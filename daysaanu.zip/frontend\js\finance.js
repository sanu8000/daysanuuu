// Daysaanu Personal Finance Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  formatCurrency,
  escapeHtml,
  icons
} from './components.js';

let summaryData = null;

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('finance');
  loadFinanceData();
  setupEventListeners();

  const params = new URLSearchParams(window.location.search);
  if (params.get('action') === 'create') {
    openTxModal();
  }
});

function setupEventListeners() {
  document.getElementById('open-create-tx-modal')?.addEventListener('click', openTxModal);
  document.getElementById('tx-modal-close-btn')?.addEventListener('click', closeTxModal);
  document.getElementById('tx-cancel-btn')?.addEventListener('click', closeTxModal);
  document.getElementById('tx-form')?.addEventListener('submit', handleTxSubmit);

  // Budget Modal
  document.getElementById('open-budget-modal-btn')?.addEventListener('click', openBudgetModal);
  document.getElementById('budget-modal-close-btn')?.addEventListener('click', closeBudgetModal);
  document.getElementById('budget-cancel-btn')?.addEventListener('click', closeBudgetModal);
  document.getElementById('budget-form')?.addEventListener('submit', handleBudgetSubmit);

  // Filters
  document.getElementById('tx-type-filter')?.addEventListener('change', loadTransactions);
  document.getElementById('tx-category-filter')?.addEventListener('change', loadTransactions);
}

async function loadFinanceData() {
  await Promise.all([
    loadSummary(),
    loadTransactions()
  ]);
}

async function loadSummary() {
  try {
    const res = await api.finance.getSummary();
    if (!res.success) return;

    summaryData = res.summary;

    document.getElementById('fin-saldo').textContent = formatCurrency(summaryData.saldo);
    document.getElementById('fin-income-month').textContent = formatCurrency(summaryData.totalIncomeMonth);
    document.getElementById('fin-expense-month').textContent = formatCurrency(summaryData.totalExpenseMonth);
    document.getElementById('fin-remaining-budget').textContent = formatCurrency(summaryData.remainingBudget);
    document.getElementById('fin-budget-cap-label').textContent = `Pagu: ${formatCurrency(summaryData.monthlyBudget)}`;

    // Savings Progress
    const savingsTarget = summaryData.savingsTarget || 1;
    const currentSavings = summaryData.currentSavings || 0;
    const savingsPct = Math.min(100, Math.round((currentSavings / savingsTarget) * 100));

    document.getElementById('savings-progress-text').textContent = `${savingsPct}%`;
    document.getElementById('savings-progress-bar').style.width = `${savingsPct}%`;
    document.getElementById('savings-current-label').textContent = `Terkumpul: ${formatCurrency(currentSavings)}`;
    document.getElementById('savings-target-label').textContent = `Target: ${formatCurrency(savingsTarget)}`;

    // Category Breakdown Bars
    renderCategoryBreakdown(summaryData.categories, summaryData.totalExpenseMonth);
  } catch (err) {
    console.error('Failed loading finance summary:', err);
  }
}

function renderCategoryBreakdown(categories, totalExpense) {
  const container = document.getElementById('category-breakdown-container');
  if (!container) return;

  if (!categories || categories.length === 0 || totalExpense === 0) {
    container.innerHTML = `
      <div style="padding: 16px; text-align: center; color: var(--text-tertiary); font-size: 0.85rem;">
        Belum ada pengeluaran yang tercatat pada bulan ini.
      </div>
    `;
    return;
  }

  const categoryColors = {
    'Makanan': '#EF4444',
    'Transportasi': '#F59E0B',
    'Kuliah': '#4F46E5',
    'Hiburan': '#EC4899',
    'Tabungan': '#10B981',
    'Lainnya': '#8B5CF6'
  };

  container.innerHTML = categories.map(c => {
    const pct = totalExpense > 0 ? Math.round((c.total / totalExpense) * 100) : 0;
    const barColor = categoryColors[c.category] || '#4F46E5';

    return `
      <div style="margin-bottom: 14px;">
        <div class="category-bar-row">
          <span class="text-xs font-semibold" style="color: var(--text-primary);">${escapeHtml(c.category)}</span>
          <span class="text-xs font-bold text-muted">${formatCurrency(c.total)} (${pct}%)</span>
        </div>
        <div class="category-bar-outer">
          <div class="category-bar-inner" style="width: ${pct}%; background: ${barColor};"></div>
        </div>
      </div>
    `;
  }).join('');
}

async function loadTransactions() {
  const container = document.getElementById('transactions-list-container');
  if (!container) return;

  const type = document.getElementById('tx-type-filter')?.value;
  const category = document.getElementById('tx-category-filter')?.value;

  container.innerHTML = `<div style="padding: 24px; text-align: center; color: var(--text-tertiary);">Memuat transaksi...</div>`;

  try {
    const res = await api.finance.getTransactions({ type, category });
    if (!res.success) throw new Error(res.message);

    const txs = res.transactions || [];
    if (txs.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="padding: 30px;">
          <div class="empty-state-title" style="font-size: 0.95rem;">Tidak ada transaksi</div>
          <div class="empty-state-desc" style="font-size: 0.85rem; margin-bottom: 0;">Catat transaksi pertama untuk melacak riwayat keuangan.</div>
        </div>
      `;
      return;
    }

    container.innerHTML = txs.map(t => {
      const isIncome = t.type === 'pemasukan';
      const d = new Date(t.date);
      const categoryBadgeClass = isIncome ? 'badge-success' : 'badge-indigo';

      return `
        <div class="tx-item" data-id="${t.id}">
          <div style="display: flex; align-items: center; gap: 12px; min-width: 0;">
            <div style="width: 38px; height: 38px; border-radius: var(--radius-full); background: ${isIncome ? 'rgba(16, 185, 129, 0.12)' : 'rgba(239, 68, 68, 0.12)'}; display: flex; align-items: center; justify-content: center; font-size: 1.1rem; flex-shrink: 0;">
              ${isIncome ? '↓' : '↑'}
            </div>
            <div style="min-width: 0;">
              <div class="font-bold text-sm truncate">${escapeHtml(t.notes || t.category)}</div>
              <div class="text-xs text-muted">
                <span class="badge ${categoryBadgeClass}">${escapeHtml(t.category)}</span> • ${formatDateIndonesian(d)}
              </div>
            </div>
          </div>
          <div style="display: flex; align-items: center; gap: 14px;">
            <div class="font-bold text-sm ${isIncome ? 'text-success' : 'text-danger'}" style="white-space: nowrap;">
              ${isIncome ? '+' : '-'} ${formatCurrency(t.amount)}
            </div>
            <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);" onclick="window.DaysaanuDeleteTx(${t.id})" title="Hapus">
              ${icons.trash}
            </button>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--status-danger);">${escapeHtml(err.message)}</div>`;
  }
}

// Global delete action
window.DaysaanuDeleteTx = (id) => {
  confirmDialog({
    title: 'Hapus Transaksi',
    message: 'Apakah Anda yakin ingin menghapus data transaksi ini?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.finance.deleteTransaction(id);
        showToast('Transaksi berhasil dihapus.', 'success');
        loadFinanceData();
      } catch (err) {
        showToast('Gagal menghapus transaksi.', 'error');
      }
    }
  });
};

function openTxModal() {
  const modal = document.getElementById('tx-modal');
  const form = document.getElementById('tx-form');
  form.reset();
  document.getElementById('tx-date-input').value = new Date().toISOString().slice(0, 10);
  modal.classList.add('active');
  document.getElementById('tx-amount-input').focus();
}

function closeTxModal() {
  document.getElementById('tx-modal')?.classList.remove('active');
}

async function handleTxSubmit(e) {
  e.preventDefault();
  const type = document.getElementById('tx-type-select').value;
  const category = document.getElementById('tx-category-select').value;
  const amount = document.getElementById('tx-amount-input').value;
  const date = document.getElementById('tx-date-input').value;
  const notes = document.getElementById('tx-notes-input').value.trim();

  if (!amount || parseFloat(amount) <= 0) {
    showToast('Jumlah transaksi harus lebih dari 0.', 'error');
    return;
  }

  try {
    await api.finance.createTransaction({ type, category, amount, date, notes });
    showToast('Transaksi berhasil dicatat!', 'success');
    closeTxModal();
    loadFinanceData();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan transaksi.', 'error');
  }
}

function openBudgetModal() {
  const modal = document.getElementById('budget-modal');
  if (summaryData) {
    document.getElementById('budget-monthly-input').value = summaryData.monthlyBudget;
    document.getElementById('budget-savings-target-input').value = summaryData.savingsTarget;
    document.getElementById('budget-savings-current-input').value = summaryData.currentSavings;
  }
  modal.classList.add('active');
}

function closeBudgetModal() {
  document.getElementById('budget-modal')?.classList.remove('active');
}

async function handleBudgetSubmit(e) {
  e.preventDefault();
  const monthly_budget = document.getElementById('budget-monthly-input').value;
  const savings_target = document.getElementById('budget-savings-target-input').value;
  const current_savings = document.getElementById('budget-savings-current-input').value;

  try {
    await api.finance.updateBudget({ monthly_budget, savings_target, current_savings });
    showToast('Anggaran dan target tabungan berhasil diperbarui!', 'success');
    closeBudgetModal();
    loadFinanceData();
  } catch (err) {
    showToast(err.message || 'Gagal memperbarui anggaran.', 'error');
  }
}
