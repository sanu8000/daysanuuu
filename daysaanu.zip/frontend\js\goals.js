// Daysaanu Goals & Milestones Interactive Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  escapeHtml,
  icons
} from './components.js';

let goalsData = [];

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('goals');
  loadGoals();
  setupEventListeners();

  const params = new URLSearchParams(window.location.search);
  if (params.get('action') === 'create') {
    openGoalModal();
  }
});

function setupEventListeners() {
  document.getElementById('open-create-goal-modal')?.addEventListener('click', () => openGoalModal());
  document.getElementById('goal-modal-close-btn')?.addEventListener('click', closeGoalModal);
  document.getElementById('goal-cancel-btn')?.addEventListener('click', closeGoalModal);
  document.getElementById('goal-form')?.addEventListener('submit', handleGoalSubmit);
}

async function loadGoals() {
  const container = document.getElementById('goals-grid-container');
  if (!container) return;

  container.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--text-tertiary); grid-column: 1/-1;">Memuat data target...</div>`;

  try {
    const res = await api.goals.getAll();
    if (!res.success) throw new Error(res.message);

    goalsData = res.goals || [];
    if (goalsData.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="grid-column: 1/-1;">
          <div class="empty-state-icon">🎯</div>
          <div class="empty-state-title">Belum ada target yang dibuat</div>
          <div class="empty-state-desc">Tuliskan impian besarmu dan bagi menjadi beberapa langkah kecil.</div>
          <button class="btn btn-secondary btn-sm" onclick="window.DaysaanuOpenCreateGoal()">+ Buat Target Pertama</button>
        </div>
      `;
      return;
    }

    container.innerHTML = goalsData.map(g => {
      const d = g.target_date ? new Date(g.target_date) : null;
      const statusBadge = g.status === 'Tercapai' ? 'badge-success' : g.status === 'Ditunda' ? 'badge-danger' : 'badge-amber';

      return `
        <div class="goal-card" data-id="${g.id}">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
              <div>
                <span class="badge ${statusBadge}">${escapeHtml(g.status)}</span>
                <h3 class="font-bold text-base" style="margin-top: 8px;">${escapeHtml(g.title)}</h3>
              </div>
              <div style="display: flex; gap: 4px;">
                <button class="btn btn-ghost btn-icon btn-sm" onclick="window.DaysaanuEditGoal(${g.id})" title="Edit">
                  ${icons.edit}
                </button>
                <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);" onclick="window.DaysaanuDeleteGoal(${g.id})" title="Hapus">
                  ${icons.trash}
                </button>
              </div>
            </div>

            ${g.description ? `<p class="text-xs text-muted" style="margin: 8px 0;">${escapeHtml(g.description)}</p>` : ''}

            <!-- Progress Bar -->
            <div style="margin: 14px 0 16px 0;">
              <div class="flex justify-between items-center" style="margin-bottom: 6px;">
                <span class="text-xs font-semibold text-muted">Progres Pencapaian</span>
                <span class="text-xs font-bold ${g.progress === 100 ? 'text-success' : 'text-indigo'}">${g.progress}%</span>
              </div>
              <div class="progress-container">
                <div class="progress-bar ${g.progress === 100 ? 'amber' : ''}" style="width: ${g.progress}%;"></div>
              </div>
            </div>

            <!-- Milestones List -->
            <div style="margin-top: 14px;">
              <div class="text-xs font-bold text-muted" style="margin-bottom: 8px; text-transform: uppercase;">
                Tahapan / Milestones (${g.completedMilestonesCount}/${g.milestonesCount})
              </div>
              <div id="milestones-box-${g.id}">
                ${g.milestones.map(m => `
                  <div class="milestone-item ${m.completed ? 'done' : ''}">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; flex: 1; min-width: 0;">
                      <input type="checkbox" ${m.completed ? 'checked' : ''}
                             onchange="window.DaysaanuToggleMilestone(${m.id})"
                             style="width: 16px; height: 16px; accent-color: var(--brand-indigo);" />
                      <span class="truncate">${escapeHtml(m.title)}</span>
                    </label>
                    <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--text-tertiary); width: 24px; height: 24px;"
                            onclick="window.DaysaanuDeleteMilestone(${m.id})" title="Hapus Milestone">
                      ×
                    </button>
                  </div>
                `).join('')}
              </div>

              <!-- Quick add milestone input -->
              <div style="display: flex; gap: 6px; margin-top: 8px;">
                <input type="text" id="new-milestone-input-${g.id}" class="form-input" style="padding: 6px 10px; font-size: 0.82rem;" placeholder="+ Tambah tahapan baru..." />
                <button class="btn btn-secondary btn-sm" onclick="window.DaysaanuAddMilestone(${g.id})">Tambah</button>
              </div>
            </div>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 20px; padding-top: 12px; border-top: 1px solid var(--border-subtle); font-size: 0.78rem; color: var(--text-tertiary);">
            <span class="badge badge-violet">${escapeHtml(g.category)}</span>
            <span>${d ? `Target: ${formatDateIndonesian(d)}` : 'Fleksibel'}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div style="padding: 24px; text-align: center; color: var(--status-danger); grid-column: 1/-1;">${escapeHtml(err.message)}</div>`;
  }
}

// Global actions
window.DaysaanuOpenCreateGoal = () => openGoalModal();

window.DaysaanuToggleMilestone = async (milestoneId) => {
  try {
    const res = await api.goals.toggleMilestone(milestoneId);
    showToast(res.message, 'success');
    loadGoals();
  } catch (err) {
    showToast('Gagal mengubah status tahapan.', 'error');
  }
};

window.DaysaanuAddMilestone = async (goalId) => {
  const input = document.getElementById(`new-milestone-input-${goalId}`);
  if (!input) return;
  const title = input.value.trim();
  if (!title) {
    showToast('Tuliskan judul tahapan.', 'error');
    return;
  }

  try {
    await api.goals.addMilestone(goalId, { title });
    showToast('Tahapan berhasil ditambahkan!', 'success');
    input.value = '';
    loadGoals();
  } catch (err) {
    showToast(err.message || 'Gagal menambahkan tahapan.', 'error');
  }
};

window.DaysaanuDeleteMilestone = (milestoneId) => {
  confirmDialog({
    title: 'Hapus Tahapan',
    message: 'Apakah Anda yakin ingin menghapus tahapan ini?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.goals.deleteMilestone(milestoneId);
        showToast('Tahapan dihapus.', 'success');
        loadGoals();
      } catch (err) {
        showToast('Gagal menghapus tahapan.', 'error');
      }
    }
  });
};

window.DaysaanuEditGoal = (id) => {
  const goal = goalsData.find(g => g.id === id);
  if (goal) openGoalModal(goal);
};

window.DaysaanuDeleteGoal = (id) => {
  confirmDialog({
    title: 'Hapus Target',
    message: 'Apakah Anda yakin ingin menghapus target ini beserta seluruh tahapannya?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.goals.delete(id);
        showToast('Target berhasil dihapus.', 'success');
        loadGoals();
      } catch (err) {
        showToast('Gagal menghapus target.', 'error');
      }
    }
  });
};

function openGoalModal(goal = null) {
  const modal = document.getElementById('goal-modal');
  const form = document.getElementById('goal-form');
  const title = document.getElementById('goal-modal-title');

  form.reset();
  if (goal) {
    title.textContent = 'Edit Target';
    document.getElementById('goal-id').value = goal.id;
    document.getElementById('goal-title-input').value = goal.title;
    document.getElementById('goal-desc-input').value = goal.description || '';
    document.getElementById('goal-category-input').value = goal.category || 'Pribadi';
    document.getElementById('goal-status-input').value = goal.status || 'Sedang Berjalan';
    if (goal.target_date) {
      document.getElementById('goal-target-date-input').value = goal.target_date.slice(0, 10);
    }
  } else {
    title.textContent = 'Buat Target Baru';
    document.getElementById('goal-id').value = '';
  }

  modal.classList.add('active');
  document.getElementById('goal-title-input').focus();
}

function closeGoalModal() {
  document.getElementById('goal-modal')?.classList.remove('active');
}

async function handleGoalSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('goal-id').value;
  const title = document.getElementById('goal-title-input').value.trim();
  const description = document.getElementById('goal-desc-input').value.trim();
  const category = document.getElementById('goal-category-input').value;
  const target_date = document.getElementById('goal-target-date-input').value;
  const status = document.getElementById('goal-status-input').value;

  if (!title) {
    showToast('Judul target wajib diisi.', 'error');
    return;
  }

  const payload = {
    title,
    description,
    category,
    target_date: target_date || null,
    status
  };

  try {
    if (id) {
      await api.goals.update(id, payload);
      showToast('Target berhasil diperbarui!', 'success');
    } else {
      await api.goals.create(payload);
      showToast('Target baru berhasil dibuat!', 'success');
    }
    closeGoalModal();
    loadGoals();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan target.', 'error');
  }
}
