import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { initDB } from './config/db.js';

// Route imports
import authRoutes from './routes/auth.routes.js';
import dashboardRoutes from './routes/dashboard.routes.js';
import tasksRoutes from './routes/tasks.routes.js';
import coursesRoutes from './routes/courses.routes.js';
import eventsRoutes from './routes/events.routes.js';
import focusRoutes from './routes/focus.routes.js';
import habitsRoutes from './routes/habits.routes.js';
import financeRoutes from './routes/finance.routes.js';
import notesRoutes from './routes/notes.routes.js';
import goalsRoutes from './routes/goals.routes.js';
import statisticsRoutes from './routes/statistics.routes.js';
import searchRoutes from './routes/search.routes.js';
import settingsRoutes from './routes/settings.routes.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend assets
const frontendPath = path.resolve(__dirname, '../frontend');
app.use(express.static(frontendPath));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/tasks', tasksRoutes);
app.use('/api/courses', coursesRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api/focus', focusRoutes);
app.use('/api/habits', habitsRoutes);
app.use('/api/finance', financeRoutes);
app.use('/api/notes', notesRoutes);
app.use('/api/goals', goalsRoutes);
app.use('/api/statistics', statisticsRoutes);
app.use('/api/search', searchRoutes);
app.use('/api/settings', settingsRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    app: 'Daysaanu API',
    version: '1.0.0',
    timestamp: new Date().toISOString()
  });
});

// Friendly 404 handler for unknown API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({
    success: false,
    message: 'Layanan API tidak ditemukan.'
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err);
  res.status(500).json({
    success: false,
    message: 'Sepertinya ada masalah pada server. Coba lagi beberapa saat lagi.'
  });
});

// Fallback to index.html for unknown frontend routes
app.get('*', (req, res) => {
  res.sendFile(path.join(frontendPath, 'index.html'));
});

// Initialize database and start server
async function startServer() {
  try {
    await initDB();
    app.listen(PORT, () => {
      console.log(`\n======================================================`);
      console.log(`✨ Daysaanu Server berjalan di http://localhost:${PORT}`);
      console.log(`🌱 Lingkungan: ${process.env.NODE_ENV || 'development'}`);
      console.log(`🎨 Antarmuka Digital Pribadi: http://localhost:${PORT}/dashboard.html`);
      console.log(`======================================================\n`);
    });
  } catch (err) {
    console.error('❌ Gagal memulai server Daysaanu:', err);
    process.exit(1);
  }
}

startServer();
