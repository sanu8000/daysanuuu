// Daysaanu Statistics & Genuine Insights Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  formatCurrency,
  escapeHtml
} from './components.js';

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('statistics');
  loadStatistics();
});

async function loadStatistics() {
  try {
    const res = await api.statistics.get();
    if (!res.success) throw new Error(res.message);

    const { stats, insights } = res;

    // 1. KPI Cards
    document.getElementById('kpi-task-rate').textContent = `${stats.taskCompletionRate}%`;
    document.getElementById('kpi-task-count').textContent = `${stats.completedTasks} dari ${stats.totalTasks} tugas selesai`;

    const focusHours = (stats.totalFocusMinutes / 60).toFixed(1);
    document.getElementById('kpi-focus-hours').textContent = `${focusHours} Jam`;
    document.getElementById('kpi-focus-week').textContent = `${stats.weekFocusMinutes} menit 7 hari terakhir`;

    document.getElementById('kpi-habit-rate').textContent = `${stats.habitWeekRate}%`;
    document.getElementById('kpi-habit-count').textContent = `${stats.habitLogsWeek} check-in minggu ini`;

    document.getElementById('kpi-goal-count').textContent = `${stats.completedGoals}`;
    document.getElementById('kpi-goal-total').textContent = `dari ${stats.totalGoals} target terdaftar`;

    // 2. Insights
    renderInsights(insights);

    // 3. Category Spending Chart
    renderSpendingChart(stats.categorySpending, stats.monthExpense);

    // 4. Load details
    document.getElementById('stats-high-priority-count').textContent = `${stats.pendingHighPriority} tugas mendesak`;
    const budgetPct = stats.monthlyBudget > 0 ? Math.round((stats.monthExpense / stats.monthlyBudget) * 100) : 0;
    document.getElementById('stats-budget-ratio-label').textContent = `${budgetPct}% terpakai`;
    document.getElementById('stats-total-habits-label').textContent = `${stats.habitTotal} kebiasaan terdaftar`;

  } catch (err) {
    console.error('Failed loading statistics:', err);
    showToast('Gagal memuat statistik produktivitas.', 'error');
  }
}

function renderInsights(insights) {
  const container = document.getElementById('insights-container');
  if (!container) return;

  if (!insights || insights.length === 0) {
    container.innerHTML = `
      <div style="padding: 16px; text-align: center; color: var(--text-tertiary); font-size: 0.9rem;">
        Belum cukup data untuk membentuk pola wawasan. Terus gunakan Daysaanu setiap hari!
      </div>
    `;
    return;
  }

  container.innerHTML = insights.map(item => {
    const icon = item.type === 'success' ? '🎯' : item.type === 'warning' ? '⚡' : item.type === 'danger' ? '⚠️' : '💡';
    return `
      <div class="insight-card insight-${item.type}">
        <span style="font-size: 1.3rem;">${icon}</span>
        <div>
          <div class="font-bold text-sm" style="color: var(--text-primary);">${escapeHtml(item.title)}</div>
          <p class="text-xs text-muted" style="margin-top: 2px;">${escapeHtml(item.text)}</p>
        </div>
      </div>
    `;
  }).join('');
}

function renderSpendingChart(categories, totalExpense) {
  const container = document.getElementById('stats-spending-chart-box');
  if (!container) return;

  if (!categories || categories.length === 0 || totalExpense === 0) {
    container.innerHTML = `
      <div style="padding: 24px; text-align: center; color: var(--text-tertiary); font-size: 0.88rem;">
        Belum ada transaksi pengeluaran tercatat bulan ini.
      </div>
    `;
    return;
  }

  const categoryColors = {
    'Makanan': '#EF4444',
    'Transportasi': '#F59E0B',
    'Kuliah': '#4F46E5',
    'Hiburan': '#EC4899',
    'Tabungan': '#10B981',
    'Lainnya': '#8B5CF6'
  };

  container.innerHTML = categories.map(c => {
    const pct = totalExpense > 0 ? Math.round((c.total / totalExpense) * 100) : 0;
    const color = categoryColors[c.category] || '#4F46E5';

    return `
      <div style="margin-bottom: 12px;">
        <div class="flex justify-between items-center" style="margin-bottom: 4px;">
          <span class="text-xs font-semibold">${escapeHtml(c.category)}</span>
          <span class="text-xs font-bold text-muted">${formatCurrency(c.total)} (${pct}%)</span>
        </div>
        <div class="progress-container" style="height: 7px;">
          <div class="progress-bar" style="width: ${pct}%; background: ${color};"></div>
        </div>
      </div>
    `;
  }).join('');
}
