// Daysaanu University Schedule Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  escapeHtml,
  icons
} from './components.js';

let semesters = [];
let currentSemesterId = null;
let currentCourses = [];

const DAYS_LIST = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

document.addEventListener('DOMContentLoaded', async () => {
  initAppShell('schedule');
  setupEventListeners();
  await loadSemesters();

  const params = new URLSearchParams(window.location.search);
  if (params.get('action') === 'create') {
    openCourseModal();
  }
});

function setupEventListeners() {
  document.getElementById('semester-selector')?.addEventListener('change', (e) => {
    currentSemesterId = e.target.value ? parseInt(e.target.value, 10) : null;
    loadScheduleData();
  });

  document.getElementById('add-semester-btn')?.addEventListener('click', handleAddSemester);

  // Course modal
  document.getElementById('open-create-course-modal')?.addEventListener('click', () => openCourseModal());
  document.getElementById('course-modal-close-btn')?.addEventListener('click', closeCourseModal);
  document.getElementById('course-cancel-btn')?.addEventListener('click', closeCourseModal);
  document.getElementById('course-form')?.addEventListener('submit', handleCourseSubmit);

  // Exam modal
  document.getElementById('open-create-exam-modal')?.addEventListener('click', openExamModal);
  document.getElementById('exam-modal-close-btn')?.addEventListener('click', closeExamModal);
  document.getElementById('exam-cancel-btn')?.addEventListener('click', closeExamModal);
  document.getElementById('exam-form')?.addEventListener('submit', handleExamSubmit);
}

async function loadSemesters() {
  try {
    const res = await api.courses.getSemesters();
    if (res.success && res.semesters) {
      semesters = res.semesters;
      const selector = document.getElementById('semester-selector');
      if (semesters.length === 0) {
        selector.innerHTML = '<option value="">Belum ada semester</option>';
        return;
      }

      selector.innerHTML = semesters.map(s => `
        <option value="${s.id}" ${s.is_active ? 'selected' : ''}>${escapeHtml(s.name)}</option>
      `).join('');

      const active = semesters.find(s => s.is_active) || semesters[0];
      currentSemesterId = active.id;
      loadScheduleData();
    }
  } catch (err) {
    showToast('Gagal memuat data semester.', 'error');
  }
}

async function handleAddSemester() {
  const name = prompt('Masukkan nama semester baru (contoh: Semester 6 - Genap 2027):');
  if (!name || !name.trim()) return;

  try {
    const res = await api.courses.createSemester({ name: name.trim(), is_active: true });
    showToast('Semester baru berhasil dibuat!', 'success');
    await loadSemesters();
  } catch (err) {
    showToast(err.message || 'Gagal membuat semester baru.', 'error');
  }
}

async function loadScheduleData() {
  const daysContainer = document.getElementById('days-schedule-container');
  if (!daysContainer) return;

  daysContainer.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--text-tertiary); grid-column: 1/-1;">Memuat jadwal...</div>`;

  try {
    const [coursesRes, examsRes] = await Promise.all([
      api.courses.getCourses(currentSemesterId),
      api.courses.getExams()
    ]);

    currentCourses = coursesRes.courses || [];
    renderDaysGrid(currentCourses);
    renderExams(examsRes.exams || []);
  } catch (err) {
    daysContainer.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--status-danger); grid-column: 1/-1;">${escapeHtml(err.message)}</div>`;
  }
}

function renderDaysGrid(courses) {
  const container = document.getElementById('days-schedule-container');
  if (!container) return;

  // Group courses by day
  const coursesByDay = {};
  DAYS_LIST.forEach(d => { coursesByDay[d] = []; });

  courses.forEach(c => {
    if (coursesByDay[c.day_of_week]) {
      coursesByDay[c.day_of_week].push(c);
    } else {
      coursesByDay['Senin'].push(c);
    }
  });

  container.innerHTML = DAYS_LIST.map(day => {
    const list = coursesByDay[day] || [];
    return `
      <div class="day-column">
        <div class="day-header">
          <div class="font-bold text-base">${day}</div>
          <span class="badge ${list.length > 0 ? 'badge-indigo' : 'badge-secondary'}">${list.length} Mata Kuliah</span>
        </div>
        <div style="flex: 1;">
          ${list.length === 0 ? `
            <div style="padding: 24px 0; text-align: center; color: var(--text-tertiary); font-size: 0.85rem;">
              Tidak ada perkuliahan
            </div>
          ` : list.map(c => `
            <div class="course-card" style="border-left: 4px solid ${c.color || '#4F46E5'};">
              <div style="display: flex; justify-content: space-between; align-items: flex-start;">
                <div>
                  <div class="font-bold text-sm">${escapeHtml(c.name)}</div>
                  <div class="text-xs text-muted" style="margin-top: 2px;">👨‍🏫 ${escapeHtml(c.lecturer || 'Dosen pengampu')}</div>
                </div>
                <div style="display: flex; gap: 4px;">
                  <button class="btn btn-ghost btn-icon btn-sm" onclick="window.DaysaanuEditCourse(${c.id})" title="Edit">
                    ${icons.edit}
                  </button>
                  <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);" onclick="window.DaysaanuDeleteCourse(${c.id})" title="Hapus">
                    ${icons.trash}
                  </button>
                </div>
              </div>
              <div style="display: flex; gap: 8px; align-items: center; margin-top: 10px; flex-wrap: wrap;">
                <span class="badge badge-indigo">⏰ ${c.start_time} - ${c.end_time}</span>
                <span class="badge badge-secondary">🏛️ ${escapeHtml(c.room || 'Kampus')}</span>
                <span class="badge badge-amber">${c.credits || 3} SKS</span>
                ${parseInt(c.pending_tasks_count, 10) > 0 ? `
                  <a href="tasks.html" class="badge badge-danger" title="Tugas aktif terkait mata kuliah ini">
                    📝 ${c.pending_tasks_count} Tugas
                  </a>
                ` : ''}
              </div>
              ${c.notes ? `<div class="text-xs text-muted" style="margin-top: 8px; font-style: italic;">"${escapeHtml(c.notes)}"</div>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
}

function renderExams(exams) {
  const container = document.getElementById('exams-container');
  if (!container) return;

  if (exams.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="padding: 24px;">
        <div class="empty-state-title" style="font-size: 0.95rem;">Belum ada jadwal ujian</div>
        <div class="empty-state-desc" style="font-size: 0.85rem; margin-bottom: 0;">Tambahkan tanggal UTS atau UAS untuk memantau persiapanmu.</div>
      </div>
    `;
    return;
  }

  container.innerHTML = `
    <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 14px; padding: 4px;">
      ${exams.map(ex => {
        const d = new Date(ex.exam_date);
        return `
          <div class="card" style="padding: 16px; background: var(--surface-translucent); border-left: 4px solid var(--brand-amber);">
            <div style="display: flex; justify-content: space-between; align-items: flex-start;">
              <div>
                <span class="badge badge-amber">${escapeHtml(ex.exam_type)}</span>
                <div class="font-bold text-sm" style="margin-top: 6px;">${escapeHtml(ex.course_name)}</div>
              </div>
              <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);" onclick="window.DaysaanuDeleteExam(${ex.id})" title="Hapus Ujian">
                ${icons.trash}
              </button>
            </div>
            <div class="text-xs font-semibold" style="margin-top: 8px; color: var(--text-primary);">
              📅 ${formatDateIndonesian(d)}
            </div>
            <div class="text-xs text-muted" style="margin-top: 2px;">
              ⏰ ${d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} • 📍 ${escapeHtml(ex.room || 'Kampus')}
            </div>
            ${ex.notes ? `<p class="text-xs text-muted" style="margin-top: 6px;">${escapeHtml(ex.notes)}</p>` : ''}
          </div>
        `;
      }).join('')}
    </div>
  `;
}

// Global actions for inline HTML
window.DaysaanuEditCourse = (id) => {
  const course = currentCourses.find(c => c.id === id);
  if (course) openCourseModal(course);
};

window.DaysaanuDeleteCourse = (id) => {
  confirmDialog({
    title: 'Hapus Mata Kuliah',
    message: 'Apakah Anda yakin ingin menghapus mata kuliah ini dari jadwal?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.courses.deleteCourse(id);
        showToast('Mata kuliah berhasil dihapus.', 'success');
        loadScheduleData();
      } catch (err) {
        showToast('Gagal menghapus mata kuliah.', 'error');
      }
    }
  });
};

window.DaysaanuDeleteExam = (id) => {
  confirmDialog({
    title: 'Hapus Jadwal Ujian',
    message: 'Apakah Anda yakin ingin menghapus jadwal ujian ini?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.courses.deleteExam(id);
        showToast('Jadwal ujian berhasil dihapus.', 'success');
        loadScheduleData();
      } catch (err) {
        showToast('Gagal menghapus jadwal ujian.', 'error');
      }
    }
  });
};

function openCourseModal(course = null) {
  const modal = document.getElementById('course-modal');
  const form = document.getElementById('course-form');
  const title = document.getElementById('course-modal-title');

  form.reset();
  if (course) {
    title.textContent = 'Edit Mata Kuliah';
    document.getElementById('course-id').value = course.id;
    document.getElementById('course-name-input').value = course.name;
    document.getElementById('course-lecturer-input').value = course.lecturer || '';
    document.getElementById('course-day-input').value = course.day_of_week || 'Senin';
    document.getElementById('course-credits-input').value = course.credits || 3;
    document.getElementById('course-start-input').value = course.start_time || '08:00';
    document.getElementById('course-end-input').value = course.end_time || '10:00';
    document.getElementById('course-room-input').value = course.room || '';
    document.getElementById('course-color-input').value = course.color || '#4F46E5';
    document.getElementById('course-notes-input').value = course.notes || '';
  } else {
    title.textContent = 'Tambah Mata Kuliah';
    document.getElementById('course-id').value = '';
  }

  modal.classList.add('active');
  document.getElementById('course-name-input').focus();
}

function closeCourseModal() {
  document.getElementById('course-modal')?.classList.remove('active');
}

async function handleCourseSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('course-id').value;
  const name = document.getElementById('course-name-input').value.trim();
  const lecturer = document.getElementById('course-lecturer-input').value.trim();
  const day_of_week = document.getElementById('course-day-input').value;
  const credits = parseInt(document.getElementById('course-credits-input').value, 10) || 3;
  const start_time = document.getElementById('course-start-input').value;
  const end_time = document.getElementById('course-end-input').value;
  const room = document.getElementById('course-room-input').value.trim();
  const color = document.getElementById('course-color-input').value;
  const notes = document.getElementById('course-notes-input').value.trim();

  if (!name) {
    showToast('Nama mata kuliah wajib diisi.', 'error');
    return;
  }

  const payload = {
    name,
    lecturer,
    day_of_week,
    credits,
    start_time,
    end_time,
    room,
    color,
    notes,
    semester_id: currentSemesterId
  };

  try {
    if (id) {
      await api.courses.updateCourse(id, payload);
      showToast('Data mata kuliah berhasil diperbarui!', 'success');
    } else {
      await api.courses.createCourse(payload);
      showToast('Mata kuliah baru berhasil ditambahkan!', 'success');
    }
    closeCourseModal();
    loadScheduleData();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan mata kuliah.', 'error');
  }
}

function openExamModal() {
  const modal = document.getElementById('exam-modal');
  const courseSelect = document.getElementById('exam-course-select');
  courseSelect.innerHTML = currentCourses.map(c => `
    <option value="${c.id}">${escapeHtml(c.name)}</option>
  `).join('');

  if (currentCourses.length === 0) {
    showToast('Tambahkan mata kuliah terlebih dahulu sebelum menjadwalkan ujian.', 'error');
    return;
  }

  document.getElementById('exam-form').reset();
  modal.classList.add('active');
}

function closeExamModal() {
  document.getElementById('exam-modal')?.classList.remove('active');
}

async function handleExamSubmit(e) {
  e.preventDefault();
  const course_id = document.getElementById('exam-course-select').value;
  const exam_type = document.getElementById('exam-type-select').value;
  const room = document.getElementById('exam-room-input').value.trim();
  const exam_date = document.getElementById('exam-date-input').value;
  const notes = document.getElementById('exam-notes-input').value.trim();

  if (!course_id || !exam_date) {
    showToast('Pilih mata kuliah dan tanggal ujian.', 'error');
    return;
  }

  try {
    await api.courses.createExam({
      course_id,
      exam_type,
      room,
      exam_date: new Date(exam_date).toISOString(),
      notes
    });
    showToast('Jadwal ujian berhasil ditambahkan!', 'success');
    closeExamModal();
    loadScheduleData();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan ujian.', 'error');
  }
}
