import express from 'express';
import { searchGlobal } from '../controllers/search.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/', searchGlobal);

export default router;
