// Daysaanu Interactive Calendar Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  escapeHtml
} from './components.js';

let currentDate = new Date();
let currentView = 'month'; // 'month' | 'week' | 'day'
let eventsData = [];

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('calendar');
  setupEventListeners();
  loadCalendar();
});

function setupEventListeners() {
  document.getElementById('cal-prev-btn')?.addEventListener('click', () => {
    navigateCalendar(-1);
  });

  document.getElementById('cal-next-btn')?.addEventListener('click', () => {
    navigateCalendar(1);
  });

  document.getElementById('cal-today-btn')?.addEventListener('click', () => {
    currentDate = new Date();
    loadCalendar();
  });

  document.querySelectorAll('.cal-view-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cal-view-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentView = btn.dataset.view;
      loadCalendar();
    });
  });

  document.getElementById('open-create-event-modal')?.addEventListener('click', () => openEventModal());
  document.getElementById('event-modal-close-btn')?.addEventListener('click', closeEventModal);
  document.getElementById('event-cancel-btn')?.addEventListener('click', closeEventModal);
  document.getElementById('event-form')?.addEventListener('submit', handleEventSubmit);
  document.getElementById('event-delete-btn')?.addEventListener('click', handleDeleteCurrentEvent);
}

function navigateCalendar(delta) {
  if (currentView === 'month') {
    currentDate.setMonth(currentDate.getMonth() + delta);
  } else if (currentView === 'week') {
    currentDate.setDate(currentDate.getDate() + delta * 7);
  } else {
    currentDate.setDate(currentDate.getDate() + delta);
  }
  loadCalendar();
}

async function loadCalendar() {
  updateHeaderLabel();
  try {
    const res = await api.events.getAll();
    if (res.success) {
      eventsData = res.events || [];
      renderMatrix();
    }
  } catch (err) {
    showToast('Gagal memuat jadwal acara kalender.', 'error');
  }
}

function updateHeaderLabel() {
  const label = document.getElementById('cal-current-label');
  if (!label) return;

  const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  if (currentView === 'month') {
    label.textContent = `${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
  } else if (currentView === 'week') {
    label.textContent = `Minggu ke-${getWeekNumber(currentDate)}, ${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
  } else {
    label.textContent = `${currentDate.getDate()} ${months[currentDate.getMonth()]} ${currentDate.getFullYear()}`;
  }
}

function getWeekNumber(d) {
  const date = new Date(d.getTime());
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  const week1 = new Date(date.getFullYear(), 0, 4);
  return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

function renderMatrix() {
  const container = document.getElementById('calendar-days-grid');
  if (!container) return;

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  // First day of month & days in month
  const firstDayIndex = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  const todayStr = new Date().toISOString().slice(0, 10);

  // Group events by YYYY-MM-DD
  const eventsByDate = {};
  eventsData.forEach(ev => {
    const dateKey = new Date(ev.start_time).toISOString().slice(0, 10);
    if (!eventsByDate[dateKey]) eventsByDate[dateKey] = [];
    eventsByDate[dateKey].push(ev);
  });

  let cells = [];

  // Previous month trailing days
  for (let x = firstDayIndex; x > 0; x--) {
    const dNum = daysInPrevMonth - x + 1;
    const prevDate = new Date(year, month - 1, dNum);
    const dateKey = prevDate.toISOString().slice(0, 10);
    cells.push({ dayNum: dNum, dateKey, isCurrentMonth: false, isToday: dateKey === todayStr });
  }

  // Current month days
  for (let i = 1; i <= daysInMonth; i++) {
    const d = new Date(year, month, i);
    const dateKey = d.toISOString().slice(0, 10);
    cells.push({ dayNum: i, dateKey, isCurrentMonth: true, isToday: dateKey === todayStr });
  }

  // Next month leading days to complete grid (42 cells = 6 weeks)
  const remainingCells = 42 - cells.length;
  for (let j = 1; j <= remainingCells; j++) {
    const nextDate = new Date(year, month + 1, j);
    const dateKey = nextDate.toISOString().slice(0, 10);
    cells.push({ dayNum: j, dateKey, isCurrentMonth: false, isToday: dateKey === todayStr });
  }

  // Filter if view is 'day' or 'week'
  if (currentView === 'day') {
    const curDateKey = currentDate.toISOString().slice(0, 10);
    cells = [{ dayNum: currentDate.getDate(), dateKey: curDateKey, isCurrentMonth: true, isToday: curDateKey === todayStr }];
    container.style.gridTemplateColumns = '1fr';
  } else if (currentView === 'week') {
    const startOfWeek = new Date(currentDate);
    startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
    cells = [];
    for (let k = 0; k < 7; k++) {
      const wkDay = new Date(startOfWeek);
      wkDay.setDate(startOfWeek.getDate() + k);
      const wkKey = wkDay.toISOString().slice(0, 10);
      cells.push({ dayNum: wkDay.getDate(), dateKey: wkKey, isCurrentMonth: true, isToday: wkKey === todayStr });
    }
    container.style.gridTemplateColumns = 'repeat(7, 1fr)';
  } else {
    container.style.gridTemplateColumns = 'repeat(7, 1fr)';
  }

  container.innerHTML = cells.map(c => {
    const evList = eventsByDate[c.dateKey] || [];
    return `
      <div class="calendar-cell ${c.isToday ? 'today' : ''} ${!c.isCurrentMonth ? 'other-month' : ''}"
           onclick="window.DaysaanuCellClick('${c.dateKey}')">
        <div class="cell-date-num">
          ${c.isToday ? `<span class="cell-today-pill">${c.dayNum}</span>` : c.dayNum}
        </div>
        <div style="flex: 1; overflow: hidden;">
          ${evList.map(ev => `
            <div class="event-badge-pill event-${ev.event_type || 'personal'}"
                 onclick="event.stopPropagation(); window.DaysaanuEditEvent(${ev.id})"
                 title="${escapeHtml(ev.title)}">
              ${escapeHtml(ev.title)}
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }).join('');
}

// Global actions
window.DaysaanuCellClick = (dateStr) => {
  openEventModal(null, dateStr);
};

window.DaysaanuEditEvent = (id) => {
  const ev = eventsData.find(e => e.id === id);
  if (ev) openEventModal(ev);
};

function openEventModal(event = null, defaultDateStr = null) {
  const modal = document.getElementById('event-modal');
  const form = document.getElementById('event-form');
  const title = document.getElementById('event-modal-title');
  const deleteBtn = document.getElementById('event-delete-btn');

  form.reset();
  if (event) {
    title.textContent = 'Edit Acara Kalender';
    deleteBtn.style.display = 'block';
    document.getElementById('event-id').value = event.id;
    document.getElementById('event-title-input').value = event.title;
    document.getElementById('event-desc-input').value = event.description || '';
    document.getElementById('event-type-select').value = event.event_type || 'personal';
    document.getElementById('event-location-input').value = event.location || '';
    
    if (event.start_time) {
      const d = new Date(event.start_time);
      const tzOffset = d.getTimezoneOffset() * 60000;
      document.getElementById('event-start-input').value = new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
    }
    if (event.end_time) {
      const d = new Date(event.end_time);
      const tzOffset = d.getTimezoneOffset() * 60000;
      document.getElementById('event-end-input').value = new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
    }
  } else {
    title.textContent = 'Buat Acara Kalender';
    deleteBtn.style.display = 'none';
    document.getElementById('event-id').value = '';
    const dateToUse = defaultDateStr || new Date().toISOString().slice(0, 10);
    document.getElementById('event-start-input').value = `${dateToUse}T09:00`;
    document.getElementById('event-end-input').value = `${dateToUse}T10:30`;
  }

  modal.classList.add('active');
  document.getElementById('event-title-input').focus();
}

function closeEventModal() {
  document.getElementById('event-modal')?.classList.remove('active');
}

async function handleEventSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('event-id').value;
  const title = document.getElementById('event-title-input').value.trim();
  const description = document.getElementById('event-desc-input').value.trim();
  const event_type = document.getElementById('event-type-select').value;
  const location = document.getElementById('event-location-input').value.trim();
  const start_time = document.getElementById('event-start-input').value;
  const end_time = document.getElementById('event-end-input').value;

  if (!title || !start_time) {
    showToast('Nama acara dan waktu mulai wajib diisi.', 'error');
    return;
  }

  const payload = {
    title,
    description,
    event_type,
    location,
    start_time: new Date(start_time).toISOString(),
    end_time: end_time ? new Date(end_time).toISOString() : null
  };

  try {
    if (id) {
      await api.events.update(id, payload);
      showToast('Acara berhasil diperbarui!', 'success');
    } else {
      await api.events.create(payload);
      showToast('Acara baru berhasil disimpan ke kalender!', 'success');
    }
    closeEventModal();
    loadCalendar();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan acara.', 'error');
  }
}

async function handleDeleteCurrentEvent() {
  const id = document.getElementById('event-id').value;
  if (!id) return;

  confirmDialog({
    title: 'Hapus Acara',
    message: 'Apakah Anda yakin ingin menghapus acara ini dari kalender?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.events.delete(id);
        showToast('Acara berhasil dihapus.', 'success');
        closeEventModal();
        loadCalendar();
      } catch (err) {
        showToast('Gagal menghapus acara.', 'error');
      }
    }
  });
}
