import express from 'express';
import { getFocusStats, logFocusSession } from '../controllers/focus.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/stats', getFocusStats);
router.post('/session', logFocusSession);

export default router;
