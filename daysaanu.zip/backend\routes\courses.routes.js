import express from 'express';
import {
  getSemesters,
  createSemester,
  getCourses,
  createCourse,
  updateCourse,
  deleteCourse,
  getExams,
  createExam,
  deleteExam
} from '../controllers/courses.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/semesters', getSemesters);
router.post('/semesters', createSemester);
router.get('/', getCourses);
router.post('/', createCourse);
router.put('/:id', updateCourse);
router.delete('/:id', deleteCourse);

router.get('/exams/all', getExams);
router.post('/exams', createExam);
router.delete('/exams/:id', deleteExam);

export default router;
