// Daysaanu Core Application Bootstrapper
import { api, getToken } from './api.js';
import { initAppShell } from './components.js';

export function bootstrap(pageId) {
  // Guard authentication
  if (!getToken()) {
    window.location.href = 'index.html';
    return;
  }

  // Initialize Shell
  initAppShell(pageId);
}
