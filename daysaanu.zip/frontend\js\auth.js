// Daysaanu Authentication Handler
import { api, getToken, setToken, setCurrentUser } from './api.js';
import { showToast } from './components.js';

document.addEventListener('DOMContentLoaded', () => {
  // Check if user is already logged in
  if (getToken()) {
    api.auth.me()
      .then(res => {
        if (res.success && res.user) {
          setCurrentUser(res.user);
          window.location.href = 'dashboard.html';
        }
      })
      .catch(() => {
        setToken(null);
        setCurrentUser(null);
      });
  }

  const authCard = document.getElementById('auth-card');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const tabLogin = document.getElementById('tab-login');
  const tabRegister = document.getElementById('tab-register');
  const demoLoginBtn = document.getElementById('demo-login-btn');

  // Tab switching
  if (tabLogin && tabRegister) {
    tabLogin.addEventListener('click', () => {
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
      loginForm.style.display = 'block';
      registerForm.style.display = 'none';
    });

    tabRegister.addEventListener('click', () => {
      tabRegister.classList.add('active');
      tabLogin.classList.remove('active');
      loginForm.style.display = 'none';
      registerForm.style.display = 'block';
    });
  }

  // Handle Login
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;

      if (!email || !password) {
        showToast('Mohon masukkan email dan kata sandi.', 'error');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Memverifikasi...';

      try {
        const res = await api.auth.login({ email, password });
        if (res.success && res.token) {
          setToken(res.token);
          setCurrentUser(res.user);
          showToast(`Selamat datang kembali, ${res.user.name}!`, 'success');
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 600);
        }
      } catch (err) {
        showToast(err.message || 'Gagal masuk. Periksa email atau kata sandi Anda.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Masuk ke Daysaanu';
      }
    });
  }

  // Handle Register
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitBtn = registerForm.querySelector('button[type="submit"]');
      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const password = document.getElementById('reg-password').value;

      if (!name || !email || !password) {
        showToast('Semua bidang wajib diisi.', 'error');
        return;
      }

      if (password.length < 6) {
        showToast('Kata sandi minimal 6 karakter.', 'error');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Membuat Ruang Kerja...';

      try {
        const res = await api.auth.register({ name, email, password });
        if (res.success && res.token) {
          setToken(res.token);
          setCurrentUser(res.user);
          showToast(res.message, 'success');
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 800);
        }
      } catch (err) {
        showToast(err.message || 'Pendaftaran belum berhasil.', 'error');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Daftar Sekarang';
      }
    });
  }

  // 1-Click Demo Login as Salsa
  if (demoLoginBtn) {
    demoLoginBtn.addEventListener('click', async () => {
      demoLoginBtn.disabled = true;
      demoLoginBtn.textContent = 'Membuka Workspace Salsa...';
      try {
        const res = await api.auth.login({ email: 'salsa@daysaanu.local', password: 'password123' });
        if (res.success && res.token) {
          setToken(res.token);
          setCurrentUser(res.user);
          showToast(`Selamat datang kembali, Salsa!`, 'success');
          setTimeout(() => {
            window.location.href = 'dashboard.html';
          }, 500);
        }
      } catch (err) {
        showToast('Gagal memuat akun demo.', 'error');
        demoLoginBtn.disabled = false;
        demoLoginBtn.textContent = 'Masuk sebagai Salsa (Akun Demo)';
      }
    });
  }
});
