import { query } from '../config/db.js';

export async function getEvents(req, res) {
  try {
    const userId = req.user.id;
    const { start, end, type } = req.query;

    let sql = `SELECT * FROM events WHERE user_id = $1`;
    const params = [userId];
    let idx = 2;

    if (start) {
      sql += ` AND start_time >= $${idx}`;
      params.push(start);
      idx++;
    }
    if (end) {
      sql += ` AND start_time <= $${idx}`;
      params.push(end);
      idx++;
    }
    if (type && type !== 'all') {
      sql += ` AND event_type = $${idx}`;
      params.push(type);
      idx++;
    }

    sql += ` ORDER BY start_time ASC`;

    const result = await query(sql, params);
    return res.json({ success: true, events: result.rows });
  } catch (err) {
    console.error('getEvents error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat jadwal acara kalender.' });
  }
}

export async function createEvent(req, res) {
  try {
    const userId = req.user.id;
    const { title, description, event_type, start_time, end_time, location, all_day } = req.body;

    if (!title || !start_time) {
      return res.status(400).json({ success: false, message: 'Judul dan waktu mulai acara wajib diisi.' });
    }

    const result = await query(
      `INSERT INTO events (user_id, title, description, event_type, start_time, end_time, location, all_day)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [
        userId,
        title.trim(),
        description ? description.trim() : '',
        event_type || 'personal',
        new Date(start_time).toISOString(),
        end_time ? new Date(end_time).toISOString() : null,
        location ? location.trim() : '',
        all_day || false
      ]
    );

    return res.status(201).json({ success: true, message: 'Acara berhasil ditambahkan ke kalender.', event: result.rows[0] });
  } catch (err) {
    console.error('createEvent error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menambahkan acara.' });
  }
}

export async function updateEvent(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { title, description, event_type, start_time, end_time, location, all_day } = req.body;

    const check = await query('SELECT * FROM events WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Acara tidak ditemukan.' });
    }

    const current = check.rows[0];
    const result = await query(
      `UPDATE events
       SET title = $1, description = $2, event_type = $3, start_time = $4, end_time = $5, location = $6, all_day = $7
       WHERE id = $8 AND user_id = $9 RETURNING *`,
      [
        title !== undefined ? title.trim() : current.title,
        description !== undefined ? description : current.description,
        event_type || current.event_type,
        start_time ? new Date(start_time).toISOString() : current.start_time,
        end_time !== undefined ? (end_time ? new Date(end_time).toISOString() : null) : current.end_time,
        location !== undefined ? location.trim() : current.location,
        all_day !== undefined ? all_day : current.all_day,
        id,
        userId
      ]
    );

    return res.json({ success: true, message: 'Acara berhasil diperbarui.', event: result.rows[0] });
  } catch (err) {
    console.error('updateEvent error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui acara.' });
  }
}

export async function deleteEvent(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM events WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Acara tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Acara berhasil dihapus dari kalender.' });
  } catch (err) {
    console.error('deleteEvent error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus acara.' });
  }
}
