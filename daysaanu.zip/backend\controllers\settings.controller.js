import { query } from '../config/db.js';
import bcrypt from 'bcryptjs';

export async function getSettings(req, res) {
  try {
    const userId = req.user.id;

    const userRes = await query('SELECT id, name, email, avatar, created_at FROM users WHERE id = $1', [userId]);
    const settingsRes = await query('SELECT * FROM settings WHERE user_id = $1', [userId]);

    return res.json({
      success: true,
      user: userRes.rows[0],
      settings: settingsRes.rows[0] || {}
    });
  } catch (err) {
    console.error('getSettings error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat pengaturan.' });
  }
}

export async function updateSettings(req, res) {
  try {
    const userId = req.user.id;
    const {
      theme,
      accent_color,
      pomodoro_focus,
      pomodoro_short_break,
      pomodoro_long_break,
      notifications_enabled,
      reduced_motion
    } = req.body;

    const result = await query(
      `UPDATE settings
       SET theme = COALESCE($1, theme),
           accent_color = COALESCE($2, accent_color),
           pomodoro_focus = COALESCE($3, pomodoro_focus),
           pomodoro_short_break = COALESCE($4, pomodoro_short_break),
           pomodoro_long_break = COALESCE($5, pomodoro_long_break),
           notifications_enabled = COALESCE($6, notifications_enabled),
           reduced_motion = COALESCE($7, reduced_motion),
           updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $8 RETURNING *`,
      [
        theme,
        accent_color,
        pomodoro_focus ? parseInt(pomodoro_focus, 10) : null,
        pomodoro_short_break ? parseInt(pomodoro_short_break, 10) : null,
        pomodoro_long_break ? parseInt(pomodoro_long_break, 10) : null,
        notifications_enabled,
        reduced_motion,
        userId
      ]
    );

    return res.json({
      success: true,
      message: 'Preferensi pengaturan berhasil disimpan.',
      settings: result.rows[0]
    });
  } catch (err) {
    console.error('updateSettings error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui pengaturan.' });
  }
}

export async function updateProfile(req, res) {
  try {
    const userId = req.user.id;
    const { name, email, current_password, new_password, avatar } = req.body;

    if (new_password) {
      if (!current_password) {
        return res.status(400).json({ success: false, message: 'Kata sandi saat ini wajib diisi untuk mengganti kata sandi baru.' });
      }
      const userRes = await query('SELECT password_hash FROM users WHERE id = $1', [userId]);
      const isMatch = await bcrypt.compare(current_password, userRes.rows[0].password_hash);
      if (!isMatch) {
        return res.status(400).json({ success: false, message: 'Kata sandi saat ini tidak cocok.' });
      }
      const salt = await bcrypt.genSalt(10);
      const newHash = await bcrypt.hash(new_password, salt);
      await query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, userId]);
    }

    const updatedUser = await query(
      `UPDATE users
       SET name = COALESCE($1, name),
           email = COALESCE($2, email),
           avatar = COALESCE($3, avatar),
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $4 RETURNING id, name, email, avatar, created_at`,
      [name ? name.trim() : null, email ? email.trim().toLowerCase() : null, avatar || null, userId]
    );

    return res.json({
      success: true,
      message: 'Profil berhasil diperbarui.',
      user: updatedUser.rows[0]
    });
  } catch (err) {
    console.error('updateProfile error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui profil.' });
  }
}

export async function exportData(req, res) {
  try {
    const userId = req.user.id;

    const userRes = await query('SELECT id, name, email, created_at FROM users WHERE id = $1', [userId]);
    const settingsRes = await query('SELECT * FROM settings WHERE user_id = $1', [userId]);
    const tasksRes = await query('SELECT * FROM tasks WHERE user_id = $1', [userId]);
    const coursesRes = await query('SELECT * FROM courses WHERE user_id = $1', [userId]);
    const eventsRes = await query('SELECT * FROM events WHERE user_id = $1', [userId]);
    const habitsRes = await query('SELECT * FROM habits WHERE user_id = $1', [userId]);
    const habitLogsRes = await query('SELECT * FROM habit_logs WHERE user_id = $1', [userId]);
    const financeRes = await query('SELECT * FROM finance_transactions WHERE user_id = $1', [userId]);
    const notesRes = await query('SELECT * FROM notes WHERE user_id = $1', [userId]);
    const goalsRes = await query('SELECT * FROM goals WHERE user_id = $1', [userId]);
    const milestonesRes = await query('SELECT * FROM goal_milestones WHERE user_id = $1', [userId]);
    const focusRes = await query('SELECT * FROM focus_sessions WHERE user_id = $1', [userId]);

    const backup = {
      export_date: new Date().toISOString(),
      app: 'Daysaanu Personal Digital Workspace',
      user: userRes.rows[0],
      settings: settingsRes.rows[0],
      tasks: tasksRes.rows,
      courses: coursesRes.rows,
      events: eventsRes.rows,
      habits: habitsRes.rows,
      habit_logs: habitLogsRes.rows,
      finance_transactions: financeRes.rows,
      notes: notesRes.rows,
      goals: goalsRes.rows,
      goal_milestones: milestonesRes.rows,
      focus_sessions: focusRes.rows
    };

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename=daysaanu-backup-${userId}-${Date.now()}.json`);
    return res.json(backup);
  } catch (err) {
    console.error('exportData error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mengekspor data akun.' });
  }
}

export async function deleteAccount(req, res) {
  try {
    const userId = req.user.id;
    await query('DELETE FROM users WHERE id = $1', [userId]);
    return res.json({ success: true, message: 'Akun Anda dan seluruh data terkait telah berhasil dihapus secara permanen.' });
  } catch (err) {
    console.error('deleteAccount error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus akun.' });
  }
}
