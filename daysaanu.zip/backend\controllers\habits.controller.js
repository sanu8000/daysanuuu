import { query } from '../config/db.js';

export async function getHabits(req, res) {
  try {
    const userId = req.user.id;
    const today = new Date().toISOString().slice(0, 10);

    // Get all habits
    const habitsRes = await query(
      `SELECT * FROM habits WHERE user_id = $1 ORDER BY id ASC`,
      [userId]
    );

    // Get logs for the last 14 days
    const past14Days = new Date();
    past14Days.setDate(past14Days.getDate() - 14);
    const past14Str = past14Days.toISOString().slice(0, 10);

    const logsRes = await query(
      `SELECT habit_id, log_date, completed
       FROM habit_logs
       WHERE user_id = $1 AND log_date >= $2
       ORDER BY log_date DESC`,
      [userId, past14Str]
    );

    // Map logs by habit_id and date
    const logMap = {};
    for (const log of logsRes.rows) {
      const dateKey = log.log_date instanceof Date ? log.log_date.toISOString().slice(0, 10) : String(log.log_date).slice(0, 10);
      if (!logMap[log.habit_id]) logMap[log.habit_id] = {};
      logMap[log.habit_id][dateKey] = log.completed;
    }

    // Build 7-day history array [D-6, D-5, ..., D-1, Today]
    const days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      days.push(d.toISOString().slice(0, 10));
    }

    const habits = habitsRes.rows.map(h => {
      const hLogs = logMap[h.id] || {};
      const completedToday = !!hLogs[today];

      // Calculate streak
      let streak = 0;
      let checkDate = new Date();
      // If not completed today, check if completed yesterday to maintain ongoing streak
      if (!completedToday) {
        checkDate.setDate(checkDate.getDate() - 1);
      }

      while (true) {
        const dateKey = checkDate.toISOString().slice(0, 10);
        if (hLogs[dateKey]) {
          streak++;
          checkDate.setDate(checkDate.getDate() - 1);
        } else {
          break;
        }
      }

      const weekHistory = days.map(d => ({
        date: d,
        completed: !!hLogs[d]
      }));

      const weekCompletedCount = weekHistory.filter(w => w.completed).length;

      return {
        ...h,
        completedToday,
        streak,
        weekHistory,
        weekCompletedCount
      };
    });

    return res.json({ success: true, habits, days });
  } catch (err) {
    console.error('getHabits error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat daftar kebiasaan.' });
  }
}

export async function createHabit(req, res) {
  try {
    const userId = req.user.id;
    const { name, description, category, icon, target_days_per_week, color } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Nama kebiasaan wajib diisi.' });
    }

    const result = await query(
      `INSERT INTO habits (user_id, name, description, category, icon, target_days_per_week, color)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
      [
        userId,
        name.trim(),
        description ? description.trim() : '',
        category || 'Pribadi',
        icon || 'sparkles',
        target_days_per_week ? parseInt(target_days_per_week, 10) : 7,
        color || '#4F46E5'
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Kebiasaan baru berhasil ditambahkan.',
      habit: result.rows[0]
    });
  } catch (err) {
    console.error('createHabit error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menambahkan kebiasaan.' });
  }
}

export async function updateHabit(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { name, description, category, icon, target_days_per_week, color } = req.body;

    const check = await query('SELECT * FROM habits WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Kebiasaan tidak ditemukan.' });
    }

    const current = check.rows[0];
    const result = await query(
      `UPDATE habits
       SET name = $1, description = $2, category = $3, icon = $4, target_days_per_week = $5, color = $6
       WHERE id = $7 AND user_id = $8 RETURNING *`,
      [
        name !== undefined ? name.trim() : current.name,
        description !== undefined ? description : current.description,
        category || current.category,
        icon || current.icon,
        target_days_per_week ? parseInt(target_days_per_week, 10) : current.target_days_per_week,
        color || current.color,
        id,
        userId
      ]
    );

    return res.json({ success: true, message: 'Kebiasaan berhasil diperbarui.', habit: result.rows[0] });
  } catch (err) {
    console.error('updateHabit error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui kebiasaan.' });
  }
}

export async function deleteHabit(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM habits WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Kebiasaan tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Kebiasaan berhasil dihapus.' });
  } catch (err) {
    console.error('deleteHabit error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus kebiasaan.' });
  }
}

export async function toggleHabitCheck(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    let { date } = req.body;

    if (!date) {
      date = new Date().toISOString().slice(0, 10);
    }

    // Verify habit ownership
    const checkHabit = await query('SELECT * FROM habits WHERE id = $1 AND user_id = $2', [id, userId]);
    if (checkHabit.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Kebiasaan tidak ditemukan.' });
    }

    const checkLog = await query(
      `SELECT * FROM habit_logs WHERE habit_id = $1 AND user_id = $2 AND log_date = $3`,
      [id, userId, date]
    );

    let completed = false;
    if (checkLog.rows.length > 0) {
      // Delete or toggle
      await query(
        `DELETE FROM habit_logs WHERE habit_id = $1 AND user_id = $2 AND log_date = $3`,
        [id, userId, date]
      );
      completed = false;
    } else {
      await query(
        `INSERT INTO habit_logs (habit_id, user_id, log_date, completed) VALUES ($1, $2, $3, true)`,
        [id, userId, date]
      );
      completed = true;
    }

    return res.json({
      success: true,
      completed,
      message: completed ? 'Hebat! Satu kebiasaan berhasil dicapai hari ini.' : 'Status kebiasaan diperbarui.'
    });
  } catch (err) {
    console.error('toggleHabitCheck error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mencatat status kebiasaan.' });
  }
}
