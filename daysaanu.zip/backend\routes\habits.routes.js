import express from 'express';
import { getHabits, createHabit, updateHabit, deleteHabit, toggleHabitCheck } from '../controllers/habits.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/', getHabits);
router.post('/', createHabit);
router.put('/:id', updateHabit);
router.delete('/:id', deleteHabit);
router.post('/:id/toggle', toggleHabitCheck);

export default router;
