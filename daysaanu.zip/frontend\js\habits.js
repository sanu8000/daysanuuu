// Daysaanu Habit Tracker Interactive Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  escapeHtml,
  icons
} from './components.js';

let habitsData = [];
let daysHeader = [];

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('habits');
  loadHabits();
  setupEventListeners();

  const params = new URLSearchParams(window.location.search);
  if (params.get('action') === 'create') {
    openHabitModal();
  }
});

function setupEventListeners() {
  document.getElementById('open-create-habit-modal')?.addEventListener('click', () => openHabitModal());
  document.getElementById('habit-modal-close-btn')?.addEventListener('click', closeHabitModal);
  document.getElementById('habit-cancel-btn')?.addEventListener('click', closeHabitModal);
  document.getElementById('habit-form')?.addEventListener('submit', handleHabitSubmit);
}

async function loadHabits() {
  const container = document.getElementById('habits-list-container');
  if (!container) return;

  container.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--text-tertiary);">Memuat kebiasaan...</div>`;

  try {
    const res = await api.habits.getAll();
    if (!res.success) throw new Error(res.message);

    habitsData = res.habits || [];
    daysHeader = res.days || [];

    // Calculate total active streaks
    const activeStreaksCount = habitsData.filter(h => h.streak > 0).length;
    const streakBadge = document.getElementById('total-active-streaks-badge');
    if (streakBadge) {
      streakBadge.textContent = `🔥 ${activeStreaksCount} Rangkaian Aktif`;
    }

    if (habitsData.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">🌱</div>
          <div class="empty-state-title">Belum ada kebiasaan yang dibuat</div>
          <div class="empty-state-desc">Pilih 1-3 kebiasaan kecil untuk melatih disiplin harianmu.</div>
          <button class="btn btn-secondary btn-sm" onclick="window.DaysaanuOpenCreateHabit()">+ Buat Kebiasaan Pertama</button>
        </div>
      `;
      return;
    }

    // Build Table Header & Rows
    const dayLabels = daysHeader.map(d => {
      const dt = new Date(d);
      const isToday = d === new Date().toISOString().slice(0, 10);
      const dayNames = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'];
      return {
        dateStr: d,
        dayName: dayNames[dt.getDay()],
        dayNum: dt.getDate(),
        isToday
      };
    });

    let html = `
      <div style="display: flex; justify-content: space-between; padding: 0 14px 12px 14px; border-bottom: 2px solid var(--border-subtle); min-width: 620px;">
        <span class="text-xs font-bold text-muted" style="width: 260px;">NAMA KEBIASAAN</span>
        <div style="display: flex; gap: 8px;">
          ${dayLabels.map(l => `
            <div style="width: 36px; text-align: center;">
              <div class="text-xs ${l.isToday ? 'text-indigo font-bold' : 'text-muted'}">${l.dayName}</div>
              <div class="text-xs ${l.isToday ? 'text-indigo font-bold' : 'text-tertiary'}">${l.dayNum}</div>
            </div>
          `).join('')}
        </div>
        <span class="text-xs font-bold text-muted" style="width: 140px; text-align: right;">RANGKAIAN / AKSI</span>
      </div>
    `;

    html += habitsData.map(h => {
      return `
        <div class="habit-row" data-id="${h.id}">
          <div class="habit-meta">
            <div class="habit-icon-box" style="background: ${h.color || '#4F46E5'};">
              ${escapeHtml(h.icon || '✨')}
            </div>
            <div style="min-width: 0;">
              <div class="font-bold text-sm truncate">${escapeHtml(h.name)}</div>
              <div class="text-xs text-muted truncate">${escapeHtml(h.category)} • Target ${h.target_days_per_week || 7}x/mgg</div>
            </div>
          </div>

          <div class="days-circles">
            ${h.weekHistory.map(dayItem => `
              <button class="day-circle-btn ${dayItem.completed ? 'checked' : ''}"
                      title="${dayItem.date}: ${dayItem.completed ? 'Sudah dicapai' : 'Klik untuk check-in'}"
                      onclick="window.DaysaanuToggleHabitDay(${h.id}, '${dayItem.date}')">
                ${dayItem.completed ? '✓' : ''}
              </button>
            `).join('')}
          </div>

          <div style="width: 140px; display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
            <span class="streak-badge" title="Rangkaian beruntun">
              🔥 ${h.streak} hari
            </span>
            <button class="btn btn-ghost btn-icon btn-sm" onclick="window.DaysaanuEditHabit(${h.id})" title="Edit">
              ${icons.edit}
            </button>
            <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);" onclick="window.DaysaanuDeleteHabit(${h.id})" title="Hapus">
              ${icons.trash}
            </button>
          </div>
        </div>
      `;
    }).join('');

    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--status-danger);">${escapeHtml(err.message)}</div>`;
  }
}

// Global actions
window.DaysaanuOpenCreateHabit = () => openHabitModal();

window.DaysaanuToggleHabitDay = async (habitId, dateStr) => {
  try {
    const res = await api.habits.toggleCheck(habitId, dateStr);
    showToast(res.message, 'success');
    loadHabits();
  } catch (err) {
    showToast('Gagal mengubah status check-in.', 'error');
  }
};

window.DaysaanuEditHabit = (id) => {
  const habit = habitsData.find(h => h.id === id);
  if (habit) openHabitModal(habit);
};

window.DaysaanuDeleteHabit = (id) => {
  confirmDialog({
    title: 'Hapus Kebiasaan',
    message: 'Apakah Anda yakin ingin menghapus kebiasaan ini beserta seluruh data riwayatnya?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.habits.delete(id);
        showToast('Kebiasaan berhasil dihapus.', 'success');
        loadHabits();
      } catch (err) {
        showToast('Gagal menghapus kebiasaan.', 'error');
      }
    }
  });
};

function openHabitModal(habit = null) {
  const modal = document.getElementById('habit-modal');
  const form = document.getElementById('habit-form');
  const title = document.getElementById('habit-modal-title');

  form.reset();
  if (habit) {
    title.textContent = 'Edit Kebiasaan';
    document.getElementById('habit-id').value = habit.id;
    document.getElementById('habit-name-input').value = habit.name;
    document.getElementById('habit-desc-input').value = habit.description || '';
    document.getElementById('habit-category-input').value = habit.category || 'Pribadi';
    document.getElementById('habit-target-input').value = habit.target_days_per_week || 7;
    document.getElementById('habit-icon-input').value = habit.icon || '✨';
    document.getElementById('habit-color-input').value = habit.color || '#4F46E5';
  } else {
    title.textContent = 'Tambah Kebiasaan Baru';
    document.getElementById('habit-id').value = '';
    document.getElementById('habit-icon-input').value = '✨';
    document.getElementById('habit-color-input').value = '#4F46E5';
  }

  modal.classList.add('active');
  document.getElementById('habit-name-input').focus();
}

function closeHabitModal() {
  document.getElementById('habit-modal')?.classList.remove('active');
}

async function handleHabitSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('habit-id').value;
  const name = document.getElementById('habit-name-input').value.trim();
  const description = document.getElementById('habit-desc-input').value.trim();
  const category = document.getElementById('habit-category-input').value;
  const target_days_per_week = parseInt(document.getElementById('habit-target-input').value, 10) || 7;
  const icon = document.getElementById('habit-icon-input').value.trim() || '✨';
  const color = document.getElementById('habit-color-input').value;

  if (!name) {
    showToast('Nama kebiasaan wajib diisi.', 'error');
    return;
  }

  const payload = {
    name,
    description,
    category,
    target_days_per_week,
    icon,
    color
  };

  try {
    if (id) {
      await api.habits.update(id, payload);
      showToast('Kebiasaan berhasil diperbarui!', 'success');
    } else {
      await api.habits.create(payload);
      showToast('Kebiasaan baru berhasil ditambahkan!', 'success');
    }
    closeHabitModal();
    loadHabits();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan kebiasaan.', 'error');
  }
}
