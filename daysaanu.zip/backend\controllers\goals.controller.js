import { query } from '../config/db.js';

export async function getGoals(req, res) {
  try {
    const userId = req.user.id;

    const goalsRes = await query(
      `SELECT * FROM goals WHERE user_id = $1 ORDER BY id ASC`,
      [userId]
    );

    const milestonesRes = await query(
      `SELECT * FROM goal_milestones WHERE user_id = $1 ORDER BY id ASC`,
      [userId]
    );

    // Group milestones by goal_id
    const milestoneMap = {};
    for (const m of milestonesRes.rows) {
      if (!milestoneMap[m.goal_id]) milestoneMap[m.goal_id] = [];
      milestoneMap[m.goal_id].push(m);
    }

    const goals = goalsRes.rows.map(g => {
      const milestones = milestoneMap[g.id] || [];
      const total = milestones.length;
      const completedCount = milestones.filter(m => m.completed).length;
      const progress = total > 0 ? Math.round((completedCount / total) * 100) : (g.status === 'Tercapai' ? 100 : 0);

      return {
        ...g,
        milestones,
        milestonesCount: total,
        completedMilestonesCount: completedCount,
        progress
      };
    });

    return res.json({ success: true, goals });
  } catch (err) {
    console.error('getGoals error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat daftar target.' });
  }
}

export async function createGoal(req, res) {
  try {
    const userId = req.user.id;
    const { title, description, target_date, category, status, milestones } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Judul target wajib diisi.' });
    }

    const goalRes = await query(
      `INSERT INTO goals (user_id, title, description, target_date, category, status)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [
        userId,
        title.trim(),
        description ? description.trim() : '',
        target_date || null,
        category || 'Pribadi',
        status || 'Sedang Berjalan'
      ]
    );
    const goal = goalRes.rows[0];

    const createdMilestones = [];
    if (Array.isArray(milestones) && milestones.length > 0) {
      for (const m of milestones) {
        if (m && m.title && m.title.trim()) {
          const mRes = await query(
            `INSERT INTO goal_milestones (goal_id, user_id, title, completed, due_date)
             VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [goal.id, userId, m.title.trim(), !!m.completed, m.due_date || null]
          );
          createdMilestones.push(mRes.rows[0]);
        }
      }
    }

    return res.status(201).json({
      success: true,
      message: 'Target baru berhasil dibuat.',
      goal: {
        ...goal,
        milestones: createdMilestones,
        progress: 0
      }
    });
  } catch (err) {
    console.error('createGoal error:', err);
    return res.status(500).json({ success: false, message: 'Gagal membuat target.' });
  }
}

export async function updateGoal(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { title, description, target_date, category, status } = req.body;

    const check = await query('SELECT * FROM goals WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Target tidak ditemukan.' });
    }

    const current = check.rows[0];
    const result = await query(
      `UPDATE goals
       SET title = $1, description = $2, target_date = $3, category = $4, status = $5
       WHERE id = $6 AND user_id = $7 RETURNING *`,
      [
        title !== undefined ? title.trim() : current.title,
        description !== undefined ? description : current.description,
        target_date !== undefined ? target_date : current.target_date,
        category || current.category,
        status || current.status,
        id,
        userId
      ]
    );

    return res.json({ success: true, message: 'Target berhasil diperbarui.', goal: result.rows[0] });
  } catch (err) {
    console.error('updateGoal error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui target.' });
  }
}

export async function deleteGoal(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM goals WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Target tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Target berhasil dihapus.' });
  } catch (err) {
    console.error('deleteGoal error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus target.' });
  }
}

export async function addMilestone(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { title, due_date } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Judul tahapan (milestone) wajib diisi.' });
    }

    // Verify goal belongs to user
    const checkGoal = await query('SELECT id FROM goals WHERE id = $1 AND user_id = $2', [id, userId]);
    if (checkGoal.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Target tidak ditemukan.' });
    }

    const result = await query(
      `INSERT INTO goal_milestones (goal_id, user_id, title, completed, due_date)
       VALUES ($1, $2, $3, false, $4) RETURNING *`,
      [id, userId, title.trim(), due_date || null]
    );

    return res.status(201).json({
      success: true,
      message: 'Tahapan baru berhasil ditambahkan.',
      milestone: result.rows[0]
    });
  } catch (err) {
    console.error('addMilestone error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menambahkan tahapan.' });
  }
}

export async function toggleMilestone(req, res) {
  try {
    const userId = req.user.id;
    const { milestoneId } = req.params;

    const check = await query('SELECT * FROM goal_milestones WHERE id = $1 AND user_id = $2', [milestoneId, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Tahapan tidak ditemukan.' });
    }

    const current = check.rows[0];
    const newStatus = !current.completed;

    const result = await query(
      `UPDATE goal_milestones SET completed = $1 WHERE id = $2 AND user_id = $3 RETURNING *`,
      [newStatus, milestoneId, userId]
    );

    return res.json({
      success: true,
      message: newStatus ? 'Tahapan berhasil diselesaikan!' : 'Status tahapan diatur kembali.',
      milestone: result.rows[0]
    });
  } catch (err) {
    console.error('toggleMilestone error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mengubah status tahapan.' });
  }
}

export async function deleteMilestone(req, res) {
  try {
    const userId = req.user.id;
    const { milestoneId } = req.params;

    const result = await query('DELETE FROM goal_milestones WHERE id = $1 AND user_id = $2 RETURNING id', [milestoneId, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Tahapan tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Tahapan berhasil dihapus.' });
  } catch (err) {
    console.error('deleteMilestone error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus tahapan.' });
  }
}
