// Comprehensive End-to-End Automated Verification Test Suite for Daysaanu
const API_URL = 'http://localhost:3000/api';

async function runTests() {
  console.log('🚀 Starting Daysaanu Full E2E Verification Suite...\n');
  let passed = 0;
  let failed = 0;

  function assert(condition, message) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  // 1. Health check
  try {
    const health = await (await fetch(`${API_URL}/health`)).json();
    assert(health.status === 'ok' && health.app === 'Daysaanu API', 'Health check endpoint returns status ok');
  } catch (err) {
    assert(false, `Health check error: ${err.message}`);
  }

  // 2. Auth: Demo Login (Salsa)
  let salsaToken = null;
  let salsaUser = null;
  try {
    const loginRes = await (await fetch(`${API_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'salsa@daysaanu.local', password: 'password123' })
    })).json();
    assert(loginRes.success === true && loginRes.user.name === 'Salsa', 'Login with Salsa credentials succeeds');
    salsaToken = loginRes.token;
    salsaUser = loginRes.user;
  } catch (err) {
    assert(false, `Login error: ${err.message}`);
  }

  // 3. User Data Isolation Test: Register a second user (Budi)
  let budiToken = null;
  const budiEmail = `budi_${Date.now()}@test.local`;
  try {
    const regRes = await (await fetch(`${API_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: 'Budi Santoso', email: budiEmail, password: 'password123' })
    })).json();
    assert(regRes.success === true && regRes.token, 'Register second user (Budi) succeeds');
    budiToken = regRes.token;
  } catch (err) {
    assert(false, `Register Budi error: ${err.message}`);
  }

  // 4. Tasks Module: Create task for Salsa, verify Budi cannot see Salsa's task
  let testTaskId = null;
  try {
    const createRes = await (await fetch(`${API_URL}/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${salsaToken}` },
      body: JSON.stringify({
        title: 'Tugas Uji Otomatis Salsa',
        description: 'Verifikasi isolasi data user',
        category: 'Project',
        priority: 'Tinggi',
        deadline: new Date(Date.now() + 86400000).toISOString()
      })
    })).json();
    assert(createRes.success === true && createRes.task.id, 'Task creation for Salsa succeeds');
    testTaskId = createRes.task.id;

    // Check Salsa sees it
    const salsaTasks = await (await fetch(`${API_URL}/tasks`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    const hasSalsaTask = salsaTasks.tasks.some(t => t.id === testTaskId);
    assert(hasSalsaTask, 'Salsa sees her newly created task');

    // Check Budi does NOT see it
    const budiTasks = await (await fetch(`${API_URL}/tasks`, {
      headers: { 'Authorization': `Bearer ${budiToken}` }
    })).json();
    const budiSeesSalsaTask = budiTasks.tasks.some(t => t.id === testTaskId);
    assert(!budiSeesSalsaTask, 'User Isolation: Budi cannot see Salsa\'s task');

    // Check Budi cannot toggle Salsa's task (Protected & isolated)
    const budiToggle = await (await fetch(`${API_URL}/tasks/${testTaskId}/toggle`, {
      method: 'PATCH',
      headers: { 'Authorization': `Bearer ${budiToken}` }
    })).json();
    assert(budiToggle.success === false, 'User Isolation: Budi cannot modify Salsa\'s task');

    // Salsa toggles her own task
    const salsaToggle = await (await fetch(`${API_URL}/tasks/${testTaskId}/toggle`, {
      method: 'PATCH',
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(salsaToggle.success === true && salsaToggle.task.completed === true, 'Task completion toggle succeeds');

    // Salsa deletes test task
    const salsaDelete = await (await fetch(`${API_URL}/tasks/${testTaskId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(salsaDelete.success === true, 'Task deletion succeeds');
  } catch (err) {
    assert(false, `Task test error: ${err.message}`);
  }

  // 5. University / Courses Module
  try {
    const coursesRes = await (await fetch(`${API_URL}/courses`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(coursesRes.success === true && Array.isArray(coursesRes.courses), 'Get Courses endpoint returns courses array');

    const examsRes = await (await fetch(`${API_URL}/courses/exams/all`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(examsRes.success === true && Array.isArray(examsRes.exams), 'Get Exams endpoint returns exams array');
  } catch (err) {
    assert(false, `Courses error: ${err.message}`);
  }

  // 6. Habit Tracker Module: Check-in toggle
  try {
    const habitsRes = await (await fetch(`${API_URL}/habits`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(habitsRes.success === true && habitsRes.habits.length > 0, 'Get Habits returns list with streak calculation');

    const habitId = habitsRes.habits[0].id;
    const today = new Date().toISOString().slice(0, 10);
    const toggleRes = await (await fetch(`${API_URL}/habits/${habitId}/toggle`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${salsaToken}` },
      body: JSON.stringify({ date: today })
    })).json();
    assert(toggleRes.success === true, 'Habit toggle check-in succeeds');
  } catch (err) {
    assert(false, `Habits error: ${err.message}`);
  }

  // 7. Finance Module: Transactions & Summary
  try {
    const summaryRes = await (await fetch(`${API_URL}/finance/summary`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(summaryRes.success === true && typeof summaryRes.summary.saldo === 'number', 'Finance summary computes saldo & remaining budget');

    const createTxRes = await (await fetch(`${API_URL}/finance/transactions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${salsaToken}` },
      body: JSON.stringify({
        type: 'pengeluaran',
        category: 'Makanan',
        amount: 25000,
        date: new Date().toISOString().slice(0, 10),
        notes: 'Uji beli kopi'
      })
    })).json();
    assert(createTxRes.success === true && createTxRes.transaction.id, 'Create finance transaction succeeds');

    // Clean up
    await fetch(`${API_URL}/finance/transactions/${createTxRes.transaction.id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    });
  } catch (err) {
    assert(false, `Finance error: ${err.message}`);
  }

  // 8. Focus Module: Log Session
  try {
    const logFocusRes = await (await fetch(`${API_URL}/focus/session`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${salsaToken}` },
      body: JSON.stringify({ duration_minutes: 25, session_type: 'focus' })
    })).json();
    assert(logFocusRes.success === true && logFocusRes.session.id, 'Log Focus Session succeeds');

    const focusStats = await (await fetch(`${API_URL}/focus/stats`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(focusStats.success === true && focusStats.stats.totalMinutes > 0, 'Focus stats calculation verified');
  } catch (err) {
    assert(false, `Focus error: ${err.message}`);
  }

  // 9. Notes Module
  try {
    const createNoteRes = await (await fetch(`${API_URL}/notes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${salsaToken}` },
      body: JSON.stringify({ title: 'Uji Catatan', content: 'Konten penting', category: 'Ide', is_pinned: true })
    })).json();
    assert(createNoteRes.success === true && createNoteRes.note.id, 'Create Note succeeds');

    const noteId = createNoteRes.note.id;
    const pinRes = await (await fetch(`${API_URL}/notes/${noteId}/pin`, {
      method: 'PATCH',
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(pinRes.success === true, 'Toggle Note Pin succeeds');

    await fetch(`${API_URL}/notes/${noteId}`, { method: 'DELETE', headers: { 'Authorization': `Bearer ${salsaToken}` } });
  } catch (err) {
    assert(false, `Notes error: ${err.message}`);
  }

  // 10. Goals & Milestones Module
  try {
    const goalsRes = await (await fetch(`${API_URL}/goals`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(goalsRes.success === true && Array.isArray(goalsRes.goals), 'Get Goals returns goals with computed milestone progress');

    if (goalsRes.goals.length > 0 && goalsRes.goals[0].milestones.length > 0) {
      const milestoneId = goalsRes.goals[0].milestones[0].id;
      const toggleMilestone = await (await fetch(`${API_URL}/goals/milestones/${milestoneId}/toggle`, {
        method: 'PATCH',
        headers: { 'Authorization': `Bearer ${salsaToken}` }
      })).json();
      assert(toggleMilestone.success === true, 'Goal Milestone toggle completion succeeds');
    }
  } catch (err) {
    assert(false, `Goals error: ${err.message}`);
  }

  // 11. Statistics Module: Genuine Data
  try {
    const statsRes = await (await fetch(`${API_URL}/statistics`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(statsRes.success === true && Array.isArray(statsRes.insights), 'Statistics aggregates real user numbers and derives true insights');
  } catch (err) {
    assert(false, `Statistics error: ${err.message}`);
  }

  // 12. Global Search Module (Ctrl+K)
  try {
    const searchRes = await (await fetch(`${API_URL}/search?q=Pemrograman`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(searchRes.success === true && (searchRes.results.courses.length > 0 || searchRes.results.tasks.length > 0), 'Global multi-module search works');
  } catch (err) {
    assert(false, `Search error: ${err.message}`);
  }

  // 13. Dashboard Aggregator
  try {
    const dashRes = await (await fetch(`${API_URL}/dashboard`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    })).json();
    assert(dashRes.success === true && typeof dashRes.data.dailyProgress === 'number', 'Dashboard aggregated payload valid');
  } catch (err) {
    assert(false, `Dashboard error: ${err.message}`);
  }

  // 14. Settings & Data Export
  try {
    const exportRes = await fetch(`${API_URL}/settings/export`, {
      headers: { 'Authorization': `Bearer ${salsaToken}` }
    });
    const backupJson = await exportRes.json();
    assert(backupJson.app === 'Daysaanu Personal Digital Workspace' && backupJson.user, 'Data export JSON backup generation verified');
  } catch (err) {
    assert(false, `Settings export error: ${err.message}`);
  }

  console.log(`\n========================================`);
  console.log(`✨ Test Results: ${passed} PASSED, ${failed} FAILED`);
  console.log(`========================================\n`);

  if (failed > 0) process.exit(1);
}

runTests();
