import { query } from '../config/db.js';

export async function getFinanceSummary(req, res) {
  try {
    const userId = req.user.id;
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    const today = now.toISOString().slice(0, 10);

    // Get user budget
    let budgetRes = await query('SELECT * FROM finance_budgets WHERE user_id = $1', [userId]);
    if (budgetRes.rows.length === 0) {
      await query(
        `INSERT INTO finance_budgets (user_id, monthly_budget, savings_target, current_savings)
         VALUES ($1, 3000000, 10000000, 0)`,
        [userId]
      );
      budgetRes = await query('SELECT * FROM finance_budgets WHERE user_id = $1', [userId]);
    }
    const budget = budgetRes.rows[0];

    // Total income (all time & this month)
    const incomeMonthRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions
       WHERE user_id = $1 AND type = 'pemasukan' AND TO_CHAR(date, 'YYYY-MM') = $2`,
      [userId, currentMonth]
    );

    // Total expense this month
    const expenseMonthRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions
       WHERE user_id = $1 AND type = 'pengeluaran' AND TO_CHAR(date, 'YYYY-MM') = $2`,
      [userId, currentMonth]
    );

    // Total all time
    const allIncomeRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions WHERE user_id = $1 AND type = 'pemasukan'`,
      [userId]
    );
    const allExpenseRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions WHERE user_id = $1 AND type = 'pengeluaran'`,
      [userId]
    );

    // Today's expense
    const todayExpenseRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions
       WHERE user_id = $1 AND type = 'pengeluaran' AND date = $2`,
      [userId, today]
    );

    // Category breakdown for this month expenses
    const categoryRes = await query(
      `SELECT category, COALESCE(SUM(amount), 0) as total, COUNT(*) as count
       FROM finance_transactions
       WHERE user_id = $1 AND type = 'pengeluaran' AND TO_CHAR(date, 'YYYY-MM') = $2
       GROUP BY category
       ORDER BY total DESC`,
      [userId, currentMonth]
    );

    const totalIncomeMonth = parseFloat(incomeMonthRes.rows[0].total);
    const totalExpenseMonth = parseFloat(expenseMonthRes.rows[0].total);
    const allIncome = parseFloat(allIncomeRes.rows[0].total);
    const allExpense = parseFloat(allExpenseRes.rows[0].total);
    const saldo = allIncome - allExpense;
    const monthlyBudget = parseFloat(budget.monthly_budget);
    const remainingBudget = Math.max(0, monthlyBudget - totalExpenseMonth);
    const todaySpending = parseFloat(todayExpenseRes.rows[0].total);

    return res.json({
      success: true,
      summary: {
        totalIncomeMonth,
        totalExpenseMonth,
        saldo,
        monthlyBudget,
        remainingBudget,
        todaySpending,
        savingsTarget: parseFloat(budget.savings_target),
        currentSavings: parseFloat(budget.current_savings),
        categories: categoryRes.rows.map(c => ({
          category: c.category,
          total: parseFloat(c.total),
          count: parseInt(c.count, 10)
        }))
      }
    });
  } catch (err) {
    console.error('getFinanceSummary error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat ringkasan keuangan.' });
  }
}

export async function getTransactions(req, res) {
  try {
    const userId = req.user.id;
    const { type, category, search, month } = req.query;

    let sql = `SELECT * FROM finance_transactions WHERE user_id = $1`;
    const params = [userId];
    let idx = 2;

    if (type && type !== 'semua') {
      sql += ` AND type = $${idx}`;
      params.push(type);
      idx++;
    }

    if (category && category !== 'Semua') {
      sql += ` AND category = $${idx}`;
      params.push(category);
      idx++;
    }

    if (month) {
      sql += ` AND TO_CHAR(date, 'YYYY-MM') = $${idx}`;
      params.push(month);
      idx++;
    }

    if (search && search.trim()) {
      sql += ` AND notes ILIKE $${idx}`;
      params.push(`%${search.trim()}%`);
      idx++;
    }

    sql += ` ORDER BY date DESC, id DESC`;

    const result = await query(sql, params);
    return res.json({ success: true, transactions: result.rows });
  } catch (err) {
    console.error('getTransactions error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat daftar transaksi.' });
  }
}

export async function createTransaction(req, res) {
  try {
    const userId = req.user.id;
    const { type, category, amount, date, notes } = req.body;

    if (!type || !category || !amount || !date) {
      return res.status(400).json({ success: false, message: 'Mohon lengkapi jenis transaksi, kategori, jumlah, dan tanggal.' });
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      return res.status(400).json({ success: false, message: 'Jumlah transaksi harus lebih dari 0.' });
    }

    const result = await query(
      `INSERT INTO finance_transactions (user_id, type, category, amount, date, notes)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [userId, type, category, numAmount, date, notes ? notes.trim() : '']
    );

    return res.status(201).json({
      success: true,
      message: 'Transaksi berhasil disimpan.',
      transaction: result.rows[0]
    });
  } catch (err) {
    console.error('createTransaction error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menyimpan transaksi.' });
  }
}

export async function deleteTransaction(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM finance_transactions WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Transaksi tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Transaksi berhasil dihapus.' });
  } catch (err) {
    console.error('deleteTransaction error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus transaksi.' });
  }
}

export async function updateBudget(req, res) {
  try {
    const userId = req.user.id;
    const { monthly_budget, savings_target, current_savings } = req.body;

    const result = await query(
      `UPDATE finance_budgets
       SET monthly_budget = COALESCE($1, monthly_budget),
           savings_target = COALESCE($2, savings_target),
           current_savings = COALESCE($3, current_savings),
           updated_at = CURRENT_TIMESTAMP
       WHERE user_id = $4 RETURNING *`,
      [
        monthly_budget ? parseFloat(monthly_budget) : null,
        savings_target ? parseFloat(savings_target) : null,
        current_savings ? parseFloat(current_savings) : null,
        userId
      ]
    );

    return res.json({
      success: true,
      message: 'Anggaran & target tabungan berhasil diperbarui.',
      budget: result.rows[0]
    });
  } catch (err) {
    console.error('updateBudget error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui anggaran.' });
  }
}
