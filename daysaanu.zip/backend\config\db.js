import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pkg from 'pg';
const { Pool } = pkg;
import { PGlite } from '@electric-sql/pglite';
import bcrypt from 'bcryptjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let dbClient = null;
let dbType = 'unknown';

export async function initDB() {
  const schemaPath = path.resolve(__dirname, '../../database/schema.sql');
  const schemaSql = fs.readFileSync(schemaPath, 'utf8');

  // Try standard PostgreSQL if configured
  if (process.env.DATABASE_URL || process.env.PGHOST) {
    try {
      const pool = new Pool({
        connectionString: process.env.DATABASE_URL,
        host: process.env.PGHOST || 'localhost',
        port: process.env.PGPORT ? parseInt(process.env.PGPORT) : 5432,
        user: process.env.PGUSER || 'postgres',
        password: process.env.PGPASSWORD || 'postgres',
        database: process.env.PGDATABASE || 'daysaanu',
        connectionTimeoutMillis: 2000,
      });

      // Quick test query
      await pool.query('SELECT 1');
      console.log('✅ Connected to external PostgreSQL database.');
      dbClient = {
        type: 'postgres',
        query: async (text, params) => {
          const res = await pool.query(text, params);
          return { rows: res.rows, rowCount: res.rowCount };
        }
      };
      dbType = 'postgres';
    } catch (err) {
      console.log('ℹ️ External PostgreSQL not reachable, using embedded PostgreSQL engine (PGlite)...');
    }
  }

  // Fallback / default: Embedded persistent PostgreSQL via PGlite
  if (!dbClient) {
    const dataDir = path.resolve(__dirname, '../../database/data_pg');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const pglite = new PGlite(dataDir);
    await pglite.waitReady;
    console.log(`✅ Connected to embedded persistent PostgreSQL at: ${dataDir}`);

    dbClient = {
      type: 'pglite',
      query: async (text, params = []) => {
        const res = await pglite.query(text, params);
        return {
          rows: res.rows || [],
          rowCount: res.affectedRows ?? (res.rows ? res.rows.length : 0)
        };
      }
    };
    dbType = 'pglite';
  }

  // Execute schema DDL
  try {
    // Split queries by semicolon to execute clean DDL blocks
    const statements = schemaSql
      .split(';')
      .map(s => s.trim())
      .filter(s => s.length > 0);

    for (const statement of statements) {
      await dbClient.query(statement + ';');
    }
    console.log('✅ Database schema verified and up-to-date.');

    // Seed default user & demo data if empty
    await seedInitialData();
  } catch (err) {
    console.error('Error executing database schema:', err);
  }

  return dbClient;
}

export async function query(text, params = []) {
  if (!dbClient) {
    await initDB();
  }
  return dbClient.query(text, params);
}

async function seedInitialData() {
  const usersRes = await dbClient.query('SELECT COUNT(*) as count FROM users');
  const count = parseInt(usersRes.rows[0].count, 10);
  if (count > 0) return;

  console.log('🌱 Seeding initial demo account for Salsa...');
  const salt = await bcrypt.genSalt(10);
  const passwordHash = await bcrypt.hash('password123', salt);

  const userInsert = await dbClient.query(
    `INSERT INTO users (name, email, password_hash, avatar)
     VALUES ($1, $2, $3, $4) RETURNING id`,
    ['Salsa', 'salsa@daysaanu.local', passwordHash, 'salsa-avatar.png']
  );
  const userId = userInsert.rows[0].id;

  // Settings
  await dbClient.query(
    `INSERT INTO settings (user_id, theme, accent_color, pomodoro_focus, pomodoro_short_break, pomodoro_long_break, notifications_enabled, reduced_motion)
     VALUES ($1, 'system', '#4F46E5', 25, 5, 15, true, false)`,
    [userId]
  );

  // Semesters & Courses
  const semInsert = await dbClient.query(
    `INSERT INTO semesters (user_id, name, is_active) VALUES ($1, 'Semester 5 (Ganjil 2026/2027)', true) RETURNING id`,
    [userId]
  );
  const semId = semInsert.rows[0].id;

  const courses = [
    { name: 'Pemrograman Web Lanjut', lecturer: 'Dr. Ir. Rian Gunawan, M.T.', credits: 3, day: 'Senin', start: '08:00', end: '10:30', room: 'Lab Komputer 3', color: '#4F46E5', notes: 'Materi: Microservices, REST API & Security' },
    { name: 'Basis Data Terdistribusi', lecturer: 'Prof. Sri Wahyuni, Ph.D.', credits: 3, day: 'Selasa', start: '10:00', end: '12:30', room: 'Gedung D.204', color: '#8B5CF6', notes: 'Fokus pada replikasi data dan optimasi query' },
    { name: 'Interaksi Manusia dan Komputer', lecturer: 'Dina Kusuma, S.Kom., M.Cs.', credits: 3, day: 'Rabu', start: '13:00', end: '15:30', room: 'Studio Desain 2', color: '#EC4899', notes: 'Project kelompok: Prototype UI/UX Desain Sistem' },
    { name: 'Kecerdasan Buatan & ML', lecturer: 'Ahmad Fauzi, M.Sc.', credits: 4, day: 'Kamis', start: '09:00', end: '12:00', room: 'Lab Riset AI', color: '#F59E0B', notes: 'Deep learning dan Computer Vision fundamentals' }
  ];

  const courseIds = [];
  for (const c of courses) {
    const res = await dbClient.query(
      `INSERT INTO courses (user_id, semester_id, name, lecturer, credits, day_of_week, start_time, end_time, room, notes, color)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING id`,
      [userId, semId, c.name, c.lecturer, c.credits, c.day, c.start, c.end, c.room, c.notes, c.color]
    );
    courseIds.push(res.rows[0].id);
  }

  // Tasks
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const next3Days = new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000);
  const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

  const tasks = [
    { title: 'Selesaikan Tugas Arsitektur API Express', desc: 'Membangun route controller untuk modul Daysaanu', priority: 'Tinggi', category: 'Kuliah', deadline: tomorrow.toISOString(), course_id: courseIds[0], completed: false },
    { title: 'Review Desain Komponen UI Glassmorphism', desc: 'Cek konsistensi token warna dan kontras tombol di mode gelap', priority: 'Sedang', category: 'Project', deadline: next3Days.toISOString(), course_id: courseIds[2], completed: false },
    { title: 'Beli Buku Catatan Grid & Kopi', desc: 'Kebutuhan catatan perkuliahan dan sesi fokus', priority: 'Rendah', category: 'Pribadi', deadline: todayStr + 'T20:00:00.000Z', course_id: null, completed: true },
    { title: 'Persiapan Presentasi Sprint Organisasi HIMA', desc: 'Susun deck slide laporan divisi riset teknologi', priority: 'Tinggi', category: 'Organisasi', deadline: nextWeek.toISOString(), course_id: null, completed: false }
  ];

  for (const t of tasks) {
    await dbClient.query(
      `INSERT INTO tasks (user_id, course_id, title, description, priority, category, deadline, completed, completed_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [userId, t.course_id, t.title, t.desc, t.priority, t.category, t.deadline, t.completed, t.completed ? new Date().toISOString() : null]
    );
  }

  // Habits
  const habits = [
    { name: 'Membaca Jurnal / Buku 20 Menit', desc: 'Membuka wawasan dan literatur ilmiah', cat: 'Pengembangan Diri', icon: 'book', target: 7, color: '#4F46E5' },
    { name: 'Minum 2 Liter Air Putih', desc: 'Menjaga hidrasi dan energi harian', cat: 'Kesehatan', icon: 'droplet', target: 7, color: '#06B6D4' },
    { name: 'Latihan Coding 45 Menit', desc: 'Asah algoritma dan implementasi modul', cat: 'Kuliah & Skill', icon: 'code', target: 5, color: '#8B5CF6' },
    { name: 'Jalan Pagi / Peregangan', desc: 'Aktivitas fisik ringan sebelum beraktivitas', cat: 'Kesehatan', icon: 'activity', target: 6, color: '#10B981' }
  ];

  for (const h of habits) {
    const hRes = await dbClient.query(
      `INSERT INTO habits (user_id, name, description, category, icon, target_days_per_week, color)
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
      [userId, h.name, h.desc, h.cat, h.icon, h.target, h.color]
    );
    const hId = hRes.rows[0].id;

    // Seed habit logs for past 4 days
    for (let d = 0; d < 4; d++) {
      const pastDate = new Date(now.getTime() - d * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
      await dbClient.query(
        `INSERT INTO habit_logs (habit_id, user_id, log_date, completed) VALUES ($1, $2, $3, true)
         ON CONFLICT (habit_id, log_date) DO NOTHING`,
        [hId, userId, pastDate]
      );
    }
  }

  // Finance
  await dbClient.query(
    `INSERT INTO finance_budgets (user_id, monthly_budget, savings_target, current_savings)
     VALUES ($1, 3500000, 12000000, 4800000)`,
    [userId]
  );

  const transactions = [
    { type: 'pemasukan', cat: 'Tabungan', amount: 3500000, date: todayStr, notes: 'Uang saku bulanan & stipend riset' },
    { type: 'pengeluaran', cat: 'Makanan', amount: 45000, date: todayStr, notes: 'Makan siang kantin kampus' },
    { type: 'pengeluaran', cat: 'Transportasi', amount: 20000, date: todayStr, notes: 'Top up kartu transportasi' },
    { type: 'pengeluaran', cat: 'Kuliah', amount: 150000, date: todayStr, notes: 'Print modul & perlengkapan lab' }
  ];

  for (const tx of transactions) {
    await dbClient.query(
      `INSERT INTO finance_transactions (user_id, type, category, amount, date, notes)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, tx.type, tx.cat, tx.amount, tx.date, tx.notes]
    );
  }

  // Notes
  const notes = [
    { title: 'Catatan Kuliah: Arsitektur RESTful API', content: 'Prinsip utama REST: Stateless, Client-Server, Cacheable, Layered System, Uniform Interface. Selalu pastikan status HTTP tepat (200, 201, 400, 401, 403, 404, 500).', category: 'Kuliah', pinned: true },
    { title: 'Ide Fitur Daysaanu: 3D Time Orb', content: 'Gunakan gradien radial transparan dan animasi rotasi berputar halus. Merepresentasikan kontinuitas waktu dan ketenangan pikiran Salsa saat bekerja.', category: 'Ide', pinned: true },
    { title: 'Rencana Belajar Semester Ini', content: 'Target: IPK >= 3.85, selesaikan 2 proyek portofolio fullstack modern, aktif di forum diskusi.', category: 'Pribadi', pinned: false }
  ];

  for (const n of notes) {
    await dbClient.query(
      `INSERT INTO notes (user_id, title, content, category, is_pinned) VALUES ($1, $2, $3, $4, $5)`,
      [userId, n.title, n.content, n.category, n.pinned]
    );
  }

  // Goals
  const goalRes = await dbClient.query(
    `INSERT INTO goals (user_id, title, description, target_date, category, status)
     VALUES ($1, 'Raih Nilai A di Semua Mata Kuliah Kejuruan', 'Menjaga konsistensi belajar harian dan pengerjaan tugas tepat waktu', $2, 'Kuliah', 'Sedang Berjalan') RETURNING id`,
    [userId, nextWeek.toISOString().slice(0, 10)]
  );
  const goalId = goalRes.rows[0].id;

  const milestones = [
    { title: 'Selesaikan semua tugas sebelum H-1 deadline', completed: true },
    { title: 'Review catatan mingguan setiap hari Jumat sore', completed: true },
    { title: 'Raih nilai tugas minimum 90 pada Pemrograman Web', completed: false },
    { title: 'Kelompokkan materi UTS dan buat ringkasan konsep', completed: false }
  ];

  for (const m of milestones) {
    await dbClient.query(
      `INSERT INTO goal_milestones (goal_id, user_id, title, completed) VALUES ($1, $2, $3, $4)`,
      [goalId, userId, m.title, m.completed]
    );
  }

  // Focus sessions
  await dbClient.query(
    `INSERT INTO focus_sessions (user_id, duration_minutes, session_type) VALUES ($1, 25, 'focus')`,
    [userId]
  );
  await dbClient.query(
    `INSERT INTO focus_sessions (user_id, duration_minutes, session_type) VALUES ($1, 50, 'focus')`,
    [userId]
  );

  // Calendar Events
  await dbClient.query(
    `INSERT INTO events (user_id, title, description, event_type, start_time, end_time, location)
     VALUES ($1, 'Kuliah Pemrograman Web Lanjut', 'Pertemuan ke-6: Autentikasi JWT', 'kuliah', $2, $3, 'Lab Komputer 3')`,
    [userId, todayStr + 'T08:00:00.000Z', todayStr + 'T10:30:00.000Z']
  );
  await dbClient.query(
    `INSERT INTO events (user_id, title, description, event_type, start_time, end_time, location)
     VALUES ($1, 'Sesi Belajar Bersama Tim Project', 'Membahas integrasi API dan database PostgreSQL', 'personal', $2, $3, 'Perpustakaan Lt. 2')`,
    [userId, todayStr + 'T14:00:00.000Z', todayStr + 'T16:00:00.000Z']
  );

  console.log('✅ Demo data for Salsa successfully seeded.');
}
