// Daysaanu Tasks Management Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  escapeHtml,
  icons
} from './components.js';

let currentView = 'semua';
let allCourses = [];

document.addEventListener('DOMContentLoaded', async () => {
  initAppShell('tasks');
  await loadCoursesDropdown();
  loadTasks();
  setupEventListeners();

  // If redirected with ?action=create
  const params = new URLSearchParams(window.location.search);
  if (params.get('action') === 'create') {
    openTaskModal();
  }
});

async function loadCoursesDropdown() {
  try {
    const res = await api.courses.getCourses();
    if (res.success && res.courses) {
      allCourses = res.courses;
      const select = document.getElementById('task-course-input');
      if (select) {
        select.innerHTML = '<option value="">(Tidak terhubung mata kuliah)</option>' +
          res.courses.map(c => `<option value="${c.id}">${escapeHtml(c.name)}</option>`).join('');
      }
    }
  } catch (err) {
    console.error('Failed loading courses:', err);
  }
}

function setupEventListeners() {
  // Tabs
  document.querySelectorAll('.view-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.view-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentView = btn.dataset.view;
      loadTasks();
    });
  });

  // Filters
  document.getElementById('task-category-filter')?.addEventListener('change', loadTasks);
  document.getElementById('task-priority-filter')?.addEventListener('change', loadTasks);
  document.getElementById('task-sort-filter')?.addEventListener('change', loadTasks);

  // Search input debounced
  let searchTimer = null;
  document.getElementById('task-search-input')?.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(loadTasks, 250);
  });

  // Modal open/close
  document.getElementById('open-create-task-modal')?.addEventListener('click', () => openTaskModal());
  document.getElementById('task-modal-close-btn')?.addEventListener('click', closeTaskModal);
  document.getElementById('task-cancel-btn')?.addEventListener('click', closeTaskModal);

  // Form submit
  document.getElementById('task-form')?.addEventListener('submit', handleTaskFormSubmit);
}

async function loadTasks() {
  const container = document.getElementById('tasks-list-container');
  if (!container) return;

  const category = document.getElementById('task-category-filter')?.value;
  const priority = document.getElementById('task-priority-filter')?.value;
  const sort = document.getElementById('task-sort-filter')?.value;
  const search = document.getElementById('task-search-input')?.value;

  container.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--text-tertiary);">Memuat data tugas...</div>`;

  try {
    const res = await api.tasks.getAll({
      view: currentView,
      category,
      priority,
      sort,
      search
    });

    if (!res.success) throw new Error(res.message);

    const tasks = res.tasks || [];
    if (tasks.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon">📋</div>
          <div class="empty-state-title">Tidak ada tugas pada kategori ini</div>
          <div class="empty-state-desc">Waktu yang bagus untuk bernapas sebentar atau menambahkan rencana baru.</div>
          <button class="btn btn-secondary btn-sm" onclick="window.DaysaanuOpenCreateTask()">+ Buat Tugas Baru</button>
        </div>
      `;
      return;
    }

    container.innerHTML = tasks.map(t => {
      const priorityClass = t.priority === 'Tinggi' ? 'badge-danger' : t.priority === 'Sedang' ? 'badge-amber' : 'badge-indigo';
      let deadlineStr = 'Tanpa tenggat';
      let isOverdue = false;

      if (t.deadline) {
        const d = new Date(t.deadline);
        deadlineStr = `${d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' })} ${d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`;
        if (d < new Date() && !t.completed) isOverdue = true;
      }

      return `
        <div class="task-card ${t.completed ? 'completed' : ''}" data-id="${t.id}">
          <div class="task-left">
            <div class="task-check-circle ${t.completed ? 'checked' : ''}" onclick="window.DaysaanuTaskToggle(${t.id})">
              ${t.completed ? '✓' : ''}
            </div>
            <div style="min-width: 0;">
              <div class="task-text-title font-semibold text-base truncate">${escapeHtml(t.title)}</div>
              ${t.description ? `<p class="text-xs text-muted truncate" style="margin-top: 2px;">${escapeHtml(t.description)}</p>` : ''}
              <div style="display: flex; gap: 8px; align-items: center; margin-top: 6px; flex-wrap: wrap;">
                <span class="badge ${priorityClass}">${t.priority}</span>
                <span class="badge badge-violet">${escapeHtml(t.category)}</span>
                ${t.course_name ? `<span class="badge badge-indigo">📚 ${escapeHtml(t.course_name)}</span>` : ''}
                <span class="text-xs ${isOverdue ? 'text-danger font-bold' : 'text-muted'}">
                  ${isOverdue ? '⚠️ Terlambat: ' : '⏰ '} ${deadlineStr}
                </span>
              </div>
            </div>
          </div>
          <div class="task-actions">
            <button class="btn btn-ghost btn-icon btn-sm" onclick="window.DaysaanuEditTask(${t.id})" title="Edit Tugas">
              ${icons.edit}
            </button>
            <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);" onclick="window.DaysaanuDeleteTask(${t.id})" title="Hapus Tugas">
              ${icons.trash}
            </button>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div style="padding: 30px; text-align: center; color: var(--status-danger);">${escapeHtml(err.message)}</div>`;
  }
}

// Global actions for inline HTML handlers
window.DaysaanuOpenCreateTask = () => openTaskModal();

window.DaysaanuTaskToggle = async (id) => {
  try {
    const res = await api.tasks.toggle(id);
    showToast(res.message, 'success');
    loadTasks();
  } catch (err) {
    showToast('Gagal memperbarui status tugas.', 'error');
  }
};

window.DaysaanuEditTask = async (id) => {
  try {
    const res = await api.tasks.getAll({ search: '' });
    const task = res.tasks.find(t => t.id === id);
    if (!task) return;
    openTaskModal(task);
  } catch (err) {
    showToast('Gagal mengambil data tugas.', 'error');
  }
};

window.DaysaanuDeleteTask = (id) => {
  confirmDialog({
    title: 'Hapus Tugas',
    message: 'Apakah Anda yakin ingin menghapus tugas ini secara permanen?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.tasks.delete(id);
        showToast('Tugas berhasil dihapus.', 'success');
        loadTasks();
      } catch (err) {
        showToast('Gagal menghapus tugas.', 'error');
      }
    }
  });
};

function openTaskModal(task = null) {
  const modal = document.getElementById('task-modal');
  const modalTitle = document.getElementById('task-modal-title');
  const form = document.getElementById('task-form');

  form.reset();
  if (task) {
    modalTitle.textContent = 'Edit Tugas';
    document.getElementById('task-id').value = task.id;
    document.getElementById('task-title-input').value = task.title;
    document.getElementById('task-desc-input').value = task.description || '';
    document.getElementById('task-category-input').value = task.category || 'Kuliah';
    document.getElementById('task-priority-input').value = task.priority || 'Sedang';
    document.getElementById('task-recurring-input').value = task.recurring || 'none';
    document.getElementById('task-course-input').value = task.course_id || '';
    if (task.deadline) {
      const d = new Date(task.deadline);
      const tzOffset = d.getTimezoneOffset() * 60000;
      const localISOTime = new Date(d.getTime() - tzOffset).toISOString().slice(0, 16);
      document.getElementById('task-deadline-input').value = localISOTime;
    }
  } else {
    modalTitle.textContent = 'Tambah Tugas Baru';
    document.getElementById('task-id').value = '';
  }

  modal.classList.add('active');
  document.getElementById('task-title-input').focus();
}

function closeTaskModal() {
  document.getElementById('task-modal')?.classList.remove('active');
}

async function handleTaskFormSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('task-id').value;
  const title = document.getElementById('task-title-input').value.trim();
  const description = document.getElementById('task-desc-input').value.trim();
  const category = document.getElementById('task-category-input').value;
  const priority = document.getElementById('task-priority-input').value;
  const recurring = document.getElementById('task-recurring-input').value;
  const course_id = document.getElementById('task-course-input').value;
  const deadlineVal = document.getElementById('task-deadline-input').value;

  if (!title) {
    showToast('Judul tugas wajib diisi.', 'error');
    return;
  }

  const payload = {
    title,
    description,
    category,
    priority,
    recurring,
    course_id: course_id || null,
    deadline: deadlineVal ? new Date(deadlineVal).toISOString() : null
  };

  try {
    if (id) {
      await api.tasks.update(id, payload);
      showToast('Tugas berhasil diperbarui!', 'success');
    } else {
      await api.tasks.create(payload);
      showToast('Tugas baru berhasil ditambahkan!', 'success');
    }
    closeTaskModal();
    loadTasks();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan tugas.', 'error');
  }
}
