import { query } from '../config/db.js';

export async function getDashboardData(req, res) {
  try {
    const userId = req.user.id;
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    // 1. User info
    const userRes = await query('SELECT id, name, avatar FROM users WHERE id = $1', [userId]);
    const user = userRes.rows[0];

    // 2. Today's Tasks
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    const tasksTodayRes = await query(
      `SELECT t.*, c.name as course_name, c.color as course_color
       FROM tasks t
       LEFT JOIN courses c ON t.course_id = c.id
       WHERE t.user_id = $1 AND (
         (t.deadline >= $2 AND t.deadline <= $3)
         OR (t.completed = false AND t.deadline < $2)
       )
       ORDER BY t.completed ASC, t.deadline ASC`,
      [userId, todayStart.toISOString(), todayEnd.toISOString()]
    );

    const allTasksToday = tasksTodayRes.rows;
    const completedTasksToday = allTasksToday.filter(t => t.completed).length;

    // Upcoming tasks (closest 5 pending tasks overall)
    const upcomingTasksRes = await query(
      `SELECT t.*, c.name as course_name, c.color as course_color
       FROM tasks t
       LEFT JOIN courses c ON t.course_id = c.id
       WHERE t.user_id = $1 AND t.completed = false
       ORDER BY t.deadline ASC NULLS LAST, t.id DESC
       LIMIT 5`,
      [userId]
    );

    // 3. Today's Schedules / Next Activity
    // Day of week in Indonesian: Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Minggu
    const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
    const currentDayName = dayNames[now.getDay()];

    const coursesTodayRes = await query(
      `SELECT * FROM courses
       WHERE user_id = $1 AND day_of_week = $2
       ORDER BY start_time ASC`,
      [userId, currentDayName]
    );

    const eventsTodayRes = await query(
      `SELECT * FROM events
       WHERE user_id = $1 AND start_time >= $2 AND start_time <= $3
       ORDER BY start_time ASC`,
      [userId, todayStart.toISOString(), todayEnd.toISOString()]
    );

    // Find next immediate activity
    let nextActivity = null;
    const currentTimeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    for (const c of coursesTodayRes.rows) {
      if (c.end_time > currentTimeStr) {
        nextActivity = {
          type: 'kuliah',
          title: c.name,
          time: `${c.start_time} - ${c.end_time}`,
          location: c.room || 'Kampus',
          lecturer: c.lecturer,
          color: c.color
        };
        break;
      }
    }

    if (!nextActivity && eventsTodayRes.rows.length > 0) {
      const ev = eventsTodayRes.rows[0];
      nextActivity = {
        type: ev.event_type,
        title: ev.title,
        time: new Date(ev.start_time).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
        location: ev.location || 'Online',
        color: '#8B5CF6'
      };
    }

    // 4. Today's Habits
    const habitsRes = await query('SELECT * FROM habits WHERE user_id = $1 ORDER BY id ASC', [userId]);
    const habitLogsTodayRes = await query(
      'SELECT habit_id FROM habit_logs WHERE user_id = $1 AND log_date = $2 AND completed = true',
      [userId, todayStr]
    );
    const completedHabitIds = new Set(habitLogsTodayRes.rows.map(r => r.habit_id));

    const todayHabits = habitsRes.rows.map(h => ({
      ...h,
      completedToday: completedHabitIds.has(h.id)
    }));
    const totalHabits = todayHabits.length;
    const completedHabitsCount = todayHabits.filter(h => h.completedToday).length;
    const habitCompletionPct = totalHabits > 0 ? Math.round((completedHabitsCount / totalHabits) * 100) : 0;

    // Daily Combined Completion Progress
    const totalDailyItems = allTasksToday.length + totalHabits;
    const completedDailyItems = completedTasksToday + completedHabitsCount;
    const dailyProgress = totalDailyItems > 0 ? Math.round((completedDailyItems / totalDailyItems) * 100) : 0;

    // 5. Today's Focus
    const focusTodayRes = await query(
      `SELECT COALESCE(SUM(duration_minutes), 0) as today_minutes, COUNT(*) as sessions
       FROM focus_sessions
       WHERE user_id = $1 AND session_type = 'focus' AND completed_at >= $2`,
      [userId, todayStart.toISOString()]
    );

    // 6. Finance
    const todayExpenseRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total
       FROM finance_transactions WHERE user_id = $1 AND type = 'pengeluaran' AND date = $2`,
      [userId, todayStr]
    );

    const monthExpenseRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total
       FROM finance_transactions WHERE user_id = $1 AND type = 'pengeluaran' AND TO_CHAR(date, 'YYYY-MM') = $2`,
      [userId, currentMonth]
    );

    const allIncomeRes = await query(`SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions WHERE user_id = $1 AND type = 'pemasukan'`, [userId]);
    const allExpenseRes = await query(`SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions WHERE user_id = $1 AND type = 'pengeluaran'`, [userId]);
    const budgetRes = await query('SELECT monthly_budget FROM finance_budgets WHERE user_id = $1', [userId]);

    const monthlyBudget = budgetRes.rows.length > 0 ? parseFloat(budgetRes.rows[0].monthly_budget) : 3000000;
    const monthExpense = parseFloat(monthExpenseRes.rows[0].total);
    const remainingBudget = Math.max(0, monthlyBudget - monthExpense);
    const saldo = parseFloat(allIncomeRes.rows[0].total) - parseFloat(allExpenseRes.rows[0].total);

    // 7. Recent Notes (for quick access)
    const recentNotesRes = await query(
      'SELECT id, title, content, category, is_pinned, updated_at FROM notes WHERE user_id = $1 ORDER BY is_pinned DESC, updated_at DESC LIMIT 3',
      [userId]
    );

    // 8. Next Deadline
    const nextDeadlineTask = upcomingTasksRes.rows.find(t => t.deadline);

    return res.json({
      success: true,
      data: {
        user,
        dailyProgress,
        nextActivity,
        nextDeadline: nextDeadlineTask || null,
        tasks: {
          today: allTasksToday,
          upcoming: upcomingTasksRes.rows,
          completedCount: completedTasksToday,
          totalCount: allTasksToday.length
        },
        coursesToday: coursesTodayRes.rows,
        habits: {
          items: todayHabits,
          completedCount: completedHabitsCount,
          totalCount: totalHabits,
          percentage: habitCompletionPct
        },
        focus: {
          todayMinutes: parseInt(focusTodayRes.rows[0].today_minutes, 10),
          sessionsCount: parseInt(focusTodayRes.rows[0].sessions, 10)
        },
        finance: {
          todaySpending: parseFloat(todayExpenseRes.rows[0].total),
          remainingBudget,
          monthlyBudget,
          saldo
        },
        recentNotes: recentNotesRes.rows
      }
    });
  } catch (err) {
    console.error('getDashboardData error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat ringkasan dashboard.' });
  }
}
