import { query } from '../config/db.js';

export async function getFocusStats(req, res) {
  try {
    const userId = req.user.id;

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);

    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - 7);
    weekStart.setHours(0, 0, 0, 0);

    // Total focus minutes
    const totalRes = await query(
      `SELECT COALESCE(SUM(duration_minutes), 0) as total_minutes, COUNT(*) as total_sessions
       FROM focus_sessions WHERE user_id = $1 AND session_type = 'focus'`,
      [userId]
    );

    // Today focus minutes
    const todayRes = await query(
      `SELECT COALESCE(SUM(duration_minutes), 0) as today_minutes, COUNT(*) as today_sessions
       FROM focus_sessions WHERE user_id = $1 AND session_type = 'focus' AND completed_at >= $2`,
      [userId, todayStart.toISOString()]
    );

    // Weekly focus minutes
    const weekRes = await query(
      `SELECT COALESCE(SUM(duration_minutes), 0) as week_minutes, COUNT(*) as week_sessions
       FROM focus_sessions WHERE user_id = $1 AND session_type = 'focus' AND completed_at >= $2`,
      [userId, weekStart.toISOString()]
    );

    // Recent 10 sessions with task details
    const recentRes = await query(
      `SELECT fs.*, t.title as task_title
       FROM focus_sessions fs
       LEFT JOIN tasks t ON fs.task_id = t.id
       WHERE fs.user_id = $1
       ORDER BY fs.completed_at DESC
       LIMIT 10`,
      [userId]
    );

    return res.json({
      success: true,
      stats: {
        totalMinutes: parseInt(totalRes.rows[0].total_minutes, 10),
        totalSessions: parseInt(totalRes.rows[0].total_sessions, 10),
        todayMinutes: parseInt(todayRes.rows[0].today_minutes, 10),
        todaySessions: parseInt(todayRes.rows[0].today_sessions, 10),
        weekMinutes: parseInt(weekRes.rows[0].week_minutes, 10),
        weekSessions: parseInt(weekRes.rows[0].week_sessions, 10)
      },
      recentSessions: recentRes.rows
    });
  } catch (err) {
    console.error('getFocusStats error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat statistik fokus.' });
  }
}

export async function logFocusSession(req, res) {
  try {
    const userId = req.user.id;
    const { duration_minutes, task_id, session_type } = req.body;

    if (!duration_minutes || duration_minutes <= 0) {
      return res.status(400).json({ success: false, message: 'Durasi sesi tidak valid.' });
    }

    const result = await query(
      `INSERT INTO focus_sessions (user_id, task_id, duration_minutes, session_type)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [
        userId,
        task_id ? parseInt(task_id, 10) : null,
        parseInt(duration_minutes, 10),
        session_type || 'focus'
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Sesi fokus berhasil dicatat! Kerja luar biasa.',
      session: result.rows[0]
    });
  } catch (err) {
    console.error('logFocusSession error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mencatat sesi fokus.' });
  }
}
