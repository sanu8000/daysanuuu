import { query } from '../config/db.js';

export async function searchGlobal(req, res) {
  try {
    const userId = req.user.id;
    const q = req.query.q ? req.query.q.trim() : '';

    if (!q || q.length < 2) {
      return res.json({
        success: true,
        results: {
          tasks: [],
          notes: [],
          courses: [],
          goals: [],
          habits: [],
          finance: []
        }
      });
    }

    const pattern = `%${q}%`;

    // 1. Tasks
    const tasksRes = await query(
      `SELECT id, title, description, priority, category, deadline, completed
       FROM tasks
       WHERE user_id = $1 AND (title ILIKE $2 OR description ILIKE $2)
       LIMIT 6`,
      [userId, pattern]
    );

    // 2. Notes
    const notesRes = await query(
      `SELECT id, title, content, category, is_pinned
       FROM notes
       WHERE user_id = $1 AND (title ILIKE $2 OR content ILIKE $2)
       LIMIT 6`,
      [userId, pattern]
    );

    // 3. Courses / Schedules
    const coursesRes = await query(
      `SELECT id, name, lecturer, day_of_week, start_time, room, color
       FROM courses
       WHERE user_id = $1 AND (name ILIKE $2 OR lecturer ILIKE $2 OR room ILIKE $2)
       LIMIT 6`,
      [userId, pattern]
    );

    // 4. Goals
    const goalsRes = await query(
      `SELECT id, title, description, status, category
       FROM goals
       WHERE user_id = $1 AND (title ILIKE $2 OR description ILIKE $2)
       LIMIT 6`,
      [userId, pattern]
    );

    // 5. Habits
    const habitsRes = await query(
      `SELECT id, name, description, category, color
       FROM habits
       WHERE user_id = $1 AND (name ILIKE $2 OR description ILIKE $2)
       LIMIT 6`,
      [userId, pattern]
    );

    // 6. Finance
    const financeRes = await query(
      `SELECT id, type, category, amount, date, notes
       FROM finance_transactions
       WHERE user_id = $1 AND (notes ILIKE $2 OR category ILIKE $2)
       LIMIT 6`,
      [userId, pattern]
    );

    return res.json({
      success: true,
      query: q,
      results: {
        tasks: tasksRes.rows,
        notes: notesRes.rows,
        courses: coursesRes.rows,
        goals: goalsRes.rows,
        habits: habitsRes.rows,
        finance: financeRes.rows
      }
    });
  } catch (err) {
    console.error('searchGlobal error:', err);
    return res.status(500).json({ success: false, message: 'Gagal melakukan pencarian global.' });
  }
}
