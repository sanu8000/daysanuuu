import { query } from '../config/db.js';

export async function getSemesters(req, res) {
  try {
    const userId = req.user.id;
    const result = await query('SELECT * FROM semesters WHERE user_id = $1 ORDER BY id DESC', [userId]);
    return res.json({ success: true, semesters: result.rows });
  } catch (err) {
    console.error('getSemesters error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat daftar semester.' });
  }
}

export async function createSemester(req, res) {
  try {
    const userId = req.user.id;
    const { name, is_active } = req.body;
    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Nama semester wajib diisi.' });
    }

    if (is_active) {
      // deactivate other semesters
      await query('UPDATE semesters SET is_active = false WHERE user_id = $1', [userId]);
    }

    const result = await query(
      `INSERT INTO semesters (user_id, name, is_active) VALUES ($1, $2, $3) RETURNING *`,
      [userId, name.trim(), is_active !== undefined ? is_active : true]
    );

    return res.status(201).json({ success: true, message: 'Semester berhasil ditambahkan.', semester: result.rows[0] });
  } catch (err) {
    console.error('createSemester error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menambahkan semester.' });
  }
}

export async function getCourses(req, res) {
  try {
    const userId = req.user.id;
    const { semester_id } = req.query;

    let sql = `
      SELECT c.*, s.name as semester_name,
        (SELECT COUNT(*) FROM tasks t WHERE t.course_id = c.id AND t.completed = false) as pending_tasks_count
      FROM courses c
      LEFT JOIN semesters s ON c.semester_id = s.id
      WHERE c.user_id = $1
    `;
    const params = [userId];

    if (semester_id) {
      sql += ' AND c.semester_id = $2';
      params.push(semester_id);
    }

    sql += ' ORDER BY c.day_of_week ASC, c.start_time ASC';

    const result = await query(sql, params);
    return res.json({ success: true, courses: result.rows });
  } catch (err) {
    console.error('getCourses error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat jadwal mata kuliah.' });
  }
}

export async function createCourse(req, res) {
  try {
    const userId = req.user.id;
    const { name, lecturer, credits, day_of_week, start_time, end_time, room, notes, color, semester_id } = req.body;

    if (!name || !name.trim()) {
      return res.status(400).json({ success: false, message: 'Nama mata kuliah wajib diisi.' });
    }

    const result = await query(
      `INSERT INTO courses (user_id, semester_id, name, lecturer, credits, day_of_week, start_time, end_time, room, notes, color)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [
        userId,
        semester_id ? parseInt(semester_id, 10) : null,
        name.trim(),
        lecturer ? lecturer.trim() : '',
        credits ? parseInt(credits, 10) : 3,
        day_of_week || 'Senin',
        start_time || '08:00',
        end_time || '10:00',
        room ? room.trim() : '',
        notes ? notes.trim() : '',
        color || '#4F46E5'
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Mata kuliah berhasil ditambahkan ke jadwal.',
      course: result.rows[0]
    });
  } catch (err) {
    console.error('createCourse error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menambahkan mata kuliah.' });
  }
}

export async function updateCourse(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { name, lecturer, credits, day_of_week, start_time, end_time, room, notes, color, semester_id } = req.body;

    const check = await query('SELECT * FROM courses WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Mata kuliah tidak ditemukan.' });
    }

    const current = check.rows[0];
    const result = await query(
      `UPDATE courses
       SET name = $1, lecturer = $2, credits = $3, day_of_week = $4, start_time = $5,
           end_time = $6, room = $7, notes = $8, color = $9, semester_id = $10
       WHERE id = $11 AND user_id = $12 RETURNING *`,
      [
        name !== undefined ? name.trim() : current.name,
        lecturer !== undefined ? lecturer.trim() : current.lecturer,
        credits !== undefined ? parseInt(credits, 10) : current.credits,
        day_of_week || current.day_of_week,
        start_time || current.start_time,
        end_time || current.end_time,
        room !== undefined ? room.trim() : current.room,
        notes !== undefined ? notes.trim() : current.notes,
        color || current.color,
        semester_id !== undefined ? (semester_id ? parseInt(semester_id, 10) : null) : current.semester_id,
        id,
        userId
      ]
    );

    return res.json({ success: true, message: 'Mata kuliah berhasil diperbarui.', course: result.rows[0] });
  } catch (err) {
    console.error('updateCourse error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui data mata kuliah.' });
  }
}

export async function deleteCourse(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM courses WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Mata kuliah tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Mata kuliah berhasil dihapus.' });
  } catch (err) {
    console.error('deleteCourse error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus mata kuliah.' });
  }
}

// Exams
export async function getExams(req, res) {
  try {
    const userId = req.user.id;
    const result = await query(
      `SELECT ce.*, c.name as course_name, c.color as course_color
       FROM course_exams ce
       JOIN courses c ON ce.course_id = c.id
       WHERE ce.user_id = $1
       ORDER BY ce.exam_date ASC`,
      [userId]
    );
    return res.json({ success: true, exams: result.rows });
  } catch (err) {
    console.error('getExams error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat jadwal ujian.' });
  }
}

export async function createExam(req, res) {
  try {
    const userId = req.user.id;
    const { course_id, exam_type, exam_date, room, notes } = req.body;

    if (!course_id || !exam_date) {
      return res.status(400).json({ success: false, message: 'Mata kuliah dan tanggal ujian wajib diisi.' });
    }

    const result = await query(
      `INSERT INTO course_exams (user_id, course_id, exam_type, exam_date, room, notes)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [userId, parseInt(course_id, 10), exam_type || 'UTS', new Date(exam_date).toISOString(), room ? room.trim() : '', notes ? notes.trim() : '']
    );

    return res.status(201).json({ success: true, message: 'Jadwal ujian berhasil ditambahkan.', exam: result.rows[0] });
  } catch (err) {
    console.error('createExam error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menyimpan jadwal ujian.' });
  }
}

export async function deleteExam(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM course_exams WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Jadwal ujian tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Jadwal ujian berhasil dihapus.' });
  } catch (err) {
    console.error('deleteExam error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus jadwal ujian.' });
  }
}
