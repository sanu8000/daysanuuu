import express from 'express';
import { getNotes, createNote, updateNote, togglePinNote, deleteNote } from '../controllers/notes.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/', getNotes);
router.post('/', createNote);
router.put('/:id', updateNote);
router.patch('/:id/pin', togglePinNote);
router.delete('/:id', deleteNote);

export default router;
