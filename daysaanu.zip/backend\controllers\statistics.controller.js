import { query } from '../config/db.js';

export async function getStatistics(req, res) {
  try {
    const userId = req.user.id;
    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const currentMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;

    // 1. Task metrics
    const taskTotalRes = await query('SELECT COUNT(*) as count FROM tasks WHERE user_id = $1', [userId]);
    const taskCompletedRes = await query('SELECT COUNT(*) as count FROM tasks WHERE user_id = $1 AND completed = true', [userId]);
    const taskHighPriorityRes = await query(`SELECT COUNT(*) as count FROM tasks WHERE user_id = $1 AND priority = 'Tinggi' AND completed = false`, [userId]);

    const totalTasks = parseInt(taskTotalRes.rows[0].count, 10);
    const completedTasks = parseInt(taskCompletedRes.rows[0].count, 10);
    const taskCompletionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

    // 2. Focus metrics
    const focusWeekStart = new Date();
    focusWeekStart.setDate(focusWeekStart.getDate() - 7);

    const focusTotalRes = await query(`SELECT COALESCE(SUM(duration_minutes), 0) as total FROM focus_sessions WHERE user_id = $1 AND session_type = 'focus'`, [userId]);
    const focusWeekRes = await query(
      `SELECT COALESCE(SUM(duration_minutes), 0) as total FROM focus_sessions WHERE user_id = $1 AND session_type = 'focus' AND completed_at >= $2`,
      [userId, focusWeekStart.toISOString()]
    );
    const totalFocusMinutes = parseInt(focusTotalRes.rows[0].total, 10);
    const weekFocusMinutes = parseInt(focusWeekRes.rows[0].total, 10);

    // 3. Habit metrics
    const habitTotalRes = await query('SELECT COUNT(*) as count FROM habits WHERE user_id = $1', [userId]);
    const habitTotal = parseInt(habitTotalRes.rows[0].count, 10);

    const habitLogsWeekRes = await query(
      `SELECT COUNT(*) as count FROM habit_logs WHERE user_id = $1 AND log_date >= $2 AND completed = true`,
      [userId, focusWeekStart.toISOString().slice(0, 10)]
    );
    const habitLogsWeek = parseInt(habitLogsWeekRes.rows[0].count, 10);
    const maxPossibleHabitWeek = habitTotal * 7;
    const habitWeekRate = maxPossibleHabitWeek > 0 ? Math.round((habitLogsWeek / maxPossibleHabitWeek) * 100) : 0;

    // 4. Finance metrics
    const expenseMonthRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions WHERE user_id = $1 AND type = 'pengeluaran' AND TO_CHAR(date, 'YYYY-MM') = $2`,
      [userId, currentMonth]
    );
    const incomeMonthRes = await query(
      `SELECT COALESCE(SUM(amount), 0) as total FROM finance_transactions WHERE user_id = $1 AND type = 'pemasukan' AND TO_CHAR(date, 'YYYY-MM') = $2`,
      [userId, currentMonth]
    );
    const budgetRes = await query('SELECT monthly_budget FROM finance_budgets WHERE user_id = $1', [userId]);
    const monthlyBudget = budgetRes.rows.length > 0 ? parseFloat(budgetRes.rows[0].monthly_budget) : 3000000;
    const monthExpense = parseFloat(expenseMonthRes.rows[0].total);
    const monthIncome = parseFloat(incomeMonthRes.rows[0].total);

    // Category spending distribution
    const categorySpendRes = await query(
      `SELECT category, COALESCE(SUM(amount), 0) as total
       FROM finance_transactions
       WHERE user_id = $1 AND type = 'pengeluaran' AND TO_CHAR(date, 'YYYY-MM') = $2
       GROUP BY category ORDER BY total DESC`,
      [userId, currentMonth]
    );

    // 5. Goals
    const goalRes = await query('SELECT COUNT(*) as total, COUNT(*) FILTER (WHERE status = \'Tercapai\') as completed FROM goals WHERE user_id = $1', [userId]);
    const totalGoals = parseInt(goalRes.rows[0].total, 10);
    const completedGoals = parseInt(goalRes.rows[0].completed, 10);

    // 6. Dynamic Real Insights based on actual data
    const insights = [];
    if (taskCompletionRate >= 70) {
      insights.push({
        type: 'success',
        title: 'Tingkat Penyelesaian Tugas Prima',
        text: `Kamu telah menuntaskan ${taskCompletionRate}% dari total tugasmu. Pertahankan ritme kerja ini!`
      });
    } else if (taskCompletionRate > 0) {
      insights.push({
        type: 'info',
        title: 'Fokus Selesaikan Tugas Tertunda',
        text: `Tingkat penyelesaian tugas saat ini berada di ${taskCompletionRate}%. Luangkan waktu untuk tugas prioritas tinggi.`
      });
    } else {
      insights.push({
        type: 'neutral',
        title: 'Mulai Hari Ini dengan Satu Tugas',
        text: 'Belum ada tugas yang diselesaikan. Satu langkah kecil mengawali lompatan besar.'
      });
    }

    if (weekFocusMinutes >= 100) {
      insights.push({
        type: 'success',
        title: 'Konsistensi Fokus Mengagumkan',
        text: `Total ${Math.round(weekFocusMinutes / 60 * 10) / 10} jam fokus tercatat dalam 7 hari terakhir.`
      });
    } else if (weekFocusMinutes > 0) {
      insights.push({
        type: 'info',
        title: 'Sesi Fokus Berjalan Baik',
        text: `Tercatat ${weekFocusMinutes} menit sesi fokus minggu ini.`
      });
    }

    if (monthExpense > 0 && monthlyBudget > 0) {
      const budgetPercent = Math.round((monthExpense / monthlyBudget) * 100);
      if (budgetPercent <= 70) {
        insights.push({
          type: 'success',
          title: 'Pengeluaran Terkendali',
          text: `Pengeluaran bulan ini baru mencapai ${budgetPercent}% dari pagu anggaran bulanan.`
        });
      } else if (budgetPercent <= 100) {
        insights.push({
          type: 'warning',
          title: 'Mendekati Batas Anggaran',
          text: `Kamu telah menggunakan ${budgetPercent}% dari anggaran bulan ini.`
        });
      } else {
        insights.push({
          type: 'danger',
          title: 'Melebihi Anggaran Bulanan',
          text: `Pengeluaran telah melampaui pagu anggaran sebesar ${(budgetPercent - 100)}%. Evaluasi pengeluaran non-primer.`
        });
      }
    }

    return res.json({
      success: true,
      stats: {
        totalTasks,
        completedTasks,
        taskCompletionRate,
        pendingHighPriority: parseInt(taskHighPriorityRes.rows[0].count, 10),
        totalFocusMinutes,
        weekFocusMinutes,
        habitTotal,
        habitWeekRate,
        habitLogsWeek,
        monthIncome,
        monthExpense,
        monthlyBudget,
        categorySpending: categorySpendRes.rows.map(r => ({ category: r.category, total: parseFloat(r.total) })),
        totalGoals,
        completedGoals
      },
      insights
    });
  } catch (err) {
    console.error('getStatistics error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat statistik produktivitas.' });
  }
}
