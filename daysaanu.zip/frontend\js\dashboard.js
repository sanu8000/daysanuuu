// Daysaanu Dashboard Interactive Script
import { api, getCurrentUser } from './api.js';
import {
  initAppShell,
  showToast,
  formatDateIndonesian,
  formatCurrency,
  escapeHtml,
  openCommandPalette
} from './components.js';

window.Daysaanu = { openCommandPalette };

document.addEventListener('DOMContentLoaded', async () => {
  initAppShell('dashboard');
  startClock();
  loadDashboardData();
  setupQuickNote();
  setupMotivationalTone();
});

// Digital Clock & Date
function startClock() {
  const clockEl = document.getElementById('digital-clock');
  const dateEl = document.getElementById('current-date-text');

  function update() {
    const now = new Date();
    if (clockEl) {
      clockEl.textContent = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
    if (dateEl) {
      dateEl.textContent = formatDateIndonesian(now);
    }
  }

  update();
  setInterval(update, 1000);
}

// Motivational Tone
function setupMotivationalTone() {
  const pill = document.getElementById('motivational-pill');
  if (!pill) return;

  const messages = [
    '✨ Pelan-pelan, yang penting jalan.',
    '💪 Semangat. Satu langkah lagi.',
    '🌿 Harimu belum selesai, nikmati prosesnya.',
    '🌟 Fokus pada apa yang bisa kamu kendalikan hari ini.'
  ];
  const hour = new Date().getHours();
  if (hour < 11) {
    pill.textContent = '🌅 Selamat pagi. Siap untuk hari yang bermakna?';
  } else if (hour < 15) {
    pill.textContent = '☀️ Semangat. Satu langkah lagi.';
  } else if (hour < 18) {
    pill.textContent = '☕ Waktu yang baik untuk bernapas sejenak.';
  } else {
    pill.textContent = '🌙 Istirahat cukup penting untuk esok hari.';
  }
}

// Load All Dashboard Data
async function loadDashboardData() {
  try {
    const res = await api.dashboard.get();
    if (!res.success) throw new Error(res.message);

    const { data } = res;

    // Greeting
    const greetingEl = document.getElementById('hero-greeting');
    if (greetingEl && data.user) {
      greetingEl.textContent = `Selamat datang kembali, ${data.user.name}.`;
    }

    // 1. Daily Progress Ring
    renderDailyProgress(data.dailyProgress, data.tasks.completedCount + data.habits.completedCount, data.tasks.totalCount + data.habits.totalCount);

    // 2. Next Activity & Deadline
    renderNextActivity(data.nextActivity);
    renderNextDeadline(data.nextDeadline);

    // 3. Tasks List
    renderTasksList(data.tasks.upcoming);

    // 4. Habits List
    renderHabitsList(data.habits.items);

    // 5. Focus Widget
    const focusMinutesEl = document.getElementById('focus-today-minutes');
    const focusSessionsEl = document.getElementById('focus-sessions-count');
    if (focusMinutesEl) {
      focusMinutesEl.innerHTML = `${data.focus.todayMinutes} <span style="font-size: 1.1rem; font-weight: 500; color: var(--text-muted);">menit</span>`;
    }
    if (focusSessionsEl) {
      focusSessionsEl.textContent = `${data.focus.sessionsCount} sesi fokus diselesaikan hari ini`;
    }

    // 6. Finance Widget
    const financeSpendingEl = document.getElementById('finance-today-spending');
    const financeRemainingEl = document.getElementById('finance-remaining-budget');
    if (financeSpendingEl) {
      financeSpendingEl.textContent = formatCurrency(data.finance.todaySpending);
    }
    if (financeRemainingEl) {
      financeRemainingEl.textContent = formatCurrency(data.finance.remainingBudget);
    }
  } catch (err) {
    console.error('loadDashboardData error:', err);
    showToast('Gagal memuat beberapa data dashboard.', 'error');
  }
}

// Render Daily Progress Ring
function renderDailyProgress(pct, completedCount, totalCount) {
  const circle = document.getElementById('daily-ring-circle');
  const label = document.getElementById('daily-percentage-label');
  const ratio = document.getElementById('daily-items-ratio');
  const desc = document.getElementById('daily-progress-desc');

  const circumference = 263.89; // 2 * PI * 42
  const offset = circumference - (pct / 100) * circumference;

  if (circle) circle.style.strokeDashoffset = offset;
  if (label) label.textContent = `${pct}%`;
  if (ratio) ratio.textContent = `${completedCount}/${totalCount} selesai`;

  if (desc) {
    if (pct === 100 && totalCount > 0) {
      desc.textContent = 'Luar biasa! Seluruh target aktivitas harianmu selesai hari ini 🎉';
    } else if (pct >= 50) {
      desc.textContent = 'Ritme kerja sangat bagus! Lebih dari setengah target telah tercapai.';
    } else {
      desc.textContent = 'Mulai selesaikan tugas & kebiasaan untuk mengisi lingkaran harimu.';
    }
  }
}

// Render Next Activity Banner
function renderNextActivity(activity) {
  const titleEl = document.getElementById('next-activity-title');
  const metaEl = document.getElementById('next-activity-meta');
  if (!titleEl || !metaEl) return;

  if (activity) {
    titleEl.textContent = activity.title;
    metaEl.textContent = `${activity.time} • ${activity.location}`;
  } else {
    titleEl.textContent = 'Tidak ada jadwal terdekat';
    metaEl.textContent = 'Waktu bebas untuk eksplorasi mandiri';
  }
}

// Render Next Deadline
function renderNextDeadline(deadlineTask) {
  const titleEl = document.getElementById('next-deadline-title');
  const metaEl = document.getElementById('next-deadline-meta');
  if (!titleEl || !metaEl) return;

  if (deadlineTask && deadlineTask.deadline) {
    titleEl.textContent = deadlineTask.title;
    const d = new Date(deadlineTask.deadline);
    metaEl.textContent = `${d.toLocaleDateString('id-ID', { weekday: 'short', day: 'numeric', month: 'short' })} ${d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}`;
  } else {
    titleEl.textContent = 'Semua tugas aman';
    metaEl.textContent = 'Tidak ada tenggat mendesak';
  }
}

// Render Tasks List with interactive checkbox
function renderTasksList(tasks) {
  const container = document.getElementById('dashboard-tasks-list');
  if (!container) return;

  if (!tasks || tasks.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="padding: 24px;">
        <div class="empty-state-title" style="font-size: 1rem;">Tidak ada tugas aktif</div>
        <div class="empty-state-desc" style="font-size: 0.85rem; margin-bottom: 0;">Waktu yang bagus untuk bernapas sebentar.</div>
      </div>
    `;
    return;
  }

  container.innerHTML = tasks.map(t => {
    const isDue = t.deadline ? new Date(t.deadline).toLocaleDateString('id-ID', { day: 'numeric', month: 'short' }) : 'Tanpa tenggat';
    const badgeClass = t.priority === 'Tinggi' ? 'badge-danger' : t.priority === 'Sedang' ? 'badge-amber' : 'badge-indigo';
    return `
      <div class="task-mini-item ${t.completed ? 'completed' : ''}" data-id="${t.id}">
        <div style="display: flex; align-items: center; min-width: 0;">
          <div class="task-checkbox ${t.completed ? 'checked' : ''}" onclick="window.DaysaanuToggleTask(${t.id})">
            ${t.completed ? '✓' : ''}
          </div>
          <div style="min-width: 0;">
            <div class="task-title font-medium text-sm truncate">${escapeHtml(t.title)}</div>
            <div class="text-xs text-muted">${t.category} • ${isDue}</div>
          </div>
        </div>
        <span class="badge ${badgeClass}" style="flex-shrink: 0;">${t.priority}</span>
      </div>
    `;
  }).join('');
}

// Window handler for task toggle in dashboard
window.DaysaanuToggleTask = async (taskId) => {
  try {
    await api.tasks.toggle(taskId);
    showToast('Status tugas diperbarui!', 'success');
    loadDashboardData();
  } catch (err) {
    showToast('Gagal mengubah status tugas.', 'error');
  }
};

// Render Habits List with interactive check-in
function renderHabitsList(habits) {
  const container = document.getElementById('dashboard-habits-list');
  if (!container) return;

  if (!habits || habits.length === 0) {
    container.innerHTML = `
      <div class="empty-state" style="padding: 24px;">
        <div class="empty-state-title" style="font-size: 1rem;">Belum ada kebiasaan</div>
        <div class="empty-state-desc" style="font-size: 0.85rem; margin-bottom: 0;">Bangun konsistensi dengan kebiasaan kecil.</div>
      </div>
    `;
    return;
  }

  container.innerHTML = habits.map(h => {
    return `
      <div class="task-mini-item" style="border-left: 3px solid ${h.color || '#4F46E5'};">
        <div style="display: flex; align-items: center; min-width: 0;">
          <div class="task-checkbox ${h.completedToday ? 'checked' : ''}" onclick="window.DaysaanuToggleHabit(${h.id})">
            ${h.completedToday ? '✓' : ''}
          </div>
          <div style="min-width: 0;">
            <div class="font-medium text-sm truncate">${escapeHtml(h.name)}</div>
            <div class="text-xs text-muted">${h.category}</div>
          </div>
        </div>
        <span class="badge ${h.completedToday ? 'badge-success' : 'badge-violet'}">
          ${h.completedToday ? 'Selesai Hari Ini' : 'Belum Check-in'}
        </span>
      </div>
    `;
  }).join('');
}

// Window handler for habit toggle in dashboard
window.DaysaanuToggleHabit = async (habitId) => {
  try {
    const res = await api.habits.toggleCheck(habitId);
    showToast(res.message, 'success');
    loadDashboardData();
  } catch (err) {
    showToast('Gagal mencatat kebiasaan.', 'error');
  }
};

// Quick Note Form in Dashboard
function setupQuickNote() {
  const form = document.getElementById('quick-note-form');
  const input = document.getElementById('quick-note-input');
  if (!form || !input) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const content = input.value.trim();
    if (!content) {
      showToast('Tulis isi catatan terlebih dahulu.', 'error');
      return;
    }

    const firstLine = content.split('\n')[0].substring(0, 40);
    const title = firstLine || 'Catatan Cepat';

    try {
      await api.notes.create({
        title,
        content,
        category: 'Ide',
        is_pinned: false
      });
      showToast('Catatan cepat tersimpan di buku catatan!', 'success');
      input.value = '';
    } catch (err) {
      showToast('Gagal menyimpan catatan.', 'error');
    }
  });
}
