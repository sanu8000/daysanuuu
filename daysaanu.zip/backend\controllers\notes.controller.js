import { query } from '../config/db.js';

export async function getNotes(req, res) {
  try {
    const userId = req.user.id;
    const { category, search, pinned_only } = req.query;

    let sql = `SELECT * FROM notes WHERE user_id = $1`;
    const params = [userId];
    let idx = 2;

    if (category && category !== 'Semua') {
      sql += ` AND category = $${idx}`;
      params.push(category);
      idx++;
    }

    if (pinned_only === 'true') {
      sql += ` AND is_pinned = true`;
    }

    if (search && search.trim()) {
      sql += ` AND (title ILIKE $${idx} OR content ILIKE $${idx})`;
      params.push(`%${search.trim()}%`);
      idx++;
    }

    sql += ` ORDER BY is_pinned DESC, updated_at DESC, id DESC`;

    const result = await query(sql, params);
    return res.json({ success: true, notes: result.rows });
  } catch (err) {
    console.error('getNotes error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat daftar catatan.' });
  }
}

export async function createNote(req, res) {
  try {
    const userId = req.user.id;
    const { title, content, category, is_pinned } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Judul catatan wajib diisi.' });
    }

    const result = await query(
      `INSERT INTO notes (user_id, title, content, category, is_pinned)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [
        userId,
        title.trim(),
        content ? content.trim() : '',
        category || 'Pribadi',
        is_pinned || false
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Catatan berhasil disimpan.',
      note: result.rows[0]
    });
  } catch (err) {
    console.error('createNote error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menyimpan catatan.' });
  }
}

export async function updateNote(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { title, content, category, is_pinned } = req.body;

    const check = await query('SELECT * FROM notes WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Catatan tidak ditemukan.' });
    }

    const current = check.rows[0];
    const result = await query(
      `UPDATE notes
       SET title = $1, content = $2, category = $3, is_pinned = $4, updated_at = CURRENT_TIMESTAMP
       WHERE id = $5 AND user_id = $6 RETURNING *`,
      [
        title !== undefined ? title.trim() : current.title,
        content !== undefined ? content : current.content,
        category || current.category,
        is_pinned !== undefined ? is_pinned : current.is_pinned,
        id,
        userId
      ]
    );

    return res.json({
      success: true,
      message: 'Catatan berhasil diperbarui.',
      note: result.rows[0]
    });
  } catch (err) {
    console.error('updateNote error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui catatan.' });
  }
}

export async function togglePinNote(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const check = await query('SELECT is_pinned FROM notes WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Catatan tidak ditemukan.' });
    }

    const newPinned = !check.rows[0].is_pinned;
    const result = await query(
      `UPDATE notes SET is_pinned = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 AND user_id = $3 RETURNING *`,
      [newPinned, id, userId]
    );

    return res.json({
      success: true,
      message: newPinned ? 'Catatan disematkan di atas.' : 'Catatan dilepas dari sematan.',
      note: result.rows[0]
    });
  } catch (err) {
    console.error('togglePinNote error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mengubah status sematan catatan.' });
  }
}

export async function deleteNote(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM notes WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Catatan tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Catatan berhasil dihapus.' });
  } catch (err) {
    console.error('deleteNote error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus catatan.' });
  }
}
