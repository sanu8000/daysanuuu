import { query } from '../config/db.js';

export async function getTasks(req, res) {
  try {
    const userId = req.user.id;
    const { view, category, priority, search, sort } = req.query;

    let sql = `
      SELECT t.*, c.name as course_name, c.color as course_color
      FROM tasks t
      LEFT JOIN courses c ON t.course_id = c.id
      WHERE t.user_id = $1
    `;
    const params = [userId];
    let paramIndex = 2;

    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayEnd = new Date();
    todayEnd.setHours(23, 59, 59, 999);

    if (view === 'hari_ini') {
      sql += ` AND t.deadline >= $${paramIndex} AND t.deadline <= $${paramIndex + 1}`;
      params.push(todayStart.toISOString(), todayEnd.toISOString());
      paramIndex += 2;
    } else if (view === 'mendatang') {
      sql += ` AND t.deadline > $${paramIndex} AND t.completed = false`;
      params.push(todayEnd.toISOString());
      paramIndex += 1;
    } else if (view === 'terlambat') {
      sql += ` AND t.deadline < $${paramIndex} AND t.completed = false`;
      params.push(new Date().toISOString());
      paramIndex += 1;
    } else if (view === 'selesai') {
      sql += ` AND t.completed = true`;
    }

    if (category && category !== 'Semua') {
      sql += ` AND t.category = $${paramIndex}`;
      params.push(category);
      paramIndex += 1;
    }

    if (priority && priority !== 'Semua') {
      sql += ` AND t.priority = $${paramIndex}`;
      params.push(priority);
      paramIndex += 1;
    }

    if (search && search.trim()) {
      sql += ` AND (t.title ILIKE $${paramIndex} OR t.description ILIKE $${paramIndex})`;
      params.push(`%${search.trim()}%`);
      paramIndex += 1;
    }

    if (sort === 'priority') {
      sql += ` ORDER BY CASE t.priority WHEN 'Tinggi' THEN 1 WHEN 'Sedang' THEN 2 WHEN 'Rendah' THEN 3 ELSE 4 END ASC, t.deadline ASC NULLS LAST`;
    } else if (sort === 'deadline_asc') {
      sql += ` ORDER BY t.deadline ASC NULLS LAST`;
    } else if (sort === 'deadline_desc') {
      sql += ` ORDER BY t.deadline DESC NULLS LAST`;
    } else if (sort === 'title') {
      sql += ` ORDER BY t.title ASC`;
    } else {
      sql += ` ORDER BY t.completed ASC, t.deadline ASC NULLS LAST, t.id DESC`;
    }

    const result = await query(sql, params);
    return res.json({ success: true, tasks: result.rows });
  } catch (err) {
    console.error('getTasks error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memuat daftar tugas.' });
  }
}

export async function createTask(req, res) {
  try {
    const userId = req.user.id;
    const { title, description, priority, category, deadline, reminder, recurring, course_id } = req.body;

    if (!title || !title.trim()) {
      return res.status(400).json({ success: false, message: 'Judul tugas wajib diisi.' });
    }

    const result = await query(
      `INSERT INTO tasks (user_id, course_id, title, description, priority, category, deadline, reminder, recurring, completed)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, false) RETURNING *`,
      [
        userId,
        course_id ? parseInt(course_id, 10) : null,
        title.trim(),
        description ? description.trim() : '',
        priority || 'Sedang',
        category || 'Pribadi',
        deadline ? new Date(deadline).toISOString() : null,
        reminder ? new Date(reminder).toISOString() : null,
        recurring || 'none'
      ]
    );

    return res.status(201).json({
      success: true,
      message: 'Tugas berhasil ditambahkan.',
      task: result.rows[0]
    });
  } catch (err) {
    console.error('createTask error:', err);
    return res.status(500).json({ success: false, message: 'Data tugas belum berhasil disimpan.' });
  }
}

export async function updateTask(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;
    const { title, description, priority, category, deadline, reminder, recurring, course_id, completed } = req.body;

    const check = await query('SELECT * FROM tasks WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Tugas tidak ditemukan.' });
    }

    const current = check.rows[0];
    const isCompleted = completed !== undefined ? completed : current.completed;
    const completedAt = isCompleted && !current.completed ? new Date().toISOString() : (isCompleted ? current.completed_at : null);

    const result = await query(
      `UPDATE tasks
       SET title = $1, description = $2, priority = $3, category = $4, deadline = $5, reminder = $6,
           recurring = $7, course_id = $8, completed = $9, completed_at = $10, updated_at = CURRENT_TIMESTAMP
       WHERE id = $11 AND user_id = $12 RETURNING *`,
      [
        title !== undefined ? title.trim() : current.title,
        description !== undefined ? description : current.description,
        priority || current.priority,
        category || current.category,
        deadline !== undefined ? (deadline ? new Date(deadline).toISOString() : null) : current.deadline,
        reminder !== undefined ? (reminder ? new Date(reminder).toISOString() : null) : current.reminder,
        recurring || current.recurring,
        course_id !== undefined ? (course_id ? parseInt(course_id, 10) : null) : current.course_id,
        isCompleted,
        completedAt,
        id,
        userId
      ]
    );

    return res.json({
      success: true,
      message: 'Tugas berhasil diperbarui.',
      task: result.rows[0]
    });
  } catch (err) {
    console.error('updateTask error:', err);
    return res.status(500).json({ success: false, message: 'Gagal memperbarui tugas.' });
  }
}

export async function toggleTask(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const check = await query('SELECT * FROM tasks WHERE id = $1 AND user_id = $2', [id, userId]);
    if (check.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Tugas tidak ditemukan.' });
    }

    const current = check.rows[0];
    const newStatus = !current.completed;
    const completedAt = newStatus ? new Date().toISOString() : null;

    const result = await query(
      `UPDATE tasks SET completed = $1, completed_at = $2, updated_at = CURRENT_TIMESTAMP
       WHERE id = $3 AND user_id = $4 RETURNING *`,
      [newStatus, completedAt, id, userId]
    );

    return res.json({
      success: true,
      message: newStatus ? 'Selamat! Tugas selesai dikerjakan.' : 'Status tugas dikembalikan ke aktif.',
      task: result.rows[0]
    });
  } catch (err) {
    console.error('toggleTask error:', err);
    return res.status(500).json({ success: false, message: 'Gagal mengubah status tugas.' });
  }
}

export async function deleteTask(req, res) {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const result = await query('DELETE FROM tasks WHERE id = $1 AND user_id = $2 RETURNING id', [id, userId]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Tugas tidak ditemukan.' });
    }

    return res.json({ success: true, message: 'Tugas berhasil dihapus.' });
  } catch (err) {
    console.error('deleteTask error:', err);
    return res.status(500).json({ success: false, message: 'Gagal menghapus tugas.' });
  }
}
