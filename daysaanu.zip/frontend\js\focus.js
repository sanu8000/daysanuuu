// Daysaanu Pomodoro Focus Timer Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  formatDateIndonesian,
  escapeHtml
} from './components.js';

let focusMinutes = 25;
let breakMinutes = 5;
let mode = 'focus'; // 'focus' | 'break'
let totalDurationSeconds = focusMinutes * 60;
let remainingSeconds = totalDurationSeconds;
let isRunning = false;
let timerInterval = null;

const CIRCUMFERENCE = 879.64; // 2 * PI * 140

document.addEventListener('DOMContentLoaded', async () => {
  initAppShell('focus');
  setupEventListeners();
  await loadTasksDropdown();
  await loadFocusStats();
  updateTimerDisplay();
});

function setupEventListeners() {
  // Presets
  document.querySelectorAll('.preset-btn').forEach(btn => {
    if (btn.id === 'custom-preset-btn') {
      btn.addEventListener('click', handleCustomPreset);
    } else {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        focusMinutes = parseInt(btn.dataset.focus, 10);
        breakMinutes = parseInt(btn.dataset.break, 10);
        resetTimer();
      });
    }
  });

  // Controls
  document.getElementById('btn-play-pause')?.addEventListener('click', togglePlayPause);
  document.getElementById('btn-reset-timer')?.addEventListener('click', resetTimer);
  document.getElementById('btn-skip-timer')?.addEventListener('click', skipSession);
}

function handleCustomPreset() {
  const customFocus = prompt('Masukkan durasi fokus dalam menit (contoh: 40):', '40');
  if (!customFocus || isNaN(customFocus)) return;
  const fMins = parseInt(customFocus, 10);
  if (fMins <= 0 || fMins > 180) {
    showToast('Durasi harus antara 1 sampai 180 menit.', 'error');
    return;
  }

  const customBreak = prompt('Masukkan durasi istirahat dalam menit (contoh: 8):', '8');
  const bMins = parseInt(customBreak, 10) || 5;

  document.querySelectorAll('.preset-btn').forEach(b => b.classList.remove('active'));
  document.getElementById('custom-preset-btn').classList.add('active');
  focusMinutes = fMins;
  breakMinutes = bMins;
  resetTimer();
}

async function loadTasksDropdown() {
  try {
    const res = await api.tasks.getAll({ view: 'semua' });
    if (res.success && res.tasks) {
      const select = document.getElementById('focus-task-select');
      if (select) {
        select.innerHTML = '<option value="">(Fokus Bebas / Eksplorasi Mandiri)</option>' +
          res.tasks.filter(t => !t.completed).map(t => `<option value="${t.id}">${escapeHtml(t.title)}</option>`).join('');
      }
    }
  } catch (err) {
    console.error('Failed loading tasks for focus:', err);
  }
}

async function loadFocusStats() {
  try {
    const res = await api.focus.getStats();
    if (!res.success) return;

    const { stats, recentSessions } = res;
    document.getElementById('stat-today-mins').textContent = `${stats.todayMinutes} menit`;
    document.getElementById('stat-today-sessions').textContent = `${stats.todaySessions} sesi`;
    document.getElementById('stat-week-mins').textContent = `${stats.weekMinutes} menit`;
    document.getElementById('stat-week-sessions').textContent = `${stats.weekSessions} sesi`;
    document.getElementById('stat-total-mins').textContent = `${stats.totalMinutes} menit`;
    document.getElementById('stat-total-sessions').textContent = `${stats.totalSessions} sesi`;

    renderHistory(recentSessions);
  } catch (err) {
    console.error('Failed loading focus stats:', err);
  }
}

function renderHistory(sessions) {
  const container = document.getElementById('focus-history-list');
  if (!container) return;

  if (!sessions || sessions.length === 0) {
    container.innerHTML = `
      <div style="padding: 16px; text-align: center; color: var(--text-tertiary); font-size: 0.88rem;">
        Belum ada sesi fokus yang diselesaikan. Mulai sesi pertamamu sekarang!
      </div>
    `;
    return;
  }

  container.innerHTML = sessions.map(s => {
    const d = new Date(s.completed_at);
    return `
      <div style="display: flex; justify-content: space-between; align-items: center; padding: 10px 12px; border-bottom: 1px solid var(--border-subtle);">
        <div>
          <div class="font-semibold text-sm">
            ${s.session_type === 'focus' ? '🎯 Sesi Fokus Penuh' : '☕ Sesi Istirahat'}
            ${s.task_title ? `<span class="text-xs text-indigo" style="margin-left: 6px;">[${escapeHtml(s.task_title)}]</span>` : ''}
          </div>
          <div class="text-xs text-muted">
            ${formatDateIndonesian(d)} • ${d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
        <span class="badge badge-indigo font-bold">${s.duration_minutes} menit</span>
      </div>
    `;
  }).join('');
}

function togglePlayPause() {
  if (isRunning) {
    pauseTimer();
  } else {
    startTimer();
  }
}

function startTimer() {
  if (isRunning) return;
  isRunning = true;
  document.getElementById('btn-play-pause').textContent = '⏸';
  document.getElementById('btn-play-pause').title = 'Jeda';

  timerInterval = setInterval(() => {
    remainingSeconds--;
    updateTimerDisplay();

    if (remainingSeconds <= 0) {
      clearInterval(timerInterval);
      isRunning = false;
      handleSessionComplete();
    }
  }, 1000);
}

function pauseTimer() {
  isRunning = false;
  clearInterval(timerInterval);
  document.getElementById('btn-play-pause').textContent = '▶';
  document.getElementById('btn-play-pause').title = 'Mulai';
}

function resetTimer() {
  pauseTimer();
  mode = 'focus';
  totalDurationSeconds = focusMinutes * 60;
  remainingSeconds = totalDurationSeconds;
  document.getElementById('timer-mode-label').textContent = 'Fokus Penuh';
  updateTimerDisplay();
}

function skipSession() {
  pauseTimer();
  if (mode === 'focus') {
    mode = 'break';
    totalDurationSeconds = breakMinutes * 60;
    remainingSeconds = totalDurationSeconds;
    document.getElementById('timer-mode-label').textContent = 'Istirahat Sejenak';
    showToast('Beralih ke waktu istirahat ☕', 'info');
  } else {
    mode = 'focus';
    totalDurationSeconds = focusMinutes * 60;
    remainingSeconds = totalDurationSeconds;
    document.getElementById('timer-mode-label').textContent = 'Fokus Penuh';
    showToast('Beralih ke sesi fokus 🎯', 'info');
  }
  updateTimerDisplay();
}

function updateTimerDisplay() {
  const mins = Math.floor(remainingSeconds / 60);
  const secs = remainingSeconds % 60;
  const timeStr = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;

  document.getElementById('timer-digits').textContent = timeStr;
  document.title = `${timeStr} - Daysaanu Fokus`;

  // Ring progress
  const ring = document.getElementById('timer-progress-ring');
  if (ring && totalDurationSeconds > 0) {
    const progressRatio = (totalDurationSeconds - remainingSeconds) / totalDurationSeconds;
    const offset = CIRCUMFERENCE * progressRatio;
    ring.style.strokeDashoffset = offset;
  }
}

async function handleSessionComplete() {
  playChime();
  document.getElementById('btn-play-pause').textContent = '▶';

  if (mode === 'focus') {
    const selectedTaskId = document.getElementById('focus-task-select')?.value;
    try {
      await api.focus.logSession({
        duration_minutes: focusMinutes,
        task_id: selectedTaskId || null,
        session_type: 'focus'
      });
      showToast('🎉 Sesi fokus selesai! Kerja luar biasa, istirahat sejenak.', 'success');
      loadFocusStats();
    } catch (err) {
      console.error(err);
    }

    // Switch to break
    mode = 'break';
    totalDurationSeconds = breakMinutes * 60;
    remainingSeconds = totalDurationSeconds;
    document.getElementById('timer-mode-label').textContent = 'Istirahat Sejenak';
    updateTimerDisplay();
  } else {
    showToast('Waktu istirahat selesai! Siap untuk sesi fokus berikutnya? 🚀', 'info');
    mode = 'focus';
    totalDurationSeconds = focusMinutes * 60;
    remainingSeconds = totalDurationSeconds;
    document.getElementById('timer-mode-label').textContent = 'Fokus Penuh';
    updateTimerDisplay();
  }
}

// Zero-dependency pleasant chime sound via Web Audio API
function playChime() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5 note
    osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.4); // A5

    gain.gain.setValueAtTime(0.3, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 1.2);
  } catch (err) {
    console.warn('Audio not allowed or supported:', err);
  }
}
