import express from 'express';
import { getStatistics } from '../controllers/statistics.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/', getStatistics);

export default router;
