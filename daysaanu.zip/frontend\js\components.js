import { api, getToken, getCurrentUser, setCurrentUser } from './api.js';

// SVG Icon Library (Clean iOS / Feather style)
export const icons = {
  dashboard: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/></svg>`,
  tasks: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>`,
  schedule: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>`,
  focus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  habits: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>`,
  finance: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>`,
  notes: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`,
  goals: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>`,
  calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
  statistics: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`,
  settings: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-2 2 2 2 0 01-2-2v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 01-2-2 2 2 0 012-2h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 012-2 2 2 0 012 2v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 012 2 2 2 0 01-2 2h-.09a1.65 1.65 0 00-1.51 1z"/></svg>`,
  search: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  plus: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
  check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>`,
  x: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
  pin: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14l-2-7V4H7v6l-2 7z"/></svg>`,
  more: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>`,
  edit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
  trash: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>`,
  logout: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>`,
  bell: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg>`,
  arrowRight: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>`,
  sparkles: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3v3m0 12v3M3 12h3m12 0h3m-2.6-6.4l-2.1 2.1m-8.6 8.6l-2.1 2.1m0-12.8l2.1 2.1m8.6 8.6l2.1 2.1"/></svg>`
};

// Toast Notifications System
export function showToast(message, type = 'info', duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${type === 'success' ? '✨' : type === 'error' ? '⚠️' : 'ℹ️'}</span>
    <span class="toast-message">${escapeHtml(message)}</span>
  `;

  container.appendChild(toast);
  // Trigger animation
  requestAnimationFrame(() => toast.classList.add('show'));

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// Confirmation Dialog Modal
export function confirmDialog({ title, message, onConfirm, confirmText = 'Ya, Lanjutkan', danger = false }) {
  const existing = document.getElementById('confirm-modal');
  if (existing) existing.remove();

  const modal = document.createElement('div');
  modal.id = 'confirm-modal';
  modal.className = 'modal-overlay active';
  modal.innerHTML = `
    <div class="modal-content" style="max-width: 420px; text-align: center;">
      <div style="font-size: 2.2rem; margin-bottom: 12px;">${danger ? '⚠️' : '❓'}</div>
      <h3 style="margin-bottom: 8px;">${escapeHtml(title)}</h3>
      <p style="margin-bottom: 24px; color: var(--text-muted); font-size: 0.95rem;">${escapeHtml(message)}</p>
      <div style="display: flex; gap: 12px; justify-content: center;">
        <button id="confirm-cancel-btn" class="btn btn-secondary" style="flex: 1;">Batal</button>
        <button id="confirm-ok-btn" class="btn ${danger ? 'btn-danger' : 'btn-primary'}" style="flex: 1;">${escapeHtml(confirmText)}</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  modal.querySelector('#confirm-cancel-btn').addEventListener('click', () => modal.remove());
  modal.querySelector('#confirm-ok-btn').addEventListener('click', () => {
    modal.remove();
    if (typeof onConfirm === 'function') onConfirm();
  });
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

// Formatters
export function formatDateIndonesian(dateInput) {
  if (!dateInput) return '-';
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) return '-';
  const months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  const days = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
  return `${days[d.getDay()]}, ${d.getDate()} ${months[d.getMonth()]} ${d.getFullYear()}`;
}

export function formatTime(dateInput) {
  if (!dateInput) return '';
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}

export function formatCurrency(amount) {
  const num = parseFloat(amount) || 0;
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0
  }).format(num);
}

export function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// App Navigation Structure Definition
const NAV_ITEMS = [
  { id: 'dashboard', label: 'Dashboard', href: 'dashboard.html', icon: icons.dashboard },
  { id: 'tasks', label: 'Tugas', href: 'tasks.html', icon: icons.tasks },
  { id: 'schedule', label: 'Jadwal Kuliah', href: 'schedule.html', icon: icons.schedule },
  { id: 'focus', label: 'Fokus', href: 'focus.html', icon: icons.focus },
  { id: 'habits', label: 'Kebiasaan', href: 'habits.html', icon: icons.habits },
  { id: 'finance', label: 'Keuangan', href: 'finance.html', icon: icons.finance },
  { id: 'notes', label: 'Catatan', href: 'notes.html', icon: icons.notes },
  { id: 'goals', label: 'Target', href: 'goals.html', icon: icons.goals },
  { id: 'calendar', label: 'Kalender', href: 'calendar.html', icon: icons.calendar },
  { id: 'statistics', label: 'Statistik', href: 'statistics.html', icon: icons.statistics },
  { id: 'settings', label: 'Pengaturan', href: 'settings.html', icon: icons.settings }
];

// Initialize Full App Shell
export function initAppShell(activePageId = 'dashboard') {
  if (!getToken() && !window.location.pathname.endsWith('index.html') && window.location.pathname !== '/') {
    window.location.href = 'index.html';
    return;
  }

  const user = getCurrentUser() || { name: 'Salsa', email: 'salsa@daysaanu.local' };

  // 1. Inject 3D Floating Orb
  if (!document.querySelector('.orb-container')) {
    const orb = document.createElement('div');
    orb.className = 'orb-container';
    orb.innerHTML = `
      <div class="floating-orb">
        <div class="orb-ring"></div>
      </div>
    `;
    document.body.prepend(orb);
  }

  // 2. Render Desktop Sidebar
  let sidebar = document.querySelector('.sidebar');
  if (!sidebar) {
    sidebar = document.createElement('aside');
    sidebar.className = 'sidebar';
    document.querySelector('.app-container')?.prepend(sidebar);
  }

  if (sidebar) {
    sidebar.innerHTML = `
      <div class="sidebar-header">
        <a href="dashboard.html" class="sidebar-logo">
          <img src="assets/logo-icon.svg" width="34" height="34" alt="Daysaanu Logo" />
          <span><span style="color:var(--brand-indigo)">Days</span><span style="color:var(--brand-violet)">aanu</span></span>
        </a>
      </div>
      <nav class="sidebar-nav">
        ${NAV_ITEMS.map(item => `
          <a href="${item.href}" class="nav-item ${item.id === activePageId ? 'active' : ''}">
            ${item.icon}
            <span>${item.label}</span>
          </a>
        `).join('')}
      </nav>
      <div class="sidebar-footer">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
          <a href="settings.html" class="user-profile-pill" style="flex: 1; text-decoration: none;">
            <div class="user-avatar">${user.name.charAt(0).toUpperCase()}</div>
            <div style="min-width: 0; flex: 1;">
              <div class="font-semibold truncate" style="font-size: 0.9rem;">${escapeHtml(user.name)}</div>
              <div class="text-xs text-muted truncate">${escapeHtml(user.email)}</div>
            </div>
          </a>
          <button id="sidebar-logout-btn" class="btn btn-ghost btn-icon btn-sm" title="Keluar dari Akun" style="color: var(--text-tertiary); flex-shrink: 0;">
            ${icons.logout}
          </button>
        </div>
      </div>
    `;
    sidebar.querySelector('#sidebar-logout-btn')?.addEventListener('click', () => {
      confirmDialog({
        title: 'Keluar dari Daysaanu',
        message: 'Apakah Anda yakin ingin keluar dari sesi ini?',
        confirmText: 'Keluar',
        danger: true,
        onConfirm: () => api.auth.logout()
      });
    });
  }

  // 3. Render Mobile Header
  const mainContent = document.querySelector('.main-content');
  if (mainContent && !document.querySelector('.mobile-header')) {
    const mobileHeader = document.createElement('header');
    mobileHeader.className = 'mobile-header';
    mobileHeader.innerHTML = `
      <a href="dashboard.html" class="mobile-logo">
        <img src="assets/logo-icon.svg" width="28" height="28" alt="Daysaanu" />
        <span>Daysaanu</span>
      </a>
      <div style="display: flex; gap: 8px; align-items: center;">
        <button class="btn btn-secondary btn-icon" id="mobile-search-btn" title="Cari (Ctrl+K)">
          ${icons.search}
        </button>
        <a href="settings.html" class="user-avatar" style="width: 32px; height: 32px; font-size: 0.85rem;">
          ${user.name.charAt(0).toUpperCase()}
        </a>
      </div>
    `;
    mainContent.prepend(mobileHeader);
    mobileHeader.querySelector('#mobile-search-btn')?.addEventListener('click', openCommandPalette);
  }

  // 4. Render Mobile Bottom Navigation & "Lainnya" Menu
  if (!document.querySelector('.bottom-nav')) {
    const bottomNav = document.createElement('nav');
    bottomNav.className = 'bottom-nav';
    bottomNav.innerHTML = `
      <a href="dashboard.html" class="bottom-nav-item ${activePageId === 'dashboard' ? 'active' : ''}">
        ${icons.dashboard}
        <span>Beranda</span>
      </a>
      <a href="tasks.html" class="bottom-nav-item ${activePageId === 'tasks' ? 'active' : ''}">
        ${icons.tasks}
        <span>Tugas</span>
      </a>
      <a href="schedule.html" class="bottom-nav-item ${activePageId === 'schedule' ? 'active' : ''}">
        ${icons.schedule}
        <span>Jadwal</span>
      </a>
      <a href="focus.html" class="bottom-nav-item ${activePageId === 'focus' ? 'active' : ''}">
        ${icons.focus}
        <span>Fokus</span>
      </a>
      <button class="bottom-nav-item" id="more-menu-btn" style="background: none; border: none; cursor: pointer;">
        ${icons.more}
        <span>Lainnya</span>
      </button>
    `;
    document.body.appendChild(bottomNav);

    bottomNav.querySelector('#more-menu-btn')?.addEventListener('click', openMoreDrawer);
  }

  // 5. Render Floating Action Button (FAB)
  if (!document.querySelector('.fab-container')) {
    const fabContainer = document.createElement('div');
    fabContainer.className = 'fab-container';
    fabContainer.innerHTML = `
      <div class="fab-menu">
        <div class="fab-menu-item" data-action="tugas">${icons.tasks} Tambah Tugas</div>
        <div class="fab-menu-item" data-action="catatan">${icons.notes} Tambah Catatan</div>
        <div class="fab-menu-item" data-action="keuangan">${icons.finance} Catat Keuangan</div>
        <div class="fab-menu-item" data-action="jadwal">${icons.schedule} Tambah Mata Kuliah</div>
        <div class="fab-menu-item" data-action="kebiasaan">${icons.habits} Tambah Kebiasaan</div>
        <div class="fab-menu-item" data-action="target">${icons.goals} Tambah Target</div>
      </div>
      <button class="fab-main-btn" id="fab-toggle-btn" title="Aksi Cepat">
        ${icons.plus}
      </button>
    `;
    document.body.appendChild(fabContainer);

    const toggleBtn = fabContainer.querySelector('#fab-toggle-btn');
    toggleBtn.addEventListener('click', () => {
      fabContainer.classList.toggle('active');
      toggleBtn.classList.toggle('active');
    });

    fabContainer.querySelectorAll('.fab-menu-item').forEach(item => {
      item.addEventListener('click', (e) => {
        fabContainer.classList.remove('active');
        toggleBtn.classList.remove('active');
        handleQuickAction(item.dataset.action);
      });
    });
  }

  // 6. Mount Global Command Palette (Ctrl+K)
  setupCommandPalette();

  // 7. Apply saved preferences (Theme, reduced motion)
  applySavedPreferences();
}

// More Menu Drawer for Mobile
function openMoreDrawer() {
  const existing = document.getElementById('more-drawer-modal');
  if (existing) { existing.remove(); return; }

  const modal = document.createElement('div');
  modal.id = 'more-drawer-modal';
  modal.className = 'modal-overlay active';
  modal.innerHTML = `
    <div class="modal-content" style="max-width: 380px;">
      <div class="modal-header">
        <h3 class="card-title">Menu Lainnya</h3>
        <button class="modal-close-btn" id="drawer-close-btn">${icons.x}</button>
      </div>
      <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-top: 10px;">
        <a href="habits.html" class="btn btn-secondary" style="padding: 14px 10px; justify-content: flex-start;">${icons.habits} Kebiasaan</a>
        <a href="finance.html" class="btn btn-secondary" style="padding: 14px 10px; justify-content: flex-start;">${icons.finance} Keuangan</a>
        <a href="notes.html" class="btn btn-secondary" style="padding: 14px 10px; justify-content: flex-start;">${icons.notes} Catatan</a>
        <a href="goals.html" class="btn btn-secondary" style="padding: 14px 10px; justify-content: flex-start;">${icons.goals} Target</a>
        <a href="calendar.html" class="btn btn-secondary" style="padding: 14px 10px; justify-content: flex-start;">${icons.calendar} Kalender</a>
        <a href="statistics.html" class="btn btn-secondary" style="padding: 14px 10px; justify-content: flex-start;">${icons.statistics} Statistik</a>
      </div>
      <div style="margin-top: 16px; padding-top: 14px; border-top: 1px solid var(--border-subtle); display: flex; flex-direction: column; gap: 8px;">
        <a href="settings.html" class="btn btn-secondary" style="justify-content: flex-start;">${icons.settings} Pengaturan</a>
        <button id="logout-btn" class="btn btn-ghost" style="color: var(--status-danger); justify-content: flex-start;">Keluar dari Akun</button>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  modal.querySelector('#drawer-close-btn').addEventListener('click', () => modal.remove());
  modal.querySelector('#logout-btn').addEventListener('click', () => {
    confirmDialog({
      title: 'Keluar dari Daysaanu',
      message: 'Apakah Anda yakin ingin keluar dari sesi ini?',
      confirmText: 'Keluar',
      danger: true,
      onConfirm: () => api.auth.logout()
    });
  });
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
}

// Quick Action FAB Handlers
function handleQuickAction(action) {
  switch (action) {
    case 'tugas':
      if (window.location.pathname.endsWith('tasks.html')) {
        document.getElementById('open-create-task-modal')?.click();
      } else {
        window.location.href = 'tasks.html?action=create';
      }
      break;
    case 'catatan':
      if (window.location.pathname.endsWith('notes.html')) {
        document.getElementById('open-create-note-modal')?.click();
      } else {
        window.location.href = 'notes.html?action=create';
      }
      break;
    case 'keuangan':
      if (window.location.pathname.endsWith('finance.html')) {
        document.getElementById('open-create-tx-modal')?.click();
      } else {
        window.location.href = 'finance.html?action=create';
      }
      break;
    case 'jadwal':
      if (window.location.pathname.endsWith('schedule.html')) {
        document.getElementById('open-create-course-modal')?.click();
      } else {
        window.location.href = 'schedule.html?action=create';
      }
      break;
    case 'kebiasaan':
      if (window.location.pathname.endsWith('habits.html')) {
        document.getElementById('open-create-habit-modal')?.click();
      } else {
        window.location.href = 'habits.html?action=create';
      }
      break;
    case 'target':
      if (window.location.pathname.endsWith('goals.html')) {
        document.getElementById('open-create-goal-modal')?.click();
      } else {
        window.location.href = 'goals.html?action=create';
      }
      break;
  }
}

// Command Palette (Ctrl+K)
function setupCommandPalette() {
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      openCommandPalette();
    }
    if (e.key === 'Escape') {
      closeCommandPalette();
    }
  });
}

export function openCommandPalette() {
  let modal = document.getElementById('palette-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'palette-modal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-content command-palette">
        <div class="palette-input-wrapper">
          <span style="color: var(--brand-indigo);">${icons.search}</span>
          <input type="text" class="palette-input" id="palette-search-input" placeholder="Ketik untuk mencari tugas, catatan, jadwal, target..." autocomplete="off" />
          <button class="modal-close-btn" id="palette-close-btn">${icons.x}</button>
        </div>
        <div class="palette-results" id="palette-results-container">
          <div style="padding: 24px; text-align: center; color: var(--text-tertiary); font-size: 0.9rem;">
            Ketik minimal 2 karakter untuk memulai pencarian di seluruh Daysaanu
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('#palette-close-btn').addEventListener('click', closeCommandPalette);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeCommandPalette();
    });

    const searchInput = modal.querySelector('#palette-search-input');
    let debounceTimer = null;
    searchInput.addEventListener('input', (e) => {
      clearTimeout(debounceTimer);
      const val = e.target.value.trim();
      if (val.length < 2) {
        modal.querySelector('#palette-results-container').innerHTML = `
          <div style="padding: 24px; text-align: center; color: var(--text-tertiary); font-size: 0.9rem;">
            Ketik minimal 2 karakter untuk memulai pencarian di seluruh Daysaanu
          </div>
        `;
        return;
      }
      debounceTimer = setTimeout(() => executePaletteSearch(val), 250);
    });
  }

  modal.classList.add('active');
  const input = modal.querySelector('#palette-search-input');
  input.value = '';
  input.focus();
}

function closeCommandPalette() {
  document.getElementById('palette-modal')?.classList.remove('active');
}

async function executePaletteSearch(query) {
  const container = document.getElementById('palette-results-container');
  if (!container) return;

  container.innerHTML = `<div style="padding: 24px; text-align: center; color: var(--text-tertiary);">Mencari data...</div>`;
  try {
    const res = await api.search.query(query);
    const { results } = res;

    let html = '';
    let totalFound = 0;

    // Tasks
    if (results.tasks?.length > 0) {
      totalFound += results.tasks.length;
      html += `<div class="palette-group-title">Tugas</div>`;
      results.tasks.forEach(t => {
        html += `
          <div class="palette-item" onclick="window.location.href='tasks.html'">
            <div>
              <div class="font-medium ${t.completed ? 'text-muted' : ''}">${escapeHtml(t.title)}</div>
              <div class="text-xs text-muted">${t.category} • Prioritas ${t.priority}</div>
            </div>
            <span class="badge ${t.completed ? 'badge-success' : 'badge-indigo'}">${t.completed ? 'Selesai' : 'Aktif'}</span>
          </div>
        `;
      });
    }

    // Notes
    if (results.notes?.length > 0) {
      totalFound += results.notes.length;
      html += `<div class="palette-group-title">Catatan</div>`;
      results.notes.forEach(n => {
        html += `
          <div class="palette-item" onclick="window.location.href='notes.html'">
            <div>
              <div class="font-medium">${escapeHtml(n.title)}</div>
              <div class="text-xs text-muted">${n.category}</div>
            </div>
            <span class="badge badge-violet">Catatan</span>
          </div>
        `;
      });
    }

    // Courses
    if (results.courses?.length > 0) {
      totalFound += results.courses.length;
      html += `<div class="palette-group-title">Mata Kuliah / Jadwal</div>`;
      results.courses.forEach(c => {
        html += `
          <div class="palette-item" onclick="window.location.href='schedule.html'">
            <div>
              <div class="font-medium">${escapeHtml(c.name)}</div>
              <div class="text-xs text-muted">${c.day_of_week} ${c.start_time} • ${c.room || 'Online'}</div>
            </div>
            <span class="badge badge-indigo">Kuliah</span>
          </div>
        `;
      });
    }

    // Goals
    if (results.goals?.length > 0) {
      totalFound += results.goals.length;
      html += `<div class="palette-group-title">Target & Sasaran</div>`;
      results.goals.forEach(g => {
        html += `
          <div class="palette-item" onclick="window.location.href='goals.html'">
            <div>
              <div class="font-medium">${escapeHtml(g.title)}</div>
              <div class="text-xs text-muted">${g.category} • ${g.status}</div>
            </div>
            <span class="badge badge-amber">Target</span>
          </div>
        `;
      });
    }

    if (totalFound === 0) {
      html = `
        <div style="padding: 32px 16px; text-align: center; color: var(--text-tertiary);">
          <div style="font-size: 1.5rem; margin-bottom: 6px;">🔍</div>
          <div>Tidak ditemukan hasil untuk "<strong>${escapeHtml(query)}</strong>"</div>
        </div>
      `;
    }

    container.innerHTML = html;
  } catch (err) {
    container.innerHTML = `<div style="padding: 20px; text-align: center; color: var(--status-danger);">Gagal mencari data. Silakan coba lagi.</div>`;
  }
}

// Apply Saved Preferences
function applySavedPreferences() {
  const theme = localStorage.getItem('daysaanu_theme') || 'system';
  if (theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.setAttribute('data-theme', 'dark');
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
  }

  const reducedMotion = localStorage.getItem('daysaanu_reduced_motion') === 'true';
  if (reducedMotion) {
    document.documentElement.setAttribute('data-reduced-motion', 'true');
  }
}
