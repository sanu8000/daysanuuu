import express from 'express';
import {
  getFinanceSummary,
  getTransactions,
  createTransaction,
  deleteTransaction,
  updateBudget
} from '../controllers/finance.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/summary', getFinanceSummary);
router.get('/transactions', getTransactions);
router.post('/transactions', createTransaction);
router.delete('/transactions/:id', deleteTransaction);
router.put('/budget', updateBudget);

export default router;
