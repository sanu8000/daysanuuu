import express from 'express';
import {
  getSettings,
  updateSettings,
  updateProfile,
  exportData,
  deleteAccount
} from '../controllers/settings.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/', getSettings);
router.put('/', updateSettings);
router.put('/profile', updateProfile);
router.get('/export', exportData);
router.delete('/account', deleteAccount);

export default router;
