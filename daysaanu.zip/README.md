# Daysaanu (Days + Saanu)

> «“Make every day meaningful, organized, and easier to manage.”»

Daysaanu adalah ruang produktivitas digital pribadi (*private personal digital workspace*) yang dirancang khusus untuk kenyamanan, ketenangan, dan efisiensi harian. Mengusung gaya visual modern terinspirasi iOS dengan *soft glassmorphism*, permukaan translusen, sudut membulat elegan, tipografi bersih, dan palet warna Indigo, Violet, dan Amber.

Aplikasi ini dibangun secara *full-stack*, fungsional, dan ditulis seluruhnya dalam **Bahasa Indonesia**.

---

## 🌟 Fitur Utama

1. **Dashboard Pribadi (Salsa)**:
   - Sambutan hangat kontekstual: *"Selamat datang kembali, Salsa."*, *"Bagaimana harimu hari ini?"*
   - Jam digital & penanggalan dinamis Indonesia
   - Cincin progres ritme harian (*daily completion percentage*)
   - Kartu jadwal perkuliahan terdekat & tenggat tugas paling mendesak
   - Widget ringkasan sesi fokus, kebiasaan harian, dan keuangan
   - *Catatan Cepat* langsung dari dashboard

2. **Manajemen Tugas (Tugas)**:
   - Operasi CRUD lengkap dengan prioritas (*Tinggi, Sedang, Rendah*) & kategori (*Kuliah, Pribadi, Project, Organisasi, Lainnya*)
   - Tenggat waktu, pengingat, dan pengulangan tugas (*none, harian, mingguan, bulanan*)
   - Tab filter: *Semua, Hari Ini, Mendatang, Terlambat, Selesai*
   - Pencarian cepat dan pengurutan dinamis
   - Animasi penyelesaian tugas (*bounce check & strike-through*)

3. **Modul Perkuliahan & Jadwal (Jadwal)**:
   - Pengelolaan semester aktif dan riwayat semester mendatang
   - Jadwal mata kuliah lengkap: nama, dosen pengampu, SKS, hari & jam, ruangan, catatan, serta warna aksen
   - Terhubung langsung dengan sistem tugas (*menampilkan jumlah tugas aktif per mata kuliah*)
   - Pelacak jadwal ujian UTS, UAS, dan praktikum

4. **Mode Fokus (Fokus / Pomodoro)**:
   - Preset waktu: *25/5 Klasik*, *50/10 Deep Work*, dan *Kustom*
   - Kontrol: *Mulai, Jeda, Reset, Lewati*
   - Cincin timer melingkar beranimasi besar
   - Hubungkan sesi fokus dengan tugas tertentu
   - Audio lonceng relaksasi (*pleasant chime via Web Audio API*) saat sesi berakhir
   - Statistik riil: fokus hari ini, minggu ini, dan total sesi

5. **Pelacak Kebiasaan (Kebiasaan)**:
   - Kustomisasi penuh (nama, ikon emoji, target hari per minggu, warna)
   - Matriks check-in interaktif 7 hari terakhir
   - Penghitungan beruntun otomatis (*streak counter*)

6. **Keuangan Pribadi (Keuangan)**:
   - Catat pemasukan dan pengeluaran dengan kategori (*Makanan, Transportasi, Kuliah, Hiburan, Tabungan, Lainnya*)
   - Metrik otomatis: Total pemasukan, pengeluaran, saldo berjalan, dan sisa pagu anggaran
   - Diagram distribusi alokasi pengeluaran bulanan
   - Indikator progres target tabungan

7. **Buku Catatan (Catatan)**:
   - Editor bebas gangguan (*distraction-free writing*)
   - Sematkan catatan prioritas di atas (*Pin Note*)
   - Pengelompokan kategori dan pencarian waktu nyata

8. **Target & Sasaran (Target)**:
   - Sasaran besar dengan tanggal target dan status (*Sedang Berjalan, Tercapai, Ditunda*)
   - *Milestones*: Tahapan kecil yang dapat diselesaikan satu per satu dengan persentase progres dinamis

9. **Kalender Agenda (Kalender)**:
   - Tampilan *Bulan*, *Minggu*, dan *Hari*
   - Kategori acara: *Kuliah, Tugas, Ujian, Personal, Target*
   - Navigasi bulan sebelumnya, berikutnya, dan lompat ke hari ini

10. **Statistik Produktivitas (Statistik)**:
    - Metrik berbasis **100% data riil** yang tersimpan di basis data (tidak ada data buatan)
    - Wawasan produktivitas dinamis berbahasa Indonesia

11. **Pencarian Global (Ctrl + K)**:
    - *Command Palette* modern yang dapat diakses dengan tombol pintas `Ctrl + K` dari halaman manapun
    - Mencari lintas modul: tugas, catatan, jadwal kuliah, target, kebiasaan, dan transaksi keuangan

12. **Aksi Cepat (Floating Action Button)**:
    - Tombol melayang di pojok kanan bawah untuk menambah Tugas, Catatan, Jadwal, Pengeluaran, Kebiasaan, dan Target seketika

13. **Pengaturan & Personalisasi (Pengaturan)**:
    - Profil pengguna & ubah kata sandi
    - Pilihan tema: *Mode Terang, Mode Gelap, Otomatis Sistem*
    - Pengaturan *Reduced Motion*
    - Konfigurasi durasi bawaan Pomodoro
    - Izin notifikasi peramban (*Web Notifications*)
    - Ekspor data lengkap (*Backup JSON*) & Hapus akun permanen

---

## 🛠️ Arsitektur Teknologi

- **Frontend**:
  - HTML5 Semantik
  - CSS3 Modern (CSS Variables, Flexbox, Grid, iOS Glassmorphism, 3D CSS Transforms Orb)
  - Vanilla JavaScript ES Modules (Tanpa framework berat, ringan dan responsif)
- **Backend**:
  - Node.js (v18+)
  - Express.js (Arsitektur RESTful modular: *routes, controllers, config, middleware*)
  - JWT (*JSON Web Tokens*) untuk otentikasi aman
  - BcryptJS untuk hashing kata sandi aman
- **Database**:
  - PostgreSQL (Skema normalisasi lengkap dengan relasi foreign keys, indeks, dan timestamps)
  - Dilengkapi mesin PostgreSQL terintegrasi (*embedded persistent PGlite*) sehingga dapat langsung berjalan seketika (*zero-config*) tanpa memerlukan setup server postgres eksternal, dan langsung beralih ke PostgreSQL mandiri jika `DATABASE_URL` disediakan.

---

## 🚀 Panduan Instalasi & Menjalankan Aplikasi

### 1. Prasyarat
- Pastikan **Node.js** (v18 ke atas) dan **npm** telah terpasang di komputer Anda.

### 2. Kloning / Masuk ke Direktori Proyek
```bash
cd daysaanu
```

### 3. Pasang Dependensi
```bash
npm install
```

### 4. Konfigurasi Lingkungan (`.env`)
Salin berkas `.env.example` menjadi `.env`:
```bash
# Windows PowerShell:
Copy-Item .env.example .env

# Atau bash:
cp .env.example .env
```

Isi berkas `.env`:
```env
PORT=3000
NODE_ENV=development
JWT_SECRET=daysaanu_ultra_secure_jwt_secret_key_2026_salsa_workspace

# Opsional: Jika menghubungkan ke server PostgreSQL mandiri:
# DATABASE_URL=postgresql://postgres:postgres@localhost:5432/daysaanu
```

### 5. Menjalankan Server
```bash
# Mode Produksi:
npm start

# Mode Pengembangan (Auto-reload):
npm run dev
```

Buka peramban Anda di:
👉 **http://localhost:3000**

---

## 👤 Akun Demo Bawaan
Untuk mencoba seluruh fitur tanpa perlu mengisi data awal dari nol:
- **Email**: `salsa@daysaanu.local`
- **Kata Sandi**: `password123`
- Atau klik tombol **“✨ Masuk sebagai Salsa (Akun Demo)”** di halaman depan untuk akses instan 1-klik!

---

## 🧪 Menjalankan Pengujian Otomatis (E2E Test)
Untuk memverifikasi integritas API, isolasi data antar pengguna, dan seluruh modul:
```bash
node backend/test-suite.js
```

---

## 📁 Struktur Direktori
```text
daysaanu/
├── backend/
│   ├── config/
│   │   └── db.js              # Inisialisasi DB, skema DDL & seeding
│   ├── controllers/          # Logika bisnis REST API setiap modul
│   ├── middleware/
│   │   └── auth.js            # Verifikasi JWT token & isolasi user
│   ├── routes/                # Definisi endpoint RESTful API
│   ├── server.js              # Server Express utama & static server
│   └── test-suite.js          # Pengujian otomatis E2E
├── database/
│   ├── schema.sql             # Skema DDL PostgreSQL ternormalisasi
│   └── data_pg/               # Penyimpanan data persisten
├── frontend/
│   ├── assets/
│   │   ├── logo.svg           # Logo Daysaanu (Wordmark)
│   │   └── logo-icon.svg      # Ikon SVG Daysaanu
│   ├── css/
│   │   ├── variables.css      # Desain token warna & iOS spacing
│   │   ├── global.css         # Reset, mesh background, & 3D orb
│   │   ├── components.css     # Tombol, kartu glass, modal, FAB, toast
│   │   ├── dashboard.css      # Grid layout & widget hero
│   │   └── responsive.css     # Bottom nav & tata letak seluler
│   ├── js/
│   │   ├── api.js             # Client API sentral & manajemen token
│   │   ├── app.js             # Bootstrapper aplikasi
│   │   ├── auth.js            # Autentikasi masuk & daftar
│   │   ├── components.js      # App shell, modal, dialog, & toast
│   │   ├── dashboard.js       # Kontroler beranda & jam
│   │   ├── tasks.js           # Kontroler manajemen tugas
│   │   ├── schedule.js        # Kontroler jadwal kuliah & ujian
│   │   ├── focus.js           # Kontroler timer Pomodoro
│   │   ├── habits.js          # Kontroler pelacak kebiasaan
│   │   ├── finance.js         # Kontroler keuangan & anggaran
│   │   ├── notes.js           # Kontroler catatan pribadi
│   │   ├── goals.js           # Kontroler target & milestone
│   │   ├── calendar.js        # Kontroler kalender interaktif
│   │   ├── statistics.js      # Kontroler analitik data riil
│   │   └── settings.js        # Kontroler pengaturan profil & tema
│   ├── index.html             # Gerbang masuk / autentikasi
│   ├── dashboard.html         # Dashboard utama
│   ├── tasks.html             # Modul Tugas
│   ├── schedule.html          # Modul Kuliah & Jadwal
│   ├── focus.html             # Modul Pomodoro
│   ├── habits.html            # Modul Kebiasaan
│   ├── finance.html           # Modul Keuangan
│   ├── notes.html             # Modul Catatan
│   ├── goals.html             # Modul Target
│   ├── calendar.html          # Modul Kalender
│   ├── statistics.html        # Modul Statistik
│   └── settings.html          # Modul Pengaturan
├── .env.example
├── package.json
└── README.md
```

---

## 📄 Lisensi
Hak cipta © 2026 Daysaanu. Dibuat dengan penuh perhatian untuk pengalaman produktivitas harian yang tenang dan bermakna.
