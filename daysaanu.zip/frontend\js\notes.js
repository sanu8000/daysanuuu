// Daysaanu Personal Notes Interactive Script
import { api } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  formatDateIndonesian,
  escapeHtml,
  icons
} from './components.js';

let notesData = [];

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('notes');
  loadNotes();
  setupEventListeners();

  const params = new URLSearchParams(window.location.search);
  if (params.get('action') === 'create') {
    openNoteModal();
  }
});

function setupEventListeners() {
  document.getElementById('open-create-note-modal')?.addEventListener('click', () => openNoteModal());
  document.getElementById('note-modal-close-btn')?.addEventListener('click', closeNoteModal);
  document.getElementById('note-cancel-btn')?.addEventListener('click', closeNoteModal);
  document.getElementById('note-form')?.addEventListener('submit', handleNoteSubmit);

  // Filters
  document.getElementById('note-category-filter')?.addEventListener('change', loadNotes);

  let searchTimer = null;
  document.getElementById('note-search-input')?.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(loadNotes, 250);
  });
}

async function loadNotes() {
  const container = document.getElementById('notes-grid-container');
  if (!container) return;

  const category = document.getElementById('note-category-filter')?.value;
  const search = document.getElementById('note-search-input')?.value;

  container.innerHTML = `<div style="padding: 40px; text-align: center; color: var(--text-tertiary); grid-column: 1/-1;">Memuat catatan...</div>`;

  try {
    const res = await api.notes.getAll({ category, search });
    if (!res.success) throw new Error(res.message);

    notesData = res.notes || [];
    if (notesData.length === 0) {
      container.innerHTML = `
        <div class="empty-state" style="grid-column: 1/-1;">
          <div class="empty-state-icon">✍️</div>
          <div class="empty-state-title">Belum ada catatan ditemukan</div>
          <div class="empty-state-desc">Tangkap inspirasi, rangkuman ide atau tugas kuliah di sini.</div>
          <button class="btn btn-secondary btn-sm" onclick="window.DaysaanuOpenCreateNote()">+ Tulis Catatan Baru</button>
        </div>
      `;
      return;
    }

    container.innerHTML = notesData.map(n => {
      const d = new Date(n.updated_at || n.created_at);
      const isPinned = !!n.is_pinned;

      return `
        <div class="note-card ${isPinned ? 'pinned' : ''}" onclick="window.DaysaanuEditNote(${n.id})">
          <div>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;">
              <h3 class="font-bold text-base truncate" style="flex: 1;">${escapeHtml(n.title)}</h3>
              <div style="display: flex; gap: 4px; align-items: center;" onclick="event.stopPropagation();">
                <button class="btn btn-ghost btn-icon btn-sm" style="${isPinned ? 'color: var(--brand-amber);' : 'color: var(--text-tertiary);'}"
                        onclick="window.DaysaanuTogglePin(${n.id})" title="${isPinned ? 'Lepas Sematan' : 'Sematkan Catatan'}">
                  ${icons.pin}
                </button>
                <button class="btn btn-ghost btn-icon btn-sm" style="color: var(--status-danger);"
                        onclick="window.DaysaanuDeleteNote(${n.id})" title="Hapus">
                  ${icons.trash}
                </button>
              </div>
            </div>
            <p class="note-content-preview">${escapeHtml(n.content || '(Catatan kosong)')}</p>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 10px; border-top: 1px solid var(--border-subtle); font-size: 0.78rem; color: var(--text-tertiary);">
            <span class="badge badge-violet">${escapeHtml(n.category)}</span>
            <span>${d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' })}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    container.innerHTML = `<div style="padding: 24px; text-align: center; color: var(--status-danger); grid-column: 1/-1;">${escapeHtml(err.message)}</div>`;
  }
}

// Global actions
window.DaysaanuOpenCreateNote = () => openNoteModal();

window.DaysaanuEditNote = (id) => {
  const note = notesData.find(n => n.id === id);
  if (note) openNoteModal(note);
};

window.DaysaanuTogglePin = async (id) => {
  try {
    const res = await api.notes.togglePin(id);
    showToast(res.message, 'success');
    loadNotes();
  } catch (err) {
    showToast('Gagal mengubah sematan catatan.', 'error');
  }
};

window.DaysaanuDeleteNote = (id) => {
  confirmDialog({
    title: 'Hapus Catatan',
    message: 'Apakah Anda yakin ingin menghapus catatan ini?',
    confirmText: 'Hapus',
    danger: true,
    onConfirm: async () => {
      try {
        await api.notes.delete(id);
        showToast('Catatan berhasil dihapus.', 'success');
        loadNotes();
      } catch (err) {
        showToast('Gagal menghapus catatan.', 'error');
      }
    }
  });
};

function openNoteModal(note = null) {
  const modal = document.getElementById('note-modal');
  const form = document.getElementById('note-form');
  const title = document.getElementById('note-modal-title');

  form.reset();
  if (note) {
    title.textContent = 'Edit Catatan';
    document.getElementById('note-id').value = note.id;
    document.getElementById('note-title-input').value = note.title;
    document.getElementById('note-content-input').value = note.content || '';
    document.getElementById('note-category-input').value = note.category || 'Pribadi';
    document.getElementById('note-pinned-input').checked = !!note.is_pinned;
  } else {
    title.textContent = 'Tulis Catatan Baru';
    document.getElementById('note-id').value = '';
    document.getElementById('note-category-input').value = 'Kuliah';
    document.getElementById('note-pinned-input').checked = false;
  }

  modal.classList.add('active');
  document.getElementById('note-title-input').focus();
}

function closeNoteModal() {
  document.getElementById('note-modal')?.classList.remove('active');
}

async function handleNoteSubmit(e) {
  e.preventDefault();
  const id = document.getElementById('note-id').value;
  const title = document.getElementById('note-title-input').value.trim();
  const content = document.getElementById('note-content-input').value;
  const category = document.getElementById('note-category-input').value;
  const is_pinned = document.getElementById('note-pinned-input').checked;

  if (!title) {
    showToast('Judul catatan wajib diisi.', 'error');
    return;
  }

  const payload = { title, content, category, is_pinned };

  try {
    if (id) {
      await api.notes.update(id, payload);
      showToast('Catatan berhasil diperbarui!', 'success');
    } else {
      await api.notes.create(payload);
      showToast('Catatan berhasil disimpan!', 'success');
    }
    closeNoteModal();
    loadNotes();
  } catch (err) {
    showToast(err.message || 'Gagal menyimpan catatan.', 'error');
  }
}
