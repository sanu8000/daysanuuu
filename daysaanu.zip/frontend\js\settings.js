// Daysaanu Settings Interactive Script
import { api, setCurrentUser } from './api.js';
import {
  initAppShell,
  showToast,
  confirmDialog,
  escapeHtml
} from './components.js';

document.addEventListener('DOMContentLoaded', () => {
  initAppShell('settings');
  loadSettings();
  setupEventListeners();
  checkNotificationStatus();
});

function setupEventListeners() {
  document.getElementById('profile-form')?.addEventListener('submit', handleProfileUpdate);
  document.getElementById('save-pomodoro-settings-btn')?.addEventListener('click', handlePomodoroSave);

  // Theme Picker
  document.querySelectorAll('.theme-picker-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.theme-picker-option').forEach(o => o.classList.remove('active'));
      opt.classList.add('active');
      const theme = opt.dataset.theme;
      applyAndSaveTheme(theme);
    });
  });

  // Reduced Motion
  document.getElementById('setting-reduced-motion')?.addEventListener('change', (e) => {
    const enabled = e.target.checked;
    localStorage.setItem('daysaanu_reduced_motion', enabled ? 'true' : 'false');
    if (enabled) {
      document.documentElement.setAttribute('data-reduced-motion', 'true');
    } else {
      document.documentElement.removeAttribute('data-reduced-motion');
    }
    api.settings.update({ reduced_motion: enabled });
    showToast(`Mode reduced motion ${enabled ? 'diaktifkan' : 'dinonaktifkan'}.`, 'info');
  });

  // Notification Permission
  document.getElementById('request-perm-btn')?.addEventListener('click', requestNotificationPermission);

  // Export Data
  document.getElementById('export-data-btn')?.addEventListener('click', () => {
    api.settings.exportData();
    showToast('Mengunduh berkas cadangan data...', 'success');
  });

  // Logout
  document.getElementById('logout-main-btn')?.addEventListener('click', () => {
    confirmDialog({
      title: 'Keluar dari Daysaanu',
      message: 'Apakah Anda yakin ingin mengakhiri sesi ini?',
      confirmText: 'Keluar',
      danger: true,
      onConfirm: () => api.auth.logout()
    });
  });

  // Delete Account
  document.getElementById('delete-account-btn')?.addEventListener('click', () => {
    confirmDialog({
      title: 'Hapus Akun Permanen',
      message: 'PERINGATAN: Tindakan ini tidak dapat dibatalkan. Seluruh data tugas, kuliah, catatan, keuangan, dan kebiasaan Anda akan dihapus selamanya.',
      confirmText: 'Hapus Selamanya',
      danger: true,
      onConfirm: async () => {
        try {
          await api.settings.deleteAccount();
          showToast('Akun Anda telah dihapus.', 'info');
          setTimeout(() => api.auth.logout(), 1000);
        } catch (err) {
          showToast(err.message || 'Gagal menghapus akun.', 'error');
        }
      }
    });
  });
}

async function loadSettings() {
  try {
    const res = await api.settings.get();
    if (!res.success) throw new Error(res.message);

    const { user, settings } = res;

    // Profile inputs
    if (user) {
      document.getElementById('setting-name-input').value = user.name || '';
      document.getElementById('setting-email-input').value = user.email || '';
    }

    // Pomodoro settings
    if (settings) {
      document.getElementById('setting-pomodoro-focus').value = settings.pomodoro_focus || 25;
      document.getElementById('setting-pomodoro-short').value = settings.pomodoro_short_break || 5;
      document.getElementById('setting-pomodoro-long').value = settings.pomodoro_long_break || 15;

      const currentTheme = localStorage.getItem('daysaanu_theme') || settings.theme || 'system';
      document.querySelectorAll('.theme-picker-option').forEach(opt => {
        if (opt.dataset.theme === currentTheme) {
          opt.classList.add('active');
        } else {
          opt.classList.remove('active');
        }
      });

      const reducedMotion = localStorage.getItem('daysaanu_reduced_motion') === 'true' || !!settings.reduced_motion;
      document.getElementById('setting-reduced-motion').checked = reducedMotion;
    }
  } catch (err) {
    showToast('Gagal memuat pengaturan.', 'error');
  }
}

async function handleProfileUpdate(e) {
  e.preventDefault();
  const name = document.getElementById('setting-name-input').value.trim();
  const email = document.getElementById('setting-email-input').value.trim();
  const current_password = document.getElementById('setting-current-pass').value;
  const new_password = document.getElementById('setting-new-pass').value;

  if (!name || !email) {
    showToast('Nama dan email wajib diisi.', 'error');
    return;
  }

  const payload = { name, email };
  if (new_password) {
    if (!current_password) {
      showToast('Masukkan kata sandi saat ini untuk mengubah kata sandi.', 'error');
      return;
    }
    payload.current_password = current_password;
    payload.new_password = new_password;
  }

  try {
    const res = await api.settings.updateProfile(payload);
    if (res.success && res.user) {
      setCurrentUser(res.user);
      showToast('Profil berhasil diperbarui!', 'success');
      document.getElementById('setting-current-pass').value = '';
      document.getElementById('setting-new-pass').value = '';
    }
  } catch (err) {
    showToast(err.message || 'Gagal memperbarui profil.', 'error');
  }
}

async function handlePomodoroSave() {
  const pomodoro_focus = document.getElementById('setting-pomodoro-focus').value;
  const pomodoro_short_break = document.getElementById('setting-pomodoro-short').value;
  const pomodoro_long_break = document.getElementById('setting-pomodoro-long').value;

  try {
    await api.settings.update({
      pomodoro_focus: parseInt(pomodoro_focus, 10),
      pomodoro_short_break: parseInt(pomodoro_short_break, 10),
      pomodoro_long_break: parseInt(pomodoro_long_break, 10)
    });
    showToast('Durasi timer Pomodoro berhasil disimpan!', 'success');
  } catch (err) {
    showToast('Gagal menyimpan durasi timer.', 'error');
  }
}

function applyAndSaveTheme(theme) {
  localStorage.setItem('daysaanu_theme', theme);
  if (theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
    document.documentElement.setAttribute('data-theme', 'dark');
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
  }
  api.settings.update({ theme });
  showToast(`Tema diubah ke ${theme === 'dark' ? 'Mode Gelap' : theme === 'light' ? 'Mode Terang' : 'Sistem'}.`, 'info');
}

function checkNotificationStatus() {
  const statusEl = document.getElementById('notification-perm-status');
  if (!statusEl) return;

  if (!('Notification' in window)) {
    statusEl.textContent = 'Status: Browser tidak mendukung notifikasi web.';
    return;
  }

  if (Notification.permission === 'granted') {
    statusEl.textContent = 'Status: Izin telah diberikan (Aktif) ✅';
    statusEl.style.color = 'var(--status-success)';
  } else if (Notification.permission === 'denied') {
    statusEl.textContent = 'Status: Izin diblokir oleh peramban ❌';
    statusEl.style.color = 'var(--status-danger)';
  } else {
    statusEl.textContent = 'Status: Belum diizinkan ℹ️';
  }
}

async function requestNotificationPermission() {
  if (!('Notification' in window)) {
    showToast('Peramban ini tidak mendukung Web Notifications.', 'error');
    return;
  }

  const permission = await Notification.requestPermission();
  checkNotificationStatus();
  if (permission === 'granted') {
    showToast('Izin notifikasi berhasil diaktifkan!', 'success');
    new Notification('Daysaanu', {
      body: 'Pengingat dan notifikasi Anda sekarang aktif.',
      icon: 'assets/logo-icon.svg'
    });
  } else {
    showToast('Izin notifikasi tidak diberikan.', 'info');
  }
}
