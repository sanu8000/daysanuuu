import express from 'express';
import {
  getGoals,
  createGoal,
  updateGoal,
  deleteGoal,
  addMilestone,
  toggleMilestone,
  deleteMilestone
} from '../controllers/goals.controller.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
router.use(authenticate);

router.get('/', getGoals);
router.post('/', createGoal);
router.put('/:id', updateGoal);
router.delete('/:id', deleteGoal);

router.post('/:id/milestones', addMilestone);
router.patch('/milestones/:milestoneId/toggle', toggleMilestone);
router.delete('/milestones/:milestoneId', deleteMilestone);

export default router;
