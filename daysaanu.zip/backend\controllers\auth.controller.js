import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../config/db.js';

const JWT_SECRET = process.env.JWT_SECRET || 'daysaanu_ultra_secure_jwt_secret_key_2026_salsa_workspace';

export async function register(req, res) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Mohon lengkapi semua bidang (nama, email, dan kata sandi).'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Kata sandi minimal harus 6 karakter.'
      });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = await query('SELECT id FROM users WHERE email = $1', [cleanEmail]);
    if (existing.rows.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'Email sudah terdaftar. Silakan gunakan email lain atau masuk.'
      });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const userRes = await query(
      `INSERT INTO users (name, email, password_hash)
       VALUES ($1, $2, $3) RETURNING id, name, email, avatar, created_at`,
      [name.trim(), cleanEmail, passwordHash]
    );
    const user = userRes.rows[0];

    // Default settings
    await query(
      `INSERT INTO settings (user_id, theme, accent_color, pomodoro_focus, pomodoro_short_break, pomodoro_long_break, notifications_enabled, reduced_motion)
       VALUES ($1, 'system', '#4F46E5', 25, 5, 15, true, false)`,
      [user.id]
    );

    // Default budget
    await query(
      `INSERT INTO finance_budgets (user_id, monthly_budget, savings_target, current_savings)
       VALUES ($1, 3000000, 10000000, 0)`,
      [user.id]
    );

    const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, {
      expiresIn: '7d'
    });

    return res.status(201).json({
      success: true,
      message: `Selamat datang di Daysaanu, ${user.name}!`,
      token,
      user
    });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({
      success: false,
      message: 'Sepertinya ada masalah pada server. Coba lagi beberapa saat lagi.'
    });
  }
}

export async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Mohon masukkan email dan kata sandi Anda.'
      });
    }

    const cleanEmail = email.trim().toLowerCase();
    const userRes = await query(
      `SELECT id, name, email, password_hash, avatar, created_at FROM users WHERE email = $1`,
      [cleanEmail]
    );

    if (userRes.rows.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Email atau kata sandi tidak cocok. Silakan periksa kembali.'
      });
    }

    const user = userRes.rows[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);
    if (!isMatch) {
      return res.status(401).json({
        success: false,
        message: 'Email atau kata sandi tidak cocok. Silakan periksa kembali.'
      });
    }

    const token = jwt.sign({ id: user.id, email: user.email, name: user.name }, JWT_SECRET, {
      expiresIn: '7d'
    });

    delete user.password_hash;

    // Get settings
    const settingsRes = await query('SELECT * FROM settings WHERE user_id = $1', [user.id]);
    const settings = settingsRes.rows[0] || {};

    return res.json({
      success: true,
      message: `Selamat datang kembali, ${user.name}!`,
      token,
      user,
      settings
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({
      success: false,
      message: 'Sepertinya ada masalah. Coba lagi.'
    });
  }
}

export async function getMe(req, res) {
  try {
    const userRes = await query(
      `SELECT id, name, email, avatar, created_at FROM users WHERE id = $1`,
      [req.user.id]
    );

    if (userRes.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Pengguna tidak ditemukan.'
      });
    }

    const user = userRes.rows[0];
    const settingsRes = await query('SELECT * FROM settings WHERE user_id = $1', [user.id]);
    const settings = settingsRes.rows[0] || {};

    return res.json({
      success: true,
      user,
      settings
    });
  } catch (err) {
    console.error('GetMe error:', err);
    return res.status(500).json({
      success: false,
      message: 'Gagal memuat profil pengguna.'
    });
  }
}
