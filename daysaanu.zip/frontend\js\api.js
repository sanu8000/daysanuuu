// Daysaanu Central API Client

const API_BASE = '/api';

export function getToken() {
  return localStorage.getItem('daysaanu_token');
}

export function setToken(token) {
  if (token) {
    localStorage.setItem('daysaanu_token', token);
  } else {
    localStorage.removeItem('daysaanu_token');
  }
}

export function getCurrentUser() {
  const user = localStorage.getItem('daysaanu_user');
  return user ? JSON.parse(user) : null;
}

export function setCurrentUser(user) {
  if (user) {
    localStorage.setItem('daysaanu_user', JSON.stringify(user));
  } else {
    localStorage.removeItem('daysaanu_user');
  }
}

export async function request(endpoint, options = {}) {
  const token = getToken();
  const headers = {
    'Content-Type': 'application/json',
    ...(options.headers || {})
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });

    if (response.status === 401) {
      // Unauthorized: clear session and redirect to login if not already there
      setToken(null);
      setCurrentUser(null);
      if (!window.location.pathname.endsWith('index.html') && window.location.pathname !== '/') {
        window.location.href = 'index.html';
      }
      throw new Error('Sesi Anda telah berakhir. Silakan masuk kembali.');
    }

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || 'Terjadi kesalahan pada sistem.');
    }

    return data;
  } catch (err) {
    console.error(`API Error [${endpoint}]:`, err.message);
    throw err;
  }
}

export const api = {
  // Auth
  auth: {
    login: (credentials) => request('/auth/login', { method: 'POST', body: JSON.stringify(credentials) }),
    register: (userData) => request('/auth/register', { method: 'POST', body: JSON.stringify(userData) }),
    me: () => request('/auth/me'),
    logout: () => {
      setToken(null);
      setCurrentUser(null);
      window.location.href = 'index.html';
    }
  },

  // Dashboard
  dashboard: {
    get: () => request('/dashboard')
  },

  // Tasks
  tasks: {
    getAll: (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/tasks${qs ? '?' + qs : ''}`);
    },
    create: (data) => request('/tasks', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/tasks/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    toggle: (id) => request(`/tasks/${id}/toggle`, { method: 'PATCH' }),
    delete: (id) => request(`/tasks/${id}`, { method: 'DELETE' })
  },

  // University & Courses
  courses: {
    getSemesters: () => request('/courses/semesters'),
    createSemester: (data) => request('/courses/semesters', { method: 'POST', body: JSON.stringify(data) }),
    getCourses: (semesterId) => request(`/courses${semesterId ? '?semester_id=' + semesterId : ''}`),
    createCourse: (data) => request('/courses', { method: 'POST', body: JSON.stringify(data) }),
    updateCourse: (id, data) => request(`/courses/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    deleteCourse: (id) => request(`/courses/${id}`, { method: 'DELETE' }),
    getExams: () => request('/courses/exams/all'),
    createExam: (data) => request('/courses/exams', { method: 'POST', body: JSON.stringify(data) }),
    deleteExam: (id) => request(`/courses/exams/${id}`, { method: 'DELETE' })
  },

  // Events & Calendar
  events: {
    getAll: (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/events${qs ? '?' + qs : ''}`);
    },
    create: (data) => request('/events', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/events/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id) => request(`/events/${id}`, { method: 'DELETE' })
  },

  // Focus & Pomodoro
  focus: {
    getStats: () => request('/focus/stats'),
    logSession: (data) => request('/focus/session', { method: 'POST', body: JSON.stringify(data) })
  },

  // Habits
  habits: {
    getAll: () => request('/habits'),
    create: (data) => request('/habits', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/habits/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id) => request(`/habits/${id}`, { method: 'DELETE' }),
    toggleCheck: (id, date) => request(`/habits/${id}/toggle`, { method: 'POST', body: JSON.stringify({ date }) })
  },

  // Finance
  finance: {
    getSummary: () => request('/finance/summary'),
    getTransactions: (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/finance/transactions${qs ? '?' + qs : ''}`);
    },
    createTransaction: (data) => request('/finance/transactions', { method: 'POST', body: JSON.stringify(data) }),
    deleteTransaction: (id) => request(`/finance/transactions/${id}`, { method: 'DELETE' }),
    updateBudget: (data) => request('/finance/budget', { method: 'PUT', body: JSON.stringify(data) })
  },

  // Notes
  notes: {
    getAll: (params = {}) => {
      const qs = new URLSearchParams(params).toString();
      return request(`/notes${qs ? '?' + qs : ''}`);
    },
    create: (data) => request('/notes', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/notes/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    togglePin: (id) => request(`/notes/${id}/pin`, { method: 'PATCH' }),
    delete: (id) => request(`/notes/${id}`, { method: 'DELETE' })
  },

  // Goals
  goals: {
    getAll: () => request('/goals'),
    create: (data) => request('/goals', { method: 'POST', body: JSON.stringify(data) }),
    update: (id, data) => request(`/goals/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id) => request(`/goals/${id}`, { method: 'DELETE' }),
    addMilestone: (id, data) => request(`/goals/${id}/milestones`, { method: 'POST', body: JSON.stringify(data) }),
    toggleMilestone: (milestoneId) => request(`/goals/milestones/${milestoneId}/toggle`, { method: 'PATCH' }),
    deleteMilestone: (milestoneId) => request(`/goals/milestones/${milestoneId}`, { method: 'DELETE' })
  },

  // Statistics
  statistics: {
    get: () => request('/statistics')
  },

  // Global Search
  search: {
    query: (q) => request(`/search?q=${encodeURIComponent(q)}`)
  },

  // Settings
  settings: {
    get: () => request('/settings'),
    update: (data) => request('/settings', { method: 'PUT', body: JSON.stringify(data) }),
    updateProfile: (data) => request('/settings/profile', { method: 'PUT', body: JSON.stringify(data) }),
    exportData: () => window.open('/api/settings/export', '_blank'),
    deleteAccount: () => request('/settings/account', { method: 'DELETE' })
  }
};
